using System;
using ModernUO.Serialization;
using Server.Collections;
using Server.ContextMenus;
using Server.Items;
using Server.Mobiles;

namespace Server.Engines.CorpseSystem;

[SerializationGenerator(0, false)]
public partial class CorpseMinion : Banker
{
    private static readonly TimeSpan DevourDelay = TimeSpan.FromSeconds(60);

    private static readonly int[] TransformSounds = { 1115, 1114, 1113, 1112, 1153, 1150 };
    private static readonly string[] TransformPhrases =
    {
        "Unleashed!! I feed again.",
        "The many souls I feed on...",
        "Yet another corpse to leech from.",
        "Shackled into such a horrid service..",
        "I will eat more than your corpse next time!!"
    };

    private TimerExecutionToken _expireToken;
    private TimerExecutionToken _devourToken;
    private Corpse _prey;
    private bool _isTransformed;

    [SerializableField(0)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private bool _isBanker;

    [SerializableField(1)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private CorpseSummoner _summoner;

    protected override BaseAI ForcedAI => new FollowMasterAI(this);

    [Constructible]
    public CorpseMinion(CorpseSummoner summoner = null)
    {
        _summoner = summoner;

        if (summoner != null)
        {
            ActiveSpeed = summoner.ActiveSpeed;
            PassiveSpeed = summoner.PassiveSpeed;
            CurrentSpeed = summoner.CurrentSpeed;
            _isBanker = summoner.IsBanker;
        }

        Body = 776;
        Name = "an enslaved minion";
        Title = "";
        RangePerception = 100;
        SpeechHue = 33;
    }

    public bool IsTransformed => _isTransformed;

    public override void InitSBInfo()
    {
        if (_isBanker)
            base.InitSBInfo();
    }

    public override bool HandlesOnSpeech(Mobile from) => _isBanker && base.HandlesOnSpeech(from);

    public override void OnSpeech(SpeechEventArgs e)
    {
        if (_isBanker)
            base.OnSpeech(e);
    }

    public override void GetContextMenuEntries(Mobile from, ref PooledRefList<ContextMenuEntry> list)
    {
        if (_isBanker)
            base.GetContextMenuEntries(from, ref list);
    }

    public void Transform(Mobile target, Corpse prey)
    {
        if (target is null)
            return;

        _prey = prey;
        _devourToken.Cancel();
        Timer.StartTimer(DevourDelay, DevourPrey, out _devourToken);

        if (_isTransformed)
            return;

        target.FixedParticles(0x3728, 1, 13, 9912, 1150, 7, EffectLayer.Head);
        target.FixedParticles(0x3779, 1, 15, 9502, 67, 7, EffectLayer.Head);

        Direction = GetDirectionTo(target);

        Effects.PlaySound(Location, Map, Utility.RandomList(TransformSounds));
        Say(Utility.RandomList(TransformPhrases));

        FixedParticles(0x375A, 1, 17, 9919, 33, 7, EffectLayer.Waist);
        FixedParticles(0x3728, 1, 13, 9502, 33, 7, (EffectLayer)255);

        Body = 303;
        _isTransformed = true;

        Timer.StartTimer(TimeSpan.FromSeconds(10), RevertTransformation, out _expireToken);
    }

    public override void OnAfterDelete()
    {
        _expireToken.Cancel();
        _devourToken.Cancel();
        base.OnAfterDelete();
    }

    [AfterDeserialization]
    private void AfterDeserialization()
    {
        if (_summoner == null || _summoner.Deleted)
        {
            Timer.StartTimer(Delete);
            return;
        }

        _isTransformed = false;
        Body = 776;
    }

    private void DevourPrey()
    {
        if (_prey is not { Deleted: false })
            return;

        FixedParticles(0x37B9, 1, 14, 9502, 37, 3, EffectLayer.Waist);
        Effects.PlaySound(Location, Map, 0x3B3);
        PublicOverheadMessage(MessageType.Emote, 33, false, "*devours the corpse*");

        Effects.SendLocationParticles(EffectItem.Create(_prey.Location, _prey.Map, EffectItem.DefaultDuration), 0x36B0, 1, 14, 63, 7, 9915, 0);
        _prey.Delete();
        _prey = null;
    }

    private void RevertTransformation()
    {
        if (Deleted)
            return;

        _isTransformed = false;
        Body = 776;

        Effects.SendLocationParticles(EffectItem.Create(Location, Map, EffectItem.DefaultDuration), 0x37CC, 1, 40, 97, 3, 9917, 0);
        Effects.PlaySound(Location, Map, 1200);
        PublicOverheadMessage(MessageType.Emote, 0, false, "the creature returns to its suppressed state");

        foreach (var corpse in GetItemsInRange<Corpse>(4))
        {
            if (corpse is { Deleted: false } && CorpseBook.IsEmpty(corpse))
            {
                Effects.SendLocationParticles(EffectItem.Create(corpse.Location, corpse.Map, EffectItem.DefaultDuration), 0x36B0, 1, 14, 63, 7, 9915, 0);
                corpse.Delete();
            }
        }
    }
}

public class FollowMasterAI : BaseAI
{
    private readonly CorpseMinion _minion;

    public FollowMasterAI(CorpseMinion minion) : base(minion) => _minion = minion;

    public override void WalkRandom(int iChanceToNotMove, int iChanceToDir, int iSteps) => FollowMaster();

    private bool FollowMaster() =>
        _minion.Summoner is { Deleted: false } summoner && WalkMobileRange(summoner, 3, 1, 2);
}