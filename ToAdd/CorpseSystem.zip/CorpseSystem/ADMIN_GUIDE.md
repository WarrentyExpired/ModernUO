# Corpse Retrieval System — Administrator Guide

**Original author:** krazeykow (RunUO RC 1.0)  
**Refactoring:** Milva (ServUO / XMLSpawner version)  
**Refactoring + Fixed bug:** Expa (ModernUO)  

---

## 1. Overview

The Corpse Retrieval System provides an NPC **Corpse Summoner** who, for a fee,
teleports a player's corpse to the player's current location. The system keeps
track of the player's last corpses automatically and presents them in a gump
with decay time, item count and gold estimate.

Two extra features are built in:

- **Paid resurrection** — the summoner can resurrect dead players, either free
  of charge or for a configurable price (gold is drawn from the player's bank).
- **Banker mode** — the summoner's minion can act as a full banker (speech
  commands such as "bank", "balance", "withdraw", buy/sell context entries).

The system is fully serializable, restart-safe and self-healing: lost minions
are re-spawned, orphaned books and minions delete themselves after a server
restart.

This document was updated to reflect recent code changes:
- fixes to compilation errors (missing backing field, qualified MarkDirty calls),
- cleanup of references on delete,
- stylistic modernisation (expression-bodied members, pattern matching),
- minor AI compatibility adjustments to match your BaseAI signature.

---

## 2. Components

| Class | File | Description |
|---|---|---|
| `CorpseSummoner` | `CorpseSummoner.cs` | The NPC. Spawns and controls the minion. |
| `CorpseMinion` | `CorpseMinion.cs` | The summoner's slave creature. Follows its master and performs the transformation animation when a corpse is summoned. |
| `FollowMasterAI` | `CorpseMinion.cs` | Custom AI that only follows the summoner. Note: adjusted to match local `BaseAI.WalkMobileRange` signature. |
| `CorpseBook` | `CorpseBook.cs` | Invisible, blessed, immovable item stored in the player's backpack. Holds up to 5 corpses. Now clears references on delete. |
| `CorpseMenu` | `CorpseMenu.cs` | Dynamic gump listing the player's corpses. |
| `CorpseSystem` | `CorpseSystem.cs` | Static helper; hooks player deaths and manages books. |

No external dependencies. The original XMLSpawner2 `XmlAttachment` has been
replaced by the `CorpseBook` item — **XMLSpawner is no longer required**.

---

## 3. Installation & Build

1. Copy the `CorpseSystem` folder into:
   `Projects/UOContent/Engines/` (or `Projects/UOContent/Custom/` — any folder
   compiled into UOContent works).
2. Clean stale generated files if you modified an older copy:
   delete `Projects/UOContent/obj/` before building.
3. Build the server:
   - Windows: `publish.cmd`
   - Linux/macOS: `./publish.sh`

Notes
- Recent fixes required qualifying `MarkDirty()` calls as `this.MarkDirty()` to
  resolve CS0103 in your codebase; if you further change the code generator / base
  types, adapt accordingly.
- The `IsBanker` backing field was made explicit (private `_isBanker`) and exposed
  via `[SerializableProperty(..., useField: nameof(_isBanker))]` so the
  serialization generator binds property ↔ field. Check SG warnings after build.

---

## 4. Spawning the NPC

Use the standard `[add` command:

```
[add CorpseSummoner
```

Then use `[move` or the `Go` gump to place it. The NPC is invulnerable and has
no vendor buying/selling by default.

---

## 5. Configuration (in-game properties)

Target the NPC with `[props` to configure it in real time. All properties are
saved automatically.

| Property | Default | Description |
|---|---|---|
| `CorpsePrice` | 3000 | Price in gold for one corpse summon. Charged to the player's **bank**. `0` = free. |
| `ResPrice` | 0 | Price in gold for resurrection. `0` = offer normal free resurrection. |
| `CanRes` | true | Whether the summoner offers resurrection at all. |
| `IsBanker` | false | If true, the minion acts as a full banker (speech banking + context menu). Change takes effect immediately; implemented with a serializable backing field. |
| `Minion` | — | (Read-only reference, GM info.) |

---

## 6. Player Experience

### Summoning a corpse
- Player approaches the summoner and either **double-clicks** him or uses the
  context menu entry *"Summon Corpse"*.
- A gump lists up to 5 corpses with:
  - **minutes until decay** (color coded),
  - item count,
  - gold estimate (in thousands).
- The player selects one corpse and presses OK. The price is withdrawn from
  the bank (with localized receipt messages), the minion transforms with
  effects and speech, and the corpse appears at the player's feet.
- If the player does not loot the summoned corpse by the end of the transformation
  (10 seconds), the minion devours it — effects, an emote, and the corpse is
  deleted automatically.
- Corpses that have fully decayed are rejected with: *"Your corpse is beyond my
  reach, it must have rotted."*

Decay colour code (default 14-minute decay):
- **Green (57)** — 11+ minutes remaining,
- **Yellow (47)** — 5–10 minutes remaining,
- **Red (37)** — under 5 minutes remaining.

### Resurrection
Dead players near the summoner get the resurrection offer as with any healer.
If `ResPrice > 0`, a priced resurrect gump appears; payment is taken from the
bank on accept, otherwise the player stays dead.

### Banker mode
With `IsBanker = true` the minion answers standard banking speech
("bank", "balance", "withdraw", "check") and shows bank context entries.
The summoner himself is **not** a banker in either mode.

---

## 7. How corpse tracking works (technical, for admins)

- On every player death, the system attaches a `CorpseBook` item to the
  player's backpack (created automatically, invisible to players) and records
  the corpse.
- The book holds the **last 5 non-empty corpses** (oldest is pushed out).
- Empty (fully looted) corpses are pruned automatically: on every gump open
  and after every world load (`[Tidy]` serialization flag).
- When a corpse is summoned, it is removed from the book.
- The gump also falls back to the player's most recent corpse (`from.Corpse`)
  even if the book is missing.

Important implementation notes (recent changes):
- `CorpseBook.OnAfterDelete()` now clears `_player` and `_corpses` to avoid
  stale references retaining deleted Mobiles/items after the item itself is deleted.
- `IsBanker` now has an explicit backing field (`_isBanker`) to resolve
  a missing-field compile error in some codebases; this change is serialization-safe
  (uses `[SerializableProperty(..., useField: ...)]`).
- `CorpseMenu` layout and logic were modernized stylistically only; no behavior change.
- `CorpseMinion` AI (FollowMasterAI) was adjusted to match the local `BaseAI.WalkMobileRange`
  signature. If your `BaseAI` has a different signature or supports an `OnCurrentOrderChanged`
  hook, restore the call there to keep prior behavior (see Troubleshooting & Developer notes).

**Important:** corpse history from the old XMLSpawner version does **not**
migrate. The system starts fresh after the upgrade.

---

## 8. Balance & Tuning Notes

- All fees are charged to the **bank box**, not carried gold.
- The summoner never moves; the corpse is teleported **to the player**.
- `CorpsePrice` and `ResPrice` can be set to `0` for a free public service.
- `CorpseDecayTime` in `CorpseMenu.cs` is hardcoded to 14 minutes; change it
  there if your server uses a different real decay.

---

## 9. Troubleshooting & Known gotchas

| Symptom | Cause / Fix |
|---|---|
| Build errors after updating | Delete `Projects/UOContent/obj/` and rebuild. Recent fixes added `this.MarkDirty()` calls and an explicit `_isBanker` field — ensure you applied all modified files. |
| NPC shows no context menu | Player must be alive and within 2 tiles of the NPC. |
| Gump says "You have no corpse..." | All recorded corpses decayed/looted, or no corpse exists yet. |
| "Your corpse is beyond my reach..." | Selected corpse decayed between opening the gump and pressing OK. Normal — reopen the gump. |
| Summoned corpse disappeared | Minion devoured the corpse after the transformation window (10s). Loot quickly. |
| Minion missing / not following | Walk near the summoner; the minion respawns on the summoner's next movement tick. If the summoner was teleported far, the old minion is deleted and re-created next tick. |
| Duplicate minions wander | Orphaned minions are deleted on restart; each minion is bound to its summoner. |
| Banker speech ignored | Set `IsBanker = true` on the summoner and address the **minion**. |
| Serialization warnings (SGxxxx) | Review build output. The recent changes touched serialization attributes — inspect any SG warnings and share them if you need help. |

Developer note on AI and compatibility
- During refactor I removed an `override OnCurrentOrderChanged()` in `FollowMasterAI`
  because that virtual method was not present in some `BaseAI` versions (caused CS0115).
  I left `WalkRandom` calling `FollowMaster()` and adapted the `WalkMobileRange`
  call to the local signature. If your server previously relied on `OnCurrentOrderChanged`
  to make the minion immediately react to order changes, you should:
  - either add a compatible virtual hook back into your `BaseAI` and override it, or
  - call `FollowMaster()` from the code-path that changes `ControlOrder`/`ControlTarget`.
  If you want, provide your `BaseAI` source/signature and I'll produce the minimal patch to restore exact legacy behavior.

---

## 10. Testing checklist (run these after deployment)

1. Build server successfully with the updated files.
2. Add a `CorpseSummoner` and confirm it appears.
3. Kill a test `PlayerMobile`; confirm a `CorpseBook` appears in backpack and records the corpse.
4. Approach summoner, open gump, verify corpse list, decay minutes and item/gold counts.
5. Select a corpse and confirm:
   - bank withdrawal (if price > 0) with localized receipts,
   - minion transforms (particles/sound/phrase),
   - corpse appears at player's feet,
   - if not looted within 10s, minion devours the corpse and it disappears.
6. Toggle `IsBanker` on the summoner; interact with the minion by speech and context menu.
7. Move summoner away / delete and restart server; confirm minion re-spawns correctly and orphaned entities are cleaned up.
8. Save and restart server; check serialization for warnings (SG codes). Verify `CorpseBook`, `CorpseMinion`, and `CorpseSummoner` restore cleanly.
9. If your server has a custom `BaseAI`, exercise order changes and ensure minion follows as expected (see Developer note above).