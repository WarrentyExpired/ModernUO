using System;
using System.Collections.Generic;
using Server.Gumps;
using Server.Items;
using Server.Mobiles;
using Server.Network;

namespace Server.Engines.CorpseSystem;

public class CorpseMenu : DynamicGump
{
    private static readonly TimeSpan CorpseDecayTime = TimeSpan.FromMinutes(14);

    private const int BgX = 269;
    private const int BgY = 75;
    private const int BgW = 296;
    private const int BgH = 412;
    private const int CharWidth = 7;

    private static readonly int CenterX = BgX + BgW / 2;

    private enum Buttons
    {
        Okay = 5,
        Cancel
    }

    private readonly CorpseSummoner _summoner;
    private readonly int _price;
    private readonly List<Corpse> _corpses;

    public override bool Singleton => true;

    private CorpseMenu(CorpseSummoner summoner, List<Corpse> corpses) : base(0, 0)
    {
        _summoner = summoner;
        _price = summoner.CorpsePrice;
        _corpses = corpses;
    }

    public static void DisplayTo(Mobile from, CorpseSummoner summoner)
    {
        if (from is null || from.Deleted || summoner is null || summoner.Deleted)
            return;

        from.SendGump(new CorpseMenu(summoner, LoadCorpses(from)));
    }

    private static int CenteredLabelX(string text) => CenterX - text.Length * CharWidth / 2;

    private static int CenteredLineX(int width) => CenterX - width / 2;

    protected override void BuildLayout(ref DynamicGumpBuilder builder)
    {
        builder.AddPage();

        builder.AddImageTiled(BgX, BgY, BgW, BgH, 9274);
        builder.AddImageTiled(CenteredLineX(BgW - 1), BgY, BgW - 1, 4, 9107);
        builder.AddImageTiled(CenteredLineX(BgW + 5), BgY + BgH - 1, BgW + 5, 4, 9107);
        builder.AddImage(CenterX - 36, BgY + 28, 9804);

        const string title = "Corpse Summon";
        builder.AddLabel(CenteredLabelX(title), 83, 47, title);

        const string intro1 = "I will summon your corpse";
        const string intro2 = ".. but you will have to pay a price.";
        builder.AddLabel(CenteredLabelX(intro1), 153, 55, intro1);
        builder.AddLabel(CenteredLabelX(intro2), 193, 55, intro2);

        builder.AddImageTiled(CenteredLineX(213), 181, 213, 2, 9107);
        builder.AddImageTiled(CenteredLineX(213), 185, 213, 2, 9157);

        const string header = "Minutes Until Decay";
        builder.AddLabel(CenteredLabelX(header), 215, 1541, header);

        builder.AddButton(CenterX - 67, 439, 2450, 2451, (int)Buttons.Okay);
        builder.AddButton(CenterX + 8, 439, 2453, 2454, (int)Buttons.Cancel);

        var priceText = _price == 0 ? "Price: Free" : $"Price: {_price}";
        builder.AddLabel(CenteredLabelX(priceText), 398, 337, priceText);

        builder.AddItem(BgX + BgW - 21, 399, 8708);
        builder.AddItem(BgX + BgW - 21, 312, 8708);
        builder.AddItem(BgX + BgW - 21, 226, 8708);
        builder.AddItem(BgX + BgW - 21, 141, 8708);
        builder.AddItem(BgX + BgW - 21, 73, 8708);
        builder.AddItem(BgX - 24, 399, 8708);
        builder.AddItem(BgX - 24, 312, 8708);
        builder.AddItem(BgX - 24, 226, 8708);
        builder.AddItem(BgX - 24, 141, 8708);
        builder.AddItem(BgX - 24, 73, 8708);
        builder.AddImage(BgX + 1, 396, 111);

        builder.AddImageTiled(CenteredLineX(213), 425, 213, 1, 9107);

        if (_corpses.Count == 0)
        {
            const string empty = "You have no corpse for me to summon.";
            builder.AddLabel(CenteredLabelX(empty), 338, 32, empty);
            builder.AddImage(CenterX - 39, 254, 7026);
            return;
        }

        var yRadio = 242;
        var yLabel = 239;

        for (var i = 0; i < _corpses.Count; i++)
        {
            var corpse = _corpses[i];
            var remaining = Math.Max(0, (int)(CorpseDecayTime - (Core.Now - corpse.TimeOfDeath)).TotalMinutes);

            builder.AddRadio(289, yRadio, 5230, 5224, false, i);
            builder.AddLabel(320, yLabel, GetDecayHue(remaining),
                $"   {remaining}    Items: {corpse.GetTotal(TotalType.Items)}  Gold: {corpse.GetTotal(TotalType.Gold) / 1000} k");

            yRadio += 30;
            yLabel += 30;
        }
    }

    public override void OnResponse(NetState sender, in RelayInfo info)
    {
        var from = sender.Mobile;

        if (from is null || info.ButtonID != (int)Buttons.Okay)
            return;

        if (info.Switches.Length == 0)
        {
            from.SendMessage("You did not select a corpse to summon.");
            return;
        }

        var selected = info.Switches[0];

        if (selected < 0 || selected >= _corpses.Count)
        {
            from.SendMessage("You did not select a corpse to summon.");
            return;
        }

        Summon(from, _corpses[selected]);
    }

    private static List<Corpse> LoadCorpses(Mobile from)
    {
        var book = CorpseSystem.GetBook(from as PlayerMobile);

        if (book != null)
        {
            book.Prune();

            if (book.Corpses.Count > 0)
                return new List<Corpse>(book.Corpses);
        }

        if (from.Corpse is Corpse last && !last.Deleted && !CorpseBook.IsEmpty(last))
            return new List<Corpse> { last };

        return new List<Corpse>();
    }

    private void Summon(Mobile from, Corpse corpse)
    {
        if (!_summoner.InRange(from, 4) || !_summoner.InLOS(from))
            return;

        if (corpse.Deleted)
        {
            from.SendMessage("Your corpse is beyond my reach, it must have rotted.");
            return;
        }

        if (_price > 0)
        {
            if (Banker.Withdraw(from, _price))
            {
                from.SendLocalizedMessage(1060398, _price.ToString());
                from.SendLocalizedMessage(1060022, Banker.GetBalance(from).ToString());
            }
            else
            {
                from.SendMessage("Unfortunately, you do not have enough cash in your bank to summon your corpse");
                return;
            }
        }

        _summoner.TransformMinion(from, corpse);

        corpse.Map = from.Map;
        corpse.Location = from.Location;
        corpse.SelfLooted = true;

        CorpseSystem.GetBook(from as PlayerMobile)?.Remove(corpse);
    }

    private static int GetDecayHue(int minutesRemaining) => minutesRemaining switch
    {
        >= 11 => 57,
        >= 5 => 47,
        _ => 37
    };
}