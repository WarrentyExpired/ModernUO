using System.Collections.Generic;
using ModernUO.Serialization;
using Server.Items;
using Server.Mobiles;

namespace Server.Engines.CorpseSystem;

[SerializationGenerator(0, false)]
public partial class CorpseBook : Item
{
    private const int MaxCorpses = 5;

    [SerializableField(0)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private Mobile _player;

    [SerializableField(1)]
    [Tidy]
    private List<Corpse> _corpses;

    [Constructible]
    public CorpseBook() : this(null) { }

    public CorpseBook(Mobile player) : base(8787)
    {
        _player = player;
        _corpses = new List<Corpse>();
        Name = "Corpse Book [Do not delete]";
        Hue = 1109;
        Weight = 0.0;
        Visible = false;
        Movable = false;
        LootType = LootType.Blessed;
    }

    public void Update(Corpse corpse)
    {
        if (_player == null || NeedsRemoval(corpse))
            return;

        _corpses.RemoveAll(NeedsRemoval);

        if (_corpses.Count >= MaxCorpses)
            _corpses.RemoveAt(0);

        _corpses.Add(corpse);
        this.MarkDirty();
    }

    public void Remove(Corpse corpse)
    {
        if (_corpses.Remove(corpse))
            this.MarkDirty();
    }

    public void Prune()
    {
        if (_corpses.RemoveAll(NeedsRemoval) > 0)
            this.MarkDirty();
    }

    public static bool IsEmpty(Corpse corpse) =>
        corpse.GetTotal(TotalType.Gold) <= 0 && corpse.GetTotal(TotalType.Items) <= 0;

    [AfterDeserialization]
    private void AfterDeserialization()
    {
        if (_player == null || _player.Deleted)
            Timer.StartTimer(Delete);
    }

    public override void OnAfterDelete()
    {
        _player = null;
        _corpses?.Clear();
        _corpses = null;
        base.OnAfterDelete();
    }

    private static bool NeedsRemoval(Corpse corpse) => corpse == null || corpse.Deleted || IsEmpty(corpse);
}