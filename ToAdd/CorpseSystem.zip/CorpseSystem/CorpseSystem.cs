using ModernUO.CodeGeneratedEvents;
using Server.Items;
using Server.Mobiles;

namespace Server.Engines.CorpseSystem;

public static class CorpseSystem
{
    [OnEvent(nameof(PlayerMobile.PlayerDeathEvent))]
    public static void OnPlayerDeath(PlayerMobile player) => GetOrCreateBook(player)?.Update(player.Corpse as Corpse);

    public static CorpseBook GetBook(PlayerMobile player) => player?.Backpack?.FindItemByType<CorpseBook>();

    public static CorpseBook GetOrCreateBook(PlayerMobile player)
    {
        var book = GetBook(player);

        if (book == null && player?.Backpack != null)
        {
            book = new CorpseBook(player);
            player.Backpack.DropItem(book);
        }

        return book;
    }
}