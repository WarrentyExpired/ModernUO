using System;
using ModernUO.Serialization;
using Server.Collections;
using Server.ContextMenus;
using Server.Gumps;
using Server.Items;
using Server.Mobiles;

namespace Server.Engines.CorpseSystem;

[SerializationGenerator(0, false)]
public partial class CorpseSummoner : BaseHealer
{
    [SerializableField(0)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private int _resPrice;

    [SerializableField(1)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private int _corpsePrice;

    [SerializableField(2)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private bool _canRes;

    [SerializableField(3)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private CorpseMinion _minion;

    private bool _isBanker;

    public override bool IsInvulnerable => true;
    public override bool CanTeach => false;
    public override bool IsActiveVendor => false;
    public override bool IsActiveBuyer => false;
    public override bool IsActiveSeller => false;

    [SerializableProperty(4, useField: nameof(_isBanker))]
    [CommandProperty(AccessLevel.GameMaster)]
    public bool IsBanker
    {
        get => _isBanker;
        set
        {
            _isBanker = value;
            this.MarkDirty();
            if (World.Loading)
                return;

            EnsureMinion();

            if (_minion is { Deleted: false })
                _minion.IsBanker = value;
        }
    }

    [Constructible]
    public CorpseSummoner()
    {
        _corpsePrice = 3000;
        _canRes = true;
        Title = "the corpse summoner";
    }

    public override void InitOutfit()
    {
        AddItem(new Scythe());
        AddItem(new HoodedShroudOfShadows());
        AddItem(new Sandals());
    }

    public override void GetContextMenuEntries(Mobile from, ref PooledRefList<ContextMenuEntry> list)
    {
        base.GetContextMenuEntries(from, ref list);

        if (from.Alive)
            list.Add(new CorpseEntry(this));
    }

    public override void OfferResurrection(Mobile m)
    {
        if (!_canRes)
            return;

        if (_resPrice <= 0)
        {
            base.OfferResurrection(m);
            return;
        }

        Direction = GetDirectionTo(m);
        m.PlaySound(0x214);
        m.FixedEffect(0x376A, 10, 16);

        m.CloseGump<ResurrectGump>();
        m.SendGump(new ResurrectGump(this, _resPrice));
    }

    public override void OnDoubleClick(Mobile m)
    {
        if (InRange(m, 4) && InLOS(m))
            CorpseMenu.DisplayTo(m, this);
    }

    public override void OnMovement(Mobile m, Point3D oldLocation)
    {
        if (_minion is { Deleted: false })
        {
            if (InRange(_minion, 6))
            {
                _minion.ControlTarget = this;
                _minion.ControlOrder = OrderType.Follow;
            }
            else
            {
                _minion.Delete();
                EnsureMinion();
            }
        }
        else
        {
            EnsureMinion();
        }

        base.OnMovement(m, oldLocation);
    }

    public override void OnAfterDelete()
    {
        _minion?.Delete();
        _minion = null;
        base.OnAfterDelete();
    }

    public void TransformMinion(Mobile target, Corpse prey)
    {
        EnsureMinion();
        _minion?.Transform(target, prey);
    }

    [AfterDeserialization]
    private void AfterDeserialization() => Timer.StartTimer(TimeSpan.Zero, EnsureMinion);

    private void EnsureMinion()
    {
        if (_minion is { Deleted: false } || World.Loading)
            return;

        PublicOverheadMessage(MessageType.Spell, 908, true, "Ahn Durst Ku");
        Animate(200, 2, 2, true, true, 2);

        _minion = new CorpseMinion(this);
        _minion.MoveToWorld(Location, Map);
    }
}

public class CorpseEntry : ContextMenuEntry
{
    private readonly CorpseSummoner _summoner;

    public CorpseEntry(CorpseSummoner summoner) : base(6215, 2) => _summoner = summoner;

    public override void OnClick(Mobile from, IEntity target) => CorpseMenu.DisplayTo(from, _summoner);
}