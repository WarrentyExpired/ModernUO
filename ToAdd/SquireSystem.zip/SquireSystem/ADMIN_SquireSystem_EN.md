# SquireSystem — Administrator's Guide
v2.2.7 Author: **MontegroXD / James Wolff**
Refactored & fixes for ModernUO: **Expa**

---

## 1. File Structure & Responsibilities

The system lives in `Projects/UOContent/Custom/SquireSystem/` and is split into 5 folders.

### `Mobiles/` — creatures
| File | Purpose |
|---|---|
| **`Squire.cs`** | ⚠️ The core of the entire system (~2350 lines). The squire class: speech commands, combat AI, auto-heal/resurrection, auto-loot, poisoning, bushido/chivalry/necromancy, tithing, spirit speak, timer-based casts. **Any behavior changes go here.** |
| `RoomAttendant.cs` | House room attendant vendor (BaseVendor). Sells the spyglass, accepts tips (up to 50 gp), holds rumors/news for guests (3 slots: message + keyword). Managed via context menu (house owner). |
| `SS_InnKeeper.cs` | Innkeeper with a "squire room" service (300 gp). Speech: `vendor room`, `vendor help`, `keeper room`, `innkeeper room`. |
| `SquireRepresentative.cs` | Guild representative. **Sells the squire contract (5000 gp)** and the spyglass. |
| `SquireCombatInstructor.cs` | Combat skills instructor (contracts 500 gp, Bushido 300 gp). |
| `SquireHealingInstructor.cs` | Healing instructor (Healing, Veterinary, Animal Lore, Anatomy, Spirit Speak — 500 gp). |
| `SquireBardingInstructor.cs` | Barding instructor (Musicianship, Peacemaking, Discordance, Provocation — 500 gp). |
| `SquireThievingInstructor.cs` | Thieving instructor (Hiding, Stealing, Lockpicking, Poisoning — 500 gp). |

### `System/` — gumps and internal logic
| File | Purpose |
|---|---|
| **`SquireGump.cs`** | `SquireCustomizeGump` (hairstyles/beards/hues via the "restyle" command) and **`SquireLoreGump`** — the main window: Stats / Skills / Switches pages. Switches hold all squire automations. **Mutations (skill locks, switches) are owner-only** (verified by audit). |
| **`SquireCommandGump.cs`** | Categorized command gump (General/Combat/Equipment/Looting/Info/Spells/Settings). Duplicates speech commands. Owner-only, 18-tile range. |
| `SquireTargets.cs` | Target classes: stealing, lockpicking, heal/cure/resurrect, provoke, peace/discord, poisoning, item/corpse looting, potion throw, cast "pass-through" targets for delayed spells (Close Wounds, Remove Curse, etc.). |
| `SquireDialog.cs` | Phrase library (~45 KB). All squire lines: random line per tree, placeholders `{m}` (master nickname), `{s}`, `{n}`, `{t}` (command), `{c}`/`{p}`. Honors the "Be Quiet" switch. |
| `SquireTitle.cs` | Title gump by skill thresholds (Neophyte 30 → Legendary 120). Opened via the "Change title" command. |
| `SquireFunctions.cs` | Prompts (nicknames, command), spirit speak timers, pack/quiver access (`SquirePack`, `SquireQuiver`). |

### `Items/`
| File | Purpose |
|---|---|
| **`TrainingContracts.cs`** | ⚠️ Training contracts. Base `SContract` + 28 types. Mechanics: double-click the contract → skill **to 30** per contract, then +15 (30–50), +5 (50–75), +2 (75–90), +1 (90–100). **The contract is always consumed** (fixed; was an exploit). At 100.0 it is not consumed. |
| `CarrierPigeon.cs` | "Key" pigeon for the squire room. Double-click returns the squire to the master. **Ownership verified** (fixed; previously another player could steal the squire). ⚠️ Deleting the pigeon by any means other than double-click **permanently deletes the squire**. |
| `SquireStatsSpyglass.cs` | Spyglass (200 gp): view Stats/Skills/Switches of **another player's** squire if it has the "Inspectable" switch on. Viewers cannot mutate anything. |
| `SquireDeathShroud.cs` | Death shroud (dropped in the squire's corpse). |

### `Commands/` — GM commands
| File | Command | Level |
|---|---|---|
| `Squire Room.cs` | `[SquireRoom` | GM — room any squire (the targeting player receives the pigeon). |
| `Squire Lore Commands.cs` | `[SquireSkills`, `[SquireStats`, `[SquireSwitches` | GM — lore gump of any squire. |

### `Vendors/` — shop stock (SBInfo)
Pure price lists: `SBSquire*` (instructor contracts), `SBSquireRepresentative` (squire contract 5000 + spyglass 200), `SBSS_InnKeeper` (spyglass 200, chess, barkeep/vendor contracts), `SBRoomAttendant` (spyglass 200).

---

## 2. Balance Tuning Points

| Parameter | Where | Value |
|---|---|---|
| Squire price | `SBSquireRepresentative.cs` | 5000 gp |
| Contract price | `Vendors/SBSquire*.cs` | 500 gp (Bushido 300) |
| Squire room | `SS_InnKeeper.cs`, `RoomAttendant.cs` | 300 gp |
| Pet slots per squire | `Squire.cs`, constructor (`ControlSlots`) | 3 slots |
| Stat / skill caps | `Squire.cs` (`StatCap = 450`, `Skills.Cap = 50000`) | 450 / 500.0 ⚠️ contracts ignore the cap |
| Hit points | `Squire.cs`, `HitsMax` | Str/2 + 50 |
| Lockpicking cooldown | `Squire.cs`, `ExecuteCommand` → `Lockpick` | 4 sec (was 0.5 — training exploit) |
| Loot radius | `Squire.cs`, `GrabItems` | 3 tiles |
| Per-item loot action lock | `Squire.cs`, `NextActionTime` | 5 sec |
| Discordance duration | `SquireTargets.cs` | 2 × squire skill, sec |
| Title thresholds | `SquireTitle.cs`, `GetPrefix` | 30/40/…/120 |

---

## 3. Known Behaviors (not bugs, but know them)

1. **Loyalty without food.** `CheckFeedSelf`, every think tick while loyalty isn't max: +1 loyalty (50% chance), hunger = 10, stamina +15. No food consumed. Loyalty maxes in seconds. For classic food mechanics — edit `CheckFeedSelf` in `Squire.cs`.
2. **Squires are always bonded** (`IsBonded = true` in the constructor) — on death they become a ghost and can be resurrected; never lost.
3. **Cast target race.** Delayed casts (Close Wounds, Remove Curse, explosion potion) store the target in `Mobile.Target` and invoke it via a timer 1–1.5 s later. If auto-heal overwrote Target in that window — a rare cross-target is possible. Refactor deferred; if it becomes a common complaint — fix centrally.
4. **Player corpses are never looted** (not even by Loot All) — anti-criminal protection. "Blue" NPC corpses are only taken by the **Loot All** command (auto-loot and Grab All respect notoriety).
5. **Stealing via the squire** — full port of core `Stealing.cs` logic: thieves-guild check, weight, newbied/blessed, criminality. Criminal flag and PermaFlag go to the **squire**, not the master.
6. **Poisoning** — only items in the squire's or master's pack (other players' weapons/equipment are unavailable — fixed).
7. **The squire never casts Close Wounds on a dead master** — the resurrection branch (Spirit Speak + bandage) works (fixed).
8. **"all …" commands work** (all attack / all guard / all stay …) — fixed.
9. **Be Quiet** silences all lines centrally (including spirit speak).

---

## 4. Operations

### Install / Update
- Self-contained: copy the `Custom/SquireSystem/` folder into `Projects/UOContent/`. No external dependencies (ModernUO core only).
- **Serialization unchanged** (version 0 everywhere) — replace files without save conversion.
- After replacing files: rebuild (`dotnet build`), restart. Compile errors: search by namespace `Server.Mobiles.Squire*`.

### Post-update smoke test
1. `[SquireRoom` → target a squire → pigeon in pack → double-click → squire returns.
2. Speech: "Name attack" / "all stay" / "Name loot all".
3. Lore gump (pet button): Stats/Skills/Switches pages, switches toggle.
4. Spyglass on another player's squire with "Inspectable": viewable, cannot mutate.
5. Contract: used → skill rose → contract gone. At 100.0 — not consumed.
6. Ankh: "Name tithe" near a static ankh works.

### Logs
- Diagnostic `[Squire][Diag]` logs removed. Standard `ILogger` remains — errors (e.g., pigeon deletion) go to the server log.

---

## 5. Change History (audit fixes)

**Batch 1 — `Squire.cs`:** speech "all" commands; Close Wounds on corpse blocking resurrection; master auto-heal suppression; diag logs removed.
**Batch 2 — `Squire.cs`:** NRE when attacking unarmed (`SetRandomWeaponAbility`, `WeaponAbilityOne/Two`); `DropItem(null)` on empty weapon-set equip; ankh detection via static tiles (`Map.Tiles.GetStaticAndMultiTiles`).
**Batch 3 — `SquireTargets.cs` + `Squire.cs`:** discordance duration from squire skill (was master's); poisoning of other players' items; lockpick cooldown 0.5 → 4 s; diag logs. **`TrainingContracts.cs`:** contract always consumed, clamp at 100.0, no consumption at cap.
**Batch 4 — authorization & misc:** `CarrierPigeon` (squire theft); `SquireGump` (mutating another player's squire via spyglass); `RoomAttendant`/`SS_InnKeeper` (House setter, null-guards); `SquireCommandGump` (About-gump stacking); `SquireDialog` (Be Quiet centralized); typos.

### Deferred shard-owner decisions
- Loyalty without food (3.1).
- 500-point cap vs contracts.
- Softening `CarrierPigeon.OnDelete` (currently pigeon deletion = squire lost forever).
- Bushido contract price 300 vs 500; no Necromancy contract.
- `RacialSkillBonus => 20` for elf squires.
- Dead code: gender-change case in `SquireCustomizeGump`, bonding block in `CheckFeedSelf`.
