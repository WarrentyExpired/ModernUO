using System;
using ModernUO.Serialization;
using Server;
using Server.Mobiles;
using Server.Network;
using Server.Multis;

namespace Server.Items;
[SerializationGenerator(0, false)]
	public partial class RoomAttendantContract : Item
	{

		[Constructible]
		public RoomAttendantContract() : base( 0x14F0 )
		{
            Name = "a room attendant contract";
			Weight = 1.0;
			LootType = LootType.Blessed;
		}


		

		

		public override void OnDoubleClick( Mobile from )
		{
			if ( !IsChildOf( from.Backpack ) )
			{
				from.SendLocalizedMessage( 1042001 );
			}
			else if ( from.AccessLevel >= AccessLevel.GameMaster )
			{
				from.SendLocalizedMessage( 503248 );

				Mobile v = new RoomAttendant( from, BaseHouse.FindHouseAt( from ) );

				v.Direction = from.Direction & Direction.Mask;
				v.MoveToWorld( from.Location, from.Map );

				this.Delete();
			}
			else
			{
				BaseHouse house = BaseHouse.FindHouseAt( from );

				if ( house == null || !house.IsOwner( from ) )
				{
					from.LocalOverheadMessage( MessageType.Regular, 0x3B2, false, "You are not the full owner of this house." );
				}
				else if ( !house.CanPlaceNewBarkeep() )
				{
					from.SendMessage( "This action would exceed the maximum number of barkeeps/room attendants for this house." );
				}
				else
				{
					bool vendor, contract;
					BaseHouse.IsThereVendor( from.Location, from.Map, out vendor, out contract );

					if ( vendor )
					{
						from.SendMessage( "You cannot place a vendor, barkeep, or room attendant at this location." );
					}
					else if ( contract )
					{
						from.SendMessage( "You cannot place a vendor, barkeep, or room attendant on top of a rental contract!" );
					}
					else
					{
						Mobile v = new RoomAttendant( from, house );

						v.Direction = from.Direction & Direction.Mask;
						v.MoveToWorld( from.Location, from.Map );

						this.Delete();
					}
				}
			}
		}
	}
