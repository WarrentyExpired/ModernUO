using System;
using ModernUO.Serialization;
using Server.Network;
using Server.Targeting;
using Server.Items;
using Server.Mobiles;

namespace Server.Items;
[SerializationGenerator(0, false)]
public partial class SquireDeathShroud : BaseOuterTorso
	{
		[Constructible]
		public SquireDeathShroud() : this( 0 )
		{
		}

		[Constructible]
		public SquireDeathShroud( int hue ) : base( 0x204E, hue )
		{
			Weight = 3.0;
			Movable = false;
		}


		

		
	}
