using System;
using ModernUO.Serialization;
using Server;
using Server.Mobiles;
using Server.Network;
using Server.Multis;

namespace Server.Items;
[SerializationGenerator(0, false)]
	public partial class SquireContract : Item
	{

		[Constructible]
		public SquireContract() : base( 0x14F0 )
		{
            Name = "a squire contract";
			Weight = 1.0;
			LootType = LootType.Blessed;
		}


		

		

		public override void OnDoubleClick( Mobile from )
		{
			BaseCreature squi = new Squire();

			if ( !IsChildOf( from.Backpack ) )
			{
				from.SendLocalizedMessage( 1042001 );
				squi.Delete();
			}
			else if ( from.FollowersMax - from.Followers < 3 )
			{
				from.SendMessage( "You don't have 3 free follower slots to have a squire at the moment." );
				squi.Delete();
			}
			else
			{
				squi.Controlled = true;
				squi.ControlMaster = from;
				squi.ControlOrder = OrderType.Follow;
				squi.ControlTarget = from;
				squi.Direction = from.Direction & Direction.Mask;
				squi.MoveToWorld( from.Location, from.Map );

				from.SendMessage( squi.Name + " has arrived, meet your new squire!" );

				this.Delete();
			}
		}
	}
