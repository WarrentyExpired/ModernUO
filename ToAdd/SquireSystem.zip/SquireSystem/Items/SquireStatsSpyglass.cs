using Server.Gumps;
using ModernUO.Serialization;
using Server.Network;
using Server.Mobiles;
using Server.Items;
using Server.Engines.Quests;

using Server.Targeting;

namespace Server.Items;
[SerializationGenerator(0, false)]
	public partial class SquireStatsSpyglass : Item
	{
		[Constructible]
		public SquireStatsSpyglass() : base( 0x14F5 )
		{
			Name = "Squire Inspection Spyglass";
			Weight = 3.0;
		}

		public override void OnDoubleClick( Mobile from )
		{
			from.Target = new SpyglassSTarget();
			from.SendMessage( "Who's stats do you wish to see?" );
		}

		private class SpyglassSTarget : Target
		{
			public SpyglassSTarget() : base( 15, false, TargetFlags.None )
			{
			}

			protected override void OnTarget( Mobile from, object targ )
			{
				if ( targ != null && targ is Squire )
				{
					if ( ( ((BaseCreature)targ).Controlled && ((BaseCreature)targ).ControlMaster == from ) || from.AccessLevel >= AccessLevel.GameMaster || ((Squire)targ)._inspectable )
					{
						from.SendGump( new SquireLoreGump( ((BaseCreature)targ), from, SquireLorePage.Stats ) );
						from.SendMessage( "You check out " + ((BaseCreature)targ).Name + "'s stats." );
					}
					else
					{
						from.SendMessage( ((BaseCreature)targ).Name + " refuses to let you inspect them in this way." );
					}
				}
				else
				{
					from.SendMessage( "That cannot be inspected with this spyglass." );
				}
			}
		}


		

		
	}
