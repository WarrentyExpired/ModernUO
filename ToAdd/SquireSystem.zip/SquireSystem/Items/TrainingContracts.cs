using ModernUO.Serialization;
using Server;
using Server.Mobiles;
using Server.Targeting;

namespace Server.Items;

[SerializationGenerator(0, false)]
public partial class STrainingContract : Item
{
	[Constructible]
	public STrainingContract() : this(1)
	{
	}

	[Constructible]
	public STrainingContract(int amount) : base(0x14F0)
	{
		Weight = 1.0;
		Hue = 401;
		Name = "A Squire Training Contract";
	}

	protected static void UseContractOnSelf(Mobile from, Item contract, SkillName skill)
	{
		if (from is Squire squire)
		{
			if (squire.Skills[skill].Lock == SkillLock.Up)
			{
				TeachSkill(squire, skill, contract);
			}
			else
			{
				squire.ControlMaster?.SendMessage("This squire is not prepared to learn more of this skill.");
			}
		}
		else
		{
			from.Target = new STrainingTarget(from, skill, contract);
		}
	}

	internal static void TeachSkill(Squire squire, SkillName skill, Item contract)
	{
		var skillObj = squire.Skills[skill];

		if (skillObj.Base >= 100.0)
		{
			squire.ControlMaster.SendMessage("Your squire cannot learn more of this skill.");
			return;
		}

		if (skillObj.Base < 30.0)
		{
			SquireDialog.DoSquireDialog(squire, SquireDialogTree.LearnsFromContract);
			skillObj.Base = 30.0;
		}
		else if (skillObj.Base < 50.0)
		{
			skillObj.Base += 15.0;
		}
		else if (skillObj.Base < 75.0)
		{
			skillObj.Base += 5.0;
		}
		else if (skillObj.Base < 90.0)
		{
			skillObj.Base += 2.0;
		}
		else
		{
			skillObj.Base += 1.0;
		}

		if (skillObj.Base > 100.0)
		{
			skillObj.Base = 100.0;
		}

		squire.ControlMaster.SendMessage("Your Squire Learnt Something");
		contract.Delete();
	}
}

[SerializationGenerator(0, false)]
public partial class SWrestlingContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SWrestlingContract()
	{
		Name = "A Wrestling Training Contract";
		_skill = SkillName.Wrestling;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class STacticsContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public STacticsContract()
	{
		Name = "An Tactics Training Contract";
		_skill = SkillName.Tactics;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SMagicResistContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SMagicResistContract()
	{
		Name = "An Magic Resistance Training Contract";
		_skill = SkillName.MagicResist;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add("Magic Resistance" + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SAnatomyContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SAnatomyContract()
	{
		Name = "An Anatomy Training Contract";
		_skill = SkillName.Anatomy;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SSwordsContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SSwordsContract()
	{
		Name = "An Swordsmanship Training Contract";
		_skill = SkillName.Swords;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add("Swordsmanship" + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SMacingContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SMacingContract()
	{
		Name = "An Macefighting Training Contract";
		_skill = SkillName.Macing;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add("Macefighting" + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SFencingContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SFencingContract()
	{
		Name = "An Fencing Training Contract";
		_skill = SkillName.Fencing;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SArcheryContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SArcheryContract()
	{
		Name = "An Archery Training Contract";
		_skill = SkillName.Archery;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SParryContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SParryContract()
	{
		Name = "An Parry Training Contract";
		_skill = SkillName.Parry;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SHealingContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SHealingContract()
	{
		Name = "An Healing Training Contract";
		_skill = SkillName.Healing;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SVeterinaryContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SVeterinaryContract()
	{
		Name = "An Veterinary Training Contract";
		_skill = SkillName.Veterinary;
	}

	public override void OnDoubleClick(Mobile from) => from.Target = new STrainingTarget(from, _skill, this);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SEvalIntContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SEvalIntContract()
	{
		Name = "An Evaluate Intelligence Training Contract";
		_skill = SkillName.EvalInt;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add("Evaluate Intelligence" + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SMeditationContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SMeditationContract()
	{
		Name = "An Meditation Training Contract";
		_skill = SkillName.Meditation;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SAnimalLoreContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SAnimalLoreContract()
	{
		Name = "An Animal Lore Training Contract";
		_skill = SkillName.AnimalLore;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add("Animal Lore" + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SFocusContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SFocusContract()
	{
		Name = "An Focus Training Contract";
		_skill = SkillName.Focus;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SMusicianshipContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SMusicianshipContract()
	{
		Name = "An Musicianship Training Contract";
		_skill = SkillName.Musicianship;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SPeacemakingContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SPeacemakingContract()
	{
		Name = "An Peacemaking Training Contract";
		_skill = SkillName.Peacemaking;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SDiscordanceContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SDiscordanceContract()
	{
		Name = "An Discordance Training Contract";
		_skill = SkillName.Discordance;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SProvocationContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SProvocationContract()
	{
		Name = "An Provocation Training Contract";
		_skill = SkillName.Provocation;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SHidingContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SHidingContract()
	{
		Name = "An Hiding Training Contract";
		_skill = SkillName.Hiding;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SStealingContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SStealingContract()
	{
		Name = "A Stealing Training Contract";
		_skill = SkillName.Stealing;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SLockpickingContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SLockpickingContract()
	{
		Name = "A Lockpicking Training Contract";
		_skill = SkillName.Lockpicking;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SSpiritSpeakContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SSpiritSpeakContract()
	{
		Name = "A Spirit Speak Training Contract";
		_skill = SkillName.SpiritSpeak;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add("Spirit Speak" + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SPoisoningContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SPoisoningContract()
	{
		Name = "An Poisoning Training Contract";
		_skill = SkillName.Poisoning;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SChivalryContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SChivalryContract()
	{
		Name = "An Chivalry Training Contract";
		_skill = SkillName.Chivalry;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}

[SerializationGenerator(0, false)]
public partial class SBushidoContract : STrainingContract
{
	[SerializableField(0)]
	private SkillName _skill;

	[Constructible]
	public SBushidoContract()
	{
		Name = "An Bushido Training Contract";
		_skill = SkillName.Bushido;
	}

	public override void OnDoubleClick(Mobile from) => UseContractOnSelf(from, this, _skill);

	public override void GetProperties(IPropertyList list)
	{
		base.GetProperties(list);

		list.Add(_skill + ": 30");
	}
}
internal class STrainingTarget : Target
{
	private readonly SkillName _skill;
	private readonly Item _contract;

	public STrainingTarget(Mobile from, SkillName skill, Item contract) : base(1, false, TargetFlags.None)
	{
		_skill = skill;
		_contract = contract;
		from.SendMessage($"Choose a squire to teach {_skill}.");
	}

	protected override void OnTarget(Mobile from, object obj)
	{
		DoOnTarget(from, obj, _skill, _contract);
	}

	public static void DoOnTarget(Mobile from, object o, SkillName skill, Item contract)
	{
		if (o is not Mobile)
		{
			from.SendMessage("That cannot learn from a training contract.");
		}
		else if (o is not Squire squire)
		{
			from.SendMessage("This would be a waste of a training contract.");
		}
		else if (!squire.Controlled || squire.ControlMaster != from)
		{
			from.SendMessage("This squire does not belong to you.");
		}
		else if (squire.Skills[skill].Lock != SkillLock.Up)
		{
			from.SendMessage("This squire is not prepared to learn more of this skill.");
		}
		else
		{
			STrainingContract.TeachSkill(squire, skill, contract);
		}
	}
}
