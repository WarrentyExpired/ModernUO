using System;
using Server.Logging;
using ModernUO.Serialization;
using Server.Items;
using Server.Mobiles;

namespace Server.Items;
[SerializationGenerator(0, false)]
	public partial class CarrierPigeon : Item
	{
		private static readonly ILogger logger = LogFactory.GetLogger(typeof(CarrierPigeon));

		[SerializableField(0)]
		private Squire _squire;
		[SerializableField(1)]
		private bool _killTheSquire;


		public CarrierPigeon( Squire s )
		{
			_killTheSquire = true;
			_squire = s;

			Name = ( "Carrier Pigeon: " + s.Name );
			Weight = 3;
			Hue = 1001;
			ItemID = 0x211D;
			LootType = LootType.Blessed;
		}

		public override void OnDoubleClick( Mobile from )
		{
			if ( !Movable )
				return;

			if( !from.InRange( this.GetWorldLocation(), 2 ) )
			{
				from.SendLocalizedMessage( 500486 );
				return;
			}
			else if ( _squire == null || _squire.Deleted )
			{
				from.SendMessage( "Your squire has been sold into slavery." );
				return;
			}
			else if( !from.CheckAlive() )
			{
				from.SendLocalizedMessage( 1060190 );
			}
			else if ( from.AccessLevel < AccessLevel.GameMaster && !_squire.Owners.Contains( from ) )
			{
				from.SendMessage( "This carrier pigeon does not know you." );
				return;
			}
			else if ( from.Followers + _squire.ControlSlots > from.FollowersMax )
			{
				from.SendMessage( "You have too many followers to call your squire." );
				return;
			}
			else
			{
				bool alreadyOwned = _squire.Owners.Contains( from );
				if (!alreadyOwned)
				{
					_squire.Owners.Add( from );
				}

				_squire.SetControlMaster( from );
				_killTheSquire = false;

				_squire.Location = from.Location;
				_squire.Map = from.Map;

				_squire.ControlTarget = from;
				_squire.ControlOrder = OrderType.Follow;

				if ( _squire.Summoned )
					_squire.SummonMaster = from;

				this.Delete();
			}

		}
		public override void OnDelete()
		{
			try
			{
				if ( _killTheSquire )
				{
					_squire.Delete();
				}
			}
			catch
			{
				logger.Error("Error with calling squire back: {0} is being Deleted.  ItemID of:  {1}.", Name, ItemID);
			}
			base.OnDelete();
		}

		

		
	}
