using System;
using System.Collections.Generic;
using Server;
using Server.Collections;
using Server.Items;
using Server.Mobiles;
using Server.Network;
using Server.Misc;
using Server.SkillHandlers;
using Server.Targeting;
using Server.Spells;
using Server.Multis;

namespace Server.Mobiles;

internal static class SquireTargetDiag
{
	public static readonly Server.Logging.ILogger Logger = Server.Logging.LogFactory.GetLogger(typeof(SquireTargetDiag));
}

internal class MountTarget : Target {
	private readonly Squire _squire;

	public MountTarget(Mobile from, Squire squire) : base(1, false, TargetFlags.None) {
		_squire = squire;
		from.SendMessage($"Choose a mount for {_squire.Name} to ride.");
	}

	protected override void OnTarget(Mobile from, object obj) {
		DoOnTarget(from, obj, _squire);
	}

	public static void DoOnTarget(Mobile from, object o, Squire squire) {
		if (o is EtherealMount ethy) {
			if (ethy.Rider != null) {
				from.SendMessage("This ethereal mount is already in use by someone else.");
			}
			else if (!ethy.IsChildOf(from.Backpack)) {
				from.SendMessage("The ethereal mount must be in your pack for you to use it.");
			}
			else {
				ethy.Rider = squire;
			}
		}
		else if (o is BaseMount mount) {
			if (mount.Rider != null) {
				from.SendMessage("This mount is already in use by someone else.");
			}
			else if (mount.ControlMaster != from) {
				from.SendMessage("You do not own this mount.");
			}
			else {
				mount.Rider = squire;
			}
		}
		else {
			from.SendMessage("That is not a mount.");
		}
	}
}

internal class GrabItemTarget : Target {
	private readonly Squire _squire;

	public GrabItemTarget(Mobile from, Squire squire) : base(20, false, TargetFlags.None) {
		_squire = squire;
		from.SendMessage($"What would you like {squire.Name} to grab?");
	}

	protected override void OnTarget(Mobile from, object obj) {
		DoOnTarget(from, obj, _squire);
	}

	public static void DoOnTarget(Mobile from, object o, Squire squire) {
		if (o is not Item item) {
			SquireDialog.DoSquireDialog(squire, SquireDialogTree.SquireCantLiftNotItem, null, null);
			return;
		}

		if (!squire.InRange(item, 2)) {
			SquireDialog.DoSquireDialog(squire, SquireDialogTree.SquireCantReach, null, null);
			return;
		}

		if (!item.Movable) {
			if (item is Corpse) {
				SquireDialog.DoSquireDialog(squire, SquireDialogTree.SquireCantLiftCorpse, null, null);
			}

			return;
		}

		if (!squire._squireBeQuiet) {
			squire.Emote("*Picks the item off of the ground.*");
		}

		var rejected = false;
		var lootAdded = false;

		if (squire.Backpack == null || !squire.Backpack.CheckHold(squire, item, false, true)) {
			rejected = true;
		}
		else {
			squire.NextActionTime = Core.TickCount + 5000;
			squire.Lift(item, item.Amount, out var isRejected, out var reason);

			if (isRejected) {
				rejected = true;
			}
			else {
				squire.Drop(squire, Point3D.Zero);
				lootAdded = true;
			}
		}

		if (lootAdded) {
			squire.PlaySound(0x2E6);
		}

		if (rejected) {
			SquireDialog.DoSquireDialog(squire, SquireDialogTree.SquireCantLiftItem, null, null);
		}
	}
}

internal class LootCorpseTarget : Target {
	private readonly Squire _squire;

	public LootCorpseTarget(Mobile from, Squire squire) : base(20, false, TargetFlags.None) {
		_squire = squire;
		from.SendMessage($"What body would you like {squire.Name} to loot?");
	}

	protected override void OnTarget(Mobile from, object obj) {
		DoOnTarget(from, obj, _squire);
	}

	public static void DoOnTarget(Mobile from, object o, Squire squire) {
		if (o is not Item item) {
			SquireDialog.DoSquireDialog(squire, SquireDialogTree.SquireCantLootNotCorpse, null, null);
			return;
		}

		if (!squire.InRange(item, 2)) {
			SquireDialog.DoSquireDialog(squire, SquireDialogTree.SquireCantReach, null, null);
			return;
		}

		using var items = PooledRefList<Item>.Create();
		using var myItems = PooledRefList<Item>.Create();

		if (item.Movable) {
			SquireDialog.DoSquireDialog(squire, SquireDialogTree.ItemIsNotCorpse, null, null);
		}
		else if (item is Corpse corpse) {
			if (corpse.Owner?.Player == true) {
				SquireDialog.DoSquireDialog(squire, SquireDialogTree.RefusesToLootPlayers, null, null);
			}
			else {
				if (!squire._squireBeQuiet) {
					squire.Emote("*Rummages through items in a corpse.*");
				}

				var targetList = corpse.Owner == squire ? myItems : items;

				foreach (var corpseItem in corpse.Items) {
					targetList.Add(corpseItem);
				}
			}
		}

		var rejected = false;
		var lootAdded = false;

		foreach (var i in items) {
			if (squire.Backpack == null || !squire.Backpack.CheckHold(squire, i, false, true)) {
				rejected = true;
				continue;
			}

			squire.NextActionTime = Core.TickCount + 5000;
			squire.Lift(i, i.Amount, out var isRejected, out var reason);

			if (isRejected) {
				rejected = true;
				continue;
			}

			if (squire.AutoEquipLoot) {
				squire.Drop(squire, Point3D.Zero);
			}
			else {
				squire.Drop(squire.Backpack, new Point3D(Utility.Random(29, 108), Utility.Random(34, 94), 0));
			}

			lootAdded = true;
		}

		foreach (var i in myItems) {
			if (squire.Backpack == null || !squire.Backpack.CheckHold(squire, i, false, true)) {
				rejected = true;
				continue;
			}

			squire.Backpack.DropItem(i);
			lootAdded = true;
		}

		if (lootAdded) {
			squire.PlaySound(0x2E6);
		}

		if (rejected) {
			SquireDialog.DoSquireDialog(squire, SquireDialogTree.SquireCantLootAllItems, null, null);
		}
	}
}

internal class HealTarget : Target {
	private readonly Squire _squire;

	public HealTarget(Mobile from, Squire squire) : base(20, false, TargetFlags.None) {
		_squire = squire;
		from.SendMessage($"Who would you like {squire.Name} to heal?");
	}

	protected override void OnTarget(Mobile from, object obj) {
		DoOnTarget(from, obj, _squire);
	}

	public static void DoOnTarget(Mobile from, object o, Squire squire) {
		if (Core.Now <= squire._delay) {
			if (!squire._squireBeQuiet) {
				squire.Say("Sorry, I'm still finishing healing my current target...");
			}

			return;
		}

		if (o is BaseCreature creature) {
			var humanoid = creature.Body == 0x191 || creature.Body == 0x190 || creature.Body == 0x25D || creature.Body == 0x25E;

			CureHealOrRez(squire, creature,
				humanoid ? SkillName.Healing : SkillName.Veterinary,
				humanoid ? SkillName.Anatomy : SkillName.AnimalLore,
				humanoid ? SquireDialogTree.SquireCuresHumanoid : SquireDialogTree.SquireCuresAnimal,
				SquireDialogTree.SquireHealsWounded,
				humanoid ? SquireDialogTree.SquireRezsHumanoid : SquireDialogTree.SquireRezsAnimal,
				SquireDialogTree.WoundedIsNotHurtEnough,
				SquireDialogTree.WoundedOutOfRange,
				creature, null);
		}
		else if (o is PlayerMobile player) {
			var isMaster = squire.Controlled && squire.ControlMaster != null && player == squire.ControlMaster;

			CureHealOrRez(squire, player,
				SkillName.Healing,
				SkillName.Anatomy,
				isMaster ? SquireDialogTree.SquireCuresMaster : SquireDialogTree.SquireCuresPlayer,
				isMaster ? SquireDialogTree.SquireHealsMaster : SquireDialogTree.SquireHealsPlayer,
				isMaster ? SquireDialogTree.SquireRezsMaster : SquireDialogTree.SquireRezsPlayer,
				SquireDialogTree.WoundedPlayerIsNotHurtEnough,
				SquireDialogTree.WoundedPlayerOutOfRange,
				null, player);
		}
		else {
			SquireDialog.DoSquireDialog(squire, SquireDialogTree.HealingTargetNotCreature);
		}
	}

	private static void CureHealOrRez(Squire squire, Mobile wounded,
		SkillName healSkill, SkillName supportSkill,
		SquireDialogTree cureTree, SquireDialogTree healTree, SquireDialogTree rezTree,
		SquireDialogTree notHurtTree, SquireDialogTree rangeTree,
		BaseCreature creature, PlayerMobile player) {
		if (wounded.Hidden) {
			SquireDialog.DoSquireDialog(squire, SquireDialogTree.WoundedInvisible);
			return;
		}

		if (!squire.InRange(wounded, Bandage.Range)) {
			SquireDialog.DoSquireDialog(squire, rangeTree, creature, player);
			return;
		}

		var isPoisoned = wounded.Alive && wounded.Poisoned;
		var isHurt = wounded.Alive && wounded.Hits < wounded.HitsMax - 5;

		if (!isPoisoned && !isHurt && wounded.Alive) {
			SquireDialog.DoSquireDialog(squire, notHurtTree, creature, player);
			return;
		}

		var item = squire.Backpack.FindItemByType(typeof(Bandage));
		var reqSkill = isPoisoned ? 60.0 : 80.0;

		if (item != null
			&& (isHurt
				|| squire.Skills[healSkill].Value >= reqSkill && squire.Skills[supportSkill].Value >= reqSkill)
			&& BandageContext.BeginHeal(squire, wounded) != null) {
			item.Consume(1);
			squire.RevealingAction();
			SquireDialog.DoSquireDialog(squire, isPoisoned ? cureTree : isHurt ? healTree : rezTree, creature, player);
			squire._delay = Core.Now + TimeSpan.FromSeconds(isPoisoned || isHurt ? 4 : 9);
		}
	}
}

internal class ThrowTarget : Target {
	private readonly Squire _squire;

	public ThrowTarget(Mobile from, Squire squire) : base(20, false, TargetFlags.None) {
		_squire = squire;
		from.SendMessage($"Who would you like {squire.Name} to hit with a snowball?");
	}

	protected override void OnTarget(Mobile from, object obj) {
		DoOnTarget(from, obj, _squire);
	}

	public static void DoOnTarget(Mobile from, object o, Squire squire) {
		if (squire.Mounted) {
			from.SendMessage("Your squire cannot do this while mounted.");
			return;
		}

		if (o is Mobile target && target.Backpack?.FindItemByType(new[] { typeof(SnowPile), typeof(PileOfGlacialSnow) }) != null) {
			from.PlaySound(0x145);
			squire.Animate(9, 1, 1, true, false, 0);
			from.SendMessage($"{squire.Name} throws a snowball and hits the target!");
			Effects.SendMovingEffect(squire, target, 0x36E4, 7, 0, false, true, 0x480, 0);
			squire._throwDelay = Core.Now + TimeSpan.FromSeconds(1);
		}
		else {
			from.SendMessage("Your squire cannot throw a snowball at something that cannot throw one back.");
		}
	}
}

internal class ProvokeTargetOne : Target {
	private readonly BaseInstrument _instrument;
	private readonly Squire _squire;

	public ProvokeTargetOne(Mobile from, Squire squire, BaseInstrument instrument)
		: base(BaseInstrument.GetBardRange(squire, SkillName.Provocation), false, TargetFlags.None) {
		_instrument = instrument;
		_squire = squire;
		SquireDialog.DoSquireDialog(squire, SquireDialogTree.BeginProvoking, null, null);
	}

	protected override void OnTarget(Mobile from, object provokeone) {
		_squire.RevealingAction();

		if (provokeone is BaseCreature creature && _squire.CanBeHarmful(creature, true)) {
			if (!_instrument.IsChildOf(_squire.Backpack)) {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.WheredMyInstrumentGo, null, null);
			}
			else if (creature.Controlled) {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.LoyalToTheirMaster, null, null);
			}
			else if (creature.IsParagon && BaseInstrument.GetBaseDifficulty(creature) >= 160.0) {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.NoChanceToProvoke, null, null);
			}
			else {
				_squire.RevealingAction();
				_instrument.PlayInstrumentWell(_squire);
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CantProvokeOne, null, null);
				from.Target = new ProvokeTargetTwo(from, _squire, _instrument, creature);
			}
		}
		else {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CantInciteAnger, null, null);
		}
	}
}

internal class ProvokeTargetTwo : Target {
	private readonly BaseCreature _creature;
	private readonly BaseInstrument _instrument;
	private readonly Squire _squire;

	public ProvokeTargetTwo(Mobile from, Squire squire, BaseInstrument instrument, BaseCreature creature)
		: base(BaseInstrument.GetBardRange(squire, SkillName.Provocation), false, TargetFlags.None) {
		_instrument = instrument;
		_squire = squire;
		_creature = creature;
	}

	protected override void OnTarget(Mobile from, object provoketwo) {
		_squire.RevealingAction();

		if (provoketwo is not BaseCreature creature) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CantInciteAnger, null, null);
			return;
		}

		if (!_instrument.IsChildOf(_squire.Backpack)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.WheredMyInstrumentGo, null, null);
		}
		else if (_creature.Unprovokable || creature.Unprovokable) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.NoChanceToProvoke, null, null);
		}
		else if (_creature.Map != creature.Map || !_creature.InRange(creature, BaseInstrument.GetBardRange(_squire, SkillName.Provocation))) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.TooFarApartToProvoke, null, null);
		}
		else if (_creature != creature) {
			_squire.NextSkillTime = Core.TickCount + 10 * 1000;

			var diff = (_instrument.GetDifficultyFor(_creature) + _instrument.GetDifficultyFor(creature)) * 0.5 - 5.0;
			var music = _squire.Skills[SkillName.Musicianship].Value;

			if (music > 100.0) {
				diff -= (music - 100.0) * 0.5;
			}

			if (_squire.CanBeHarmful(_creature, true) && _squire.CanBeHarmful(creature, true)) {
				if (!BaseInstrument.CheckMusicianship(_squire)) {
					_squire.NextSkillTime = Core.TickCount + 5 * 1000;
					SquireDialog.DoSquireDialog(_squire, SquireDialogTree.BadPerformance, null, null);
					_instrument.PlayInstrumentBadly(_squire);
					_instrument.ConsumeUse(_squire);
				}
				else if (!_squire.CheckTargetSkill(SkillName.Provocation, creature, diff - 25.0, diff + 25.0)) {
					_squire.NextSkillTime = Core.TickCount + 5 * 1000;
					SquireDialog.DoSquireDialog(_squire, SquireDialogTree.FailedPerformanceProvoke, null, null);
					_instrument.PlayInstrumentBadly(_squire);
					_instrument.ConsumeUse(_squire);
				}
				else {
					SquireDialog.DoSquireDialog(_squire, SquireDialogTree.GoodPerformanceProvoke, null, null);
					_instrument.PlayInstrumentWell(_squire);
					_instrument.ConsumeUse(_squire);
					_creature.Provoke(_squire, creature, true);
				}
			}
		}
		else {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.ProvokeOnThemselves, null, null);
		}
	}
}

internal class SquireDiscordanceTarget : Target {
	private readonly BaseInstrument _instrument;
	private readonly Squire _squire;

	public SquireDiscordanceTarget(Mobile from, Squire squire, BaseInstrument inst)
		: base(BaseInstrument.GetBardRange(squire, SkillName.Discordance), false, TargetFlags.None) {
		_instrument = inst;
		_squire = squire;
	}

	protected override void OnTarget(Mobile from, object target) {
		_squire.RevealingAction();
		_squire.NextSkillTime = Core.TickCount + 1000;

		if (!_instrument.IsChildOf(_squire.Backpack)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.WheredMyInstrumentGo, null, null);
		}
		else if (target is not Mobile targ) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CantDiscord, null, null);
		}
		else {
			var discordEffect = 0;

			if (targ == _squire || targ == from
				|| targ is BaseCreature && (((BaseCreature)targ).BardImmune || !_squire.CanBeHarmful(targ, false))
					&& ((BaseCreature)targ).ControlMaster != from) {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CantDiscord, null, null);
			}
			else if (Discordance.GetEffect(targ, ref discordEffect)) {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.AlreadyDiscord, null, null);
			}
			else if (targ.Player) {
				_instrument.PlayInstrumentBadly(_squire);
			}
			else {
				ApplyDiscordance(from, targ);
			}
		}
	}

	private void ApplyDiscordance(Mobile from, Mobile targ) {
		var len = TimeSpan.FromSeconds(_squire.Skills[SkillName.Discordance].Value * 2);
		var diff = _instrument.GetDifficultyFor(targ) - 10.0;
		var music = _squire.Skills[SkillName.Musicianship].Value;

		if (music > 100.0) {
			diff -= (music - 100.0) * 0.5;
		}

		if (!BaseInstrument.CheckMusicianship(_squire)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.BadPerformance, null, null);
			_instrument.PlayInstrumentBadly(_squire);
			_instrument.ConsumeUse(_squire);
		}
		else if (!_squire.CheckTargetSkill(SkillName.Discordance, targ, diff - 25.0, diff + 25.0)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.FailedPerformanceDiscord, null, null);
			_instrument.PlayInstrumentBadly(_squire);
			_instrument.ConsumeUse(_squire);
		}
		else {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.GoodPerformanceDiscord, null, null);
			_instrument.PlayInstrumentWell(_squire);
			_instrument.ConsumeUse(_squire);

			int effect;
			double scalar;
			var mods = new List<object>();

			if (Core.AOS) {
				var discord = _squire.Skills[SkillName.Discordance].Value;
				effect = discord > 100.0 ? -20 + (int)((discord - 100.0) / -2.5) : (int)(discord / -5.0);

				if (Core.SE && BaseInstrument.GetBaseDifficulty(targ) >= 160.0) {
					effect /= 2;
				}

				scalar = effect * 0.01;

				var rm = new ResistanceMod(ResistanceType.Physical, "Discordance", effect);
				targ.AddResistanceMod(rm);
				mods.Add(rm);
				rm = new ResistanceMod(ResistanceType.Fire, "Discordance", effect);
				targ.AddResistanceMod(rm);
				mods.Add(rm);
				rm = new ResistanceMod(ResistanceType.Cold, "Discordance", effect);
				targ.AddResistanceMod(rm);
				mods.Add(rm);
				rm = new ResistanceMod(ResistanceType.Poison, "Discordance", effect);
				targ.AddResistanceMod(rm);
				mods.Add(rm);
				rm = new ResistanceMod(ResistanceType.Energy, "Discordance", effect);
				targ.AddResistanceMod(rm);
				mods.Add(rm);
			}
			else {
				effect = (int)(_squire.Skills[SkillName.Discordance].Value / -5.0);
				scalar = effect * 0.01;

				var sm = new StatMod(StatType.Str, "DiscordanceStr", (int)(targ.RawStr * scalar), TimeSpan.Zero);
				targ.AddStatMod(sm);
				mods.Add(sm);
				sm = new StatMod(StatType.Int, "DiscordanceInt", (int)(targ.RawInt * scalar), TimeSpan.Zero);
				targ.AddStatMod(sm);
				mods.Add(sm);
				sm = new StatMod(StatType.Dex, "DiscordanceDex", (int)(targ.RawDex * scalar), TimeSpan.Zero);
				targ.AddStatMod(sm);
				mods.Add(sm);
			}

			for (var i = 0; i < targ.Skills.Length; ++i) {
				var skill = targ.Skills[i];

				if (skill.Value > 0.0) {
					var dm = new DefaultSkillMod(skill.SkillName, "Discordance", true, skill.Value * scalar);
					targ.AddSkillMod(dm);
					mods.Add(dm);
				}
			}

			TimerExecutionToken discordToken = default;
			var discordEnd = Core.Now + len;

			Timer.StartTimer(TimeSpan.Zero, TimeSpan.FromSeconds(1.25), () => {
				if (targ.Deleted || !_squire.Alive || _squire.Hidden || Core.Now >= discordEnd) {
					foreach (var mod in mods) {
						if (mod is ResistanceMod resistanceMod) {
							targ.RemoveResistanceMod(resistanceMod);
						}
						else if (mod is StatMod statMod) {
							targ.RemoveStatMod(statMod);
						}
						else if (mod is SkillMod skillMod) {
							targ.RemoveSkillMod(skillMod);
						}
					}

					discordToken.Cancel();
				}
				else {
					targ.FixedEffect(0x376A, 1, 32);
				}
			}, out discordToken);
		}

		_squire.NextSkillTime = Core.TickCount + 12 * 1000;
	}
}

internal class SquirePeacemakingTarget : Target {
	private readonly BaseInstrument _instrument;
	private bool _setSkillTime = true;
	private readonly Squire _squire;

	public SquirePeacemakingTarget(Mobile from, Squire squire, BaseInstrument instrument)
		: base(BaseInstrument.GetBardRange(squire, SkillName.Peacemaking), false, TargetFlags.None) {
		_instrument = instrument;
		_squire = squire;
	}

	protected override void OnTargetFinish(Mobile from) {
		if (_setSkillTime) {
			from.NextSkillTime = Core.TickCount;
		}
	}

	protected override void OnTarget(Mobile from, object targeted) {
		from.RevealingAction();

		if (targeted is not Mobile targ) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CantCalm, null, null);
		}
		else if (!_instrument.IsChildOf(_squire.Backpack)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.WheredMyInstrumentGo, null, null);
		}
		else if (targeted == from || targeted == _squire) {
			PeaceArea(from);
		}
		else {
			PeaceTarget(targ);
		}
	}

	private void PeaceArea(Mobile from) {
		_setSkillTime = false;
		_squire.NextSkillTime = Core.TickCount + 10 * 1000;

		if (!BaseInstrument.CheckMusicianship(_squire)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.BadPerformance, null, null);
			_instrument.PlayInstrumentBadly(_squire);
			_instrument.ConsumeUse(_squire);
		}
		else if (!_squire.CheckSkill(SkillName.Peacemaking, 0.0, 120.0)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.BadPerformance, null, null);
			_instrument.PlayInstrumentBadly(_squire);
			_instrument.ConsumeUse(_squire);
		}
		else {
			_squire.NextSkillTime = Core.TickCount + 5 * 1000;
			_instrument.PlayInstrumentWell(_squire);
			_instrument.ConsumeUse(_squire);

			if (_squire.Map == null) {
				return;
			}

			var calmed = false;
			var range = BaseInstrument.GetBardRange(_squire, SkillName.Peacemaking);

			foreach (var m in _squire.GetMobilesInRange(range)) {
				if (m == from || m == _squire || !_squire.CanBeHarmful(m, false)
					|| m is BaseCreature { Uncalmable: true } or BaseCreature { AreaPeaceImmune: true }) {
					continue;
				}

				calmed = true;

				m.SendLocalizedMessage(500616);
				m.Combatant = null;
				m.Warmode = false;

				if (m is BaseCreature bc && !bc.BardPacified) {
					bc.Pacify(_squire, Core.Now + TimeSpan.FromSeconds(1.0));
				}
			}

			SquireDialog.DoSquireDialog(_squire, calmed ? SquireDialogTree.GoodPerformancePeace : SquireDialogTree.PeaceNobody, null, null);
		}
	}

	private void PeaceTarget(Mobile targ) {
		_setSkillTime = false;
		_squire.NextSkillTime = Core.TickCount + 10 * 1000;

		if (!_squire.CanBeHarmful(targ, false)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CantCalm, null, null);
			_setSkillTime = true;
		}
		else if (targ is BaseCreature { Uncalmable: true }) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.NoChanceToCalm, null, null);
			_setSkillTime = true;
		}
		else if (targ is BaseCreature { BardPacified: true }) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.AlreadyCalmed, null, null);
			_setSkillTime = true;
		}
		else if (!BaseInstrument.CheckMusicianship(_squire)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.BadPerformance, null, null);
			_squire.NextSkillTime = Core.TickCount + 5 * 1000;
			_instrument.PlayInstrumentBadly(_squire);
			_instrument.ConsumeUse(_squire);
		}
		else {
			var diff = _instrument.GetDifficultyFor(targ) - 10.0;
			var music = _squire.Skills[SkillName.Musicianship].Value;

			if (music > 100.0) {
				diff -= (music - 100.0) * 0.5;
			}

			if (!_squire.CheckTargetSkill(SkillName.Peacemaking, targ, diff - 25.0, diff + 25.0)) {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.BadPerformance, null, null);
				_instrument.PlayInstrumentBadly(_squire);
				_instrument.ConsumeUse(_squire);
			}
			else {
				_instrument.PlayInstrumentWell(_squire);
				_instrument.ConsumeUse(_squire);
				_squire.NextSkillTime = Core.TickCount + 5 * 1000;
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.GoodPerformancePeace, null, null);

				if (targ is BaseCreature bc) {
					targ.Combatant = null;
					targ.Warmode = false;

					var seconds = 100 - diff / 1.5;

					if (seconds > 120) {
						seconds = 120;
					}
					else if (seconds < 10) {
						seconds = 10;
					}

					bc.Pacify(_squire, Core.Now + TimeSpan.FromSeconds(seconds));
				}
				else {
					targ.SendLocalizedMessage(500616);
					targ.Combatant = null;
					targ.Warmode = false;
				}
			}
		}
	}
}

internal class SquireStealingTarget : Target {
	private readonly Mobile _from;
	private readonly Squire _squire;

	public SquireStealingTarget(Mobile from, Squire squire) : base(20, false, TargetFlags.None) {
		_from = from;
		_squire = squire;
		AllowNonlocal = true;
	}

	private Item TryStealItem(Item toSteal, ref bool caught) {
		Item stolen = null;
		object root = toSteal.RootParent;

		if (!Stealing.IsEmptyHanded(_squire)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.HandsAreFull, null, null);
		}
		else if (root is Mobile mobileRoot0 && mobileRoot0.Player && !Stealing.IsInGuild(_from)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.NotAPartOfThievesGuild, null, null);
		}
		else if (Stealing.SuspendOnMurder && root is Mobile mobileRoot1 && mobileRoot1.Player
			&& Stealing.IsInGuild(_from) && _from.Kills > 0) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.SuspendedFromThievesGuild, null, null);
		}
		else if (root is BaseVendor { IsInvulnerable: true }) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CannotStealFromVendors, null, null);
		}
		else if (root is PlayerVendor) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CannotStealFromVendors, null, null);
		}
		else if (!_squire.CanSee(toSteal)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CannotSeeStealingTarget, null, null);
		}
		else if (_squire.Backpack == null || !_squire.Backpack.CheckHold(_squire, toSteal, false, true)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.FullBackpackStealing, null, null);
		}
		else if (toSteal.Parent == null || !toSteal.Movable) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CannotStealThat, null, null);
		}
		else if (toSteal.LootType == LootType.Newbied || root is Mobile mobileRoot2 && toSteal.CheckBlessed(mobileRoot2)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CannotStealThat, null, null);
		}
		else if (Core.AOS && toSteal is Container) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CannotStealThat, null, null);
		}
		else if (!_squire.InRange(toSteal.GetWorldLocation(), 1)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.NeedToBeCloserToSteal, null, null);
		}
		else if (toSteal.Parent is Mobile) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CannotStealFromTheirHands, null, null);
		}
		else if (root == _squire) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.StealFromSelf, null, null);
		}
		else if (root is Mobile mobileRoot3 && mobileRoot3.AccessLevel > AccessLevel.Player) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CannotStealThat, null, null);
		}
		else if (root is Mobile mobileRoot4 && !_squire.CanBeHarmful(mobileRoot4)) {
		}
		else if (root is Corpse) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CannotStealThat, null, null);
		}
		else {
			stolen = StealItem(toSteal, ref caught);
		}

		_squire._stealingDelay = Core.Now + TimeSpan.FromSeconds(10);
		return stolen;
	}

	private Item StealItem(Item toSteal, ref bool caught) {
		var w = toSteal.Weight + toSteal.TotalWeight;

		if (w > 10) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.TooHeavyToSteal, null, null);
			return null;
		}

		Item stolen = null;

		if (toSteal.Stackable && toSteal.Amount > 1) {
			var maxAmount = (int)(_squire.Skills[SkillName.Stealing].Value / 10.0 / toSteal.Weight);

			if (maxAmount < 1) {
				maxAmount = 1;
			}
			else if (maxAmount > toSteal.Amount) {
				maxAmount = toSteal.Amount;
			}

			var amount = Utility.RandomMinMax(1, maxAmount);

			if (amount >= toSteal.Amount) {
				var pileWeight = (int)Math.Ceiling(toSteal.Weight * toSteal.Amount) * 10;

				if (_squire.CheckTargetSkill(SkillName.Stealing, toSteal, pileWeight - 22.5, pileWeight + 27.5)) {
					stolen = toSteal;
				}
			}
			else {
				var pileWeight = (int)Math.Ceiling(toSteal.Weight * amount) * 10;

				if (_squire.CheckTargetSkill(SkillName.Stealing, toSteal, pileWeight - 22.5, pileWeight + 27.5)) {
					stolen = Mobile.LiftItemDupe(toSteal, toSteal.Amount - amount) ?? toSteal;
				}
			}
		}
		else {
			var iw = (int)Math.Ceiling(w) * 10;

			if (_squire.CheckTargetSkill(SkillName.Stealing, toSteal, iw - 22.5, iw + 27.5)) {
				stolen = toSteal;
			}
		}

		SquireDialog.DoSquireDialog(_squire, stolen != null
			? SquireDialogTree.SuccessfulSteal
			: SquireDialogTree.UnsuccessfulSteal, null, null);

		caught = _squire.Skills[SkillName.Stealing].Value < Utility.Random(150);
		return stolen;
	}

	protected override void OnTarget(Mobile from, object target) {
		_squire.RevealingAction();

		Item stolen = null;
		object root = null;
		var caught = false;

		if (target is Item item) {
			root = item.RootParent;
			stolen = TryStealItem(item, ref caught);
		}
		else if (target is Mobile mobile) {
			var pack = mobile.Backpack;

			if (pack?.Items.Count > 0) {
				root = target;
				stolen = TryStealItem(pack.Items[Utility.Random(pack.Items.Count)], ref caught);
			}
		}
		else {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CannotStealThat, null, null);
		}

		if (stolen != null) {
			_squire.AddToBackpack(stolen);

			if (stolen is not Container && !stolen.Stackable) {
				StolenItem.Add(stolen, _squire, root as Mobile);
			}
		}

		if (caught) {
			if (root == null) {
				_squire.CriminalAction(false);
			}
			else if (root is Corpse corpse && corpse.IsCriminalAction(_squire)) {
				_squire.CriminalAction(false);
			}
			else if (root is Mobile mobRoot) {
				if (!Stealing.IsInGuild(mobRoot) && Stealing.IsInnocentTo(_squire, mobRoot)) {
					_squire.CriminalAction(false);
				}

				var message = $"You notice {_squire.Name} trying to steal from {mobRoot.Name}.";

				foreach (var ns in _squire.GetClientsInRange(8)) {
					if (ns.Mobile != _squire) {
						ns.Mobile.SendMessage(message);
					}
				}
			}
		}
		else if (root is Corpse corpseRoot && corpseRoot.IsCriminalAction(_squire)) {
			_squire.CriminalAction(false);
		}

		if (root is Mobile rootMob && rootMob.Player && from is PlayerMobile pm && Stealing.IsInnocentTo(from, rootMob)
			&& !Stealing.IsInGuild(rootMob)) {
			pm.PermaFlags.Add(rootMob);
			pm.Delta(MobileDelta.Noto);
		}
	}
}

internal class SquireLockpickTarget : Target {
	private readonly Lockpick _item;
	private readonly Squire _squire;

	public SquireLockpickTarget(Squire squire, Lockpick item) : base(20, false, TargetFlags.None) {
		_item = item;
		_squire = squire;
	}

	protected override void OnTarget(Mobile from, object targeted) {
		if (_item.Deleted) {
			return;
		}

		if (targeted is ILockpickable lockpickable && targeted is Item item) {
			_squire.Direction = _squire.GetDirectionTo(item);

			if (!_squire.InRange(item.GetWorldLocation(), 1)) {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.LockpickTooFar, null, null);
			}
			else if (lockpickable.Locked) {
				_squire.PlaySound(0x241);
				new InternalTimer(from, _squire, lockpickable, _item).Start();
			}
			else {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.NotLocked, null, null);
			}
		}
		else {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.CannotUnlock, null, null);
		}
	}

	private class InternalTimer : Timer {
		private readonly Mobile _from;
		private readonly ILockpickable _item;
		private readonly Lockpick _lockpick;
		private readonly Squire _squire;

		public InternalTimer(Mobile from, Squire squire, ILockpickable item, Lockpick lockpick) : base(TimeSpan.FromSeconds(3.0)) {
			_from = from;
			_squire = squire;
			_item = item;
			_lockpick = lockpick;
		}

		private void BrokeLockPickTest() {
			if (Utility.Random(4) == 0) {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.BrokenLockpick, null, null);
				_squire.PlaySound(0x3A4);
				_lockpick.Consume();
			}
		}

		protected override void OnTick() {
			var item = (Item)_item;

			if (!_squire.InRange(item.GetWorldLocation(), 1)) {
				return;
			}

			if (_item.LockLevel == 0 || _item.LockLevel == -255) {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.AbnormalLock, null, null);
				return;
			}

			if (_squire.Skills[SkillName.Lockpicking].Value < _item.RequiredSkill) {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.HardLock, null, null);
				return;
			}

			if (_squire.CheckTargetSkill(SkillName.Lockpicking, _item, _item.LockLevel, _item.MaxLockLevel)) {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.SuccessfulLockpick, null, null);
				_squire.PlaySound(0x4A);
				_item.LockPick(_squire);
			}
			else {
				BrokeLockPickTest();
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.UnsuccessfulLockpick, null, null);
			}
		}
	}
}

internal class SquirePoisonTarget : Target {
	private readonly Mobile _from;
	private readonly Squire _squire;

	public SquirePoisonTarget(Mobile from, Squire squire) : base(20, false, TargetFlags.None) {
		_squire = squire;
		_from = from;
	}

	protected override void OnTarget(Mobile from, object targeted) {
		if (targeted is not Item item) {
			return;
		}

		if ((item.IsChildOf(from.Backpack) && _squire.InRange(_squire.ControlMaster, 2))
			|| item.IsChildOf(_squire.Backpack)) {
			if (targeted is BasePoisonPotion potion) {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.ApplyPoisonTo, null, null);
				from.Target = new SquirePoisoningTarget(potion, _from, _squire);
			}
			else {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.NotAPoisonPotion, null, null);
			}
		}
		else if (item.IsChildOf(from.Backpack) && !_squire.InRange(_squire.ControlMaster, 2)) {
			SquireDialog.DoSquireDialog(_squire, SquireDialogTree.TooFarToPoison, null, null);
		}
	}

	private class SquirePoisoningTarget : Target {
		private readonly Mobile _from;
		private readonly BasePoisonPotion _potion;
		private readonly Squire _squire;

		public SquirePoisoningTarget(BasePoisonPotion potion, Mobile from, Squire squire) : base(20, false, TargetFlags.None) {
			_potion = potion;
			_from = from;
			_squire = squire;
		}

		protected override void OnTarget(Mobile from, object targeted) {
			if (_potion.Deleted || targeted is not Item item) {
				return;
			}

			if ((item.IsChildOf(from.Backpack) && _squire.InRange(_squire.ControlMaster, 2))
				|| item.IsChildOf(_squire.Backpack)) {
				var startTimer = false;

				if (targeted is Food or FukiyaDarts or Shuriken) {
					startTimer = true;
				}
				else if (targeted is BaseWeapon weapon) {
					if (Core.AOS) {
						startTimer = weapon.PrimaryAbility == WeaponAbility.InfectiousStrike
							|| weapon.SecondaryAbility == WeaponAbility.InfectiousStrike;
					}
					else {
						startTimer = weapon.Layer == Layer.OneHanded
							&& (weapon.Type == WeaponType.Slashing || weapon.Type == WeaponType.Piercing);
					}
				}

				if (startTimer) {
					new SquirePoisonTimer(_squire, _from, item, _potion).Start();
					_squire.PlaySound(0x4F);
					_potion.Consume();
					_squire.AddToBackpack(new Bottle());
				}
				else {
					SquireDialog.DoSquireDialog(_squire, Core.AOS
						? SquireDialogTree.CannotPoisonNotInfectious
						: SquireDialogTree.CannotPoisonNotBPFoD, null, null);
				}
			}
			else if (item.IsChildOf(from.Backpack) && !_squire.InRange(_squire.ControlMaster, 2)) {
				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.TooFarToPoison, null, null);
			}
		}

		private class SquirePoisonTimer : Timer {
			private readonly Mobile _from;
			private readonly double _maxSkill;
			private readonly double _minSkill;
			private readonly Poison _poison;
			private readonly Squire _squire;
			private readonly Item _target;

			public SquirePoisonTimer(Squire squire, Mobile from, Item target, BasePoisonPotion potion) : base(TimeSpan.FromSeconds(2.0)) {
				_squire = squire;
				_from = from;
				_target = target;
				_poison = potion.Poison;
				_minSkill = potion.MinPoisoningSkill;
				_maxSkill = potion.MaxPoisoningSkill;
			}

			protected override void OnTick() {
				if (!_squire.CheckTargetSkill(SkillName.Poisoning, _target, _minSkill, _maxSkill)) {
					if (_squire.Skills[SkillName.Poisoning].Base < 80.0 && Utility.Random(20) == 0) {
						SquireDialog.DoSquireDialog(_squire, SquireDialogTree.TerribleMistake, null, null);
						_squire.ApplyPoison(_squire, _poison);
					}
					else {
						SquireDialog.DoSquireDialog(_squire, SquireDialogTree.PoisoningFailure, null, null);
					}

					return;
				}

				switch (_target) {
					case Food food:
						food.Poison = _poison;
						break;
					case BaseWeapon weapon:
						weapon.Poison = _poison;
						weapon.PoisonCharges = 18 - _poison.Level * 2;
						break;
					case FukiyaDarts darts:
						darts.Poison = _poison;
						darts.PoisonCharges = Math.Min(18 - _poison.Level * 2, darts.UsesRemaining);
						break;
					case Shuriken shuriken:
						shuriken.Poison = _poison;
						shuriken.PoisonCharges = Math.Min(18 - _poison.Level * 2, shuriken.UsesRemaining);
						break;
				}

				SquireDialog.DoSquireDialog(_squire, SquireDialogTree.PoisoningSuccess, null, null);
				Misc.Titles.AwardKarma(_squire, -20, true);
			}
		}
	}
}

internal class SquireCleanseDelayTimer : Timer {
	private readonly Mobile _from;
	private readonly Squire _squire;

	public SquireCleanseDelayTimer(Squire squire, Mobile from, TimeSpan delay) : base(delay) {
		_squire = squire;
		_from = from;
	}

	protected override void OnTick() {
		_from.Target = new SquirePassCleanseTarget(_from, _squire);
	}
}

internal class SquireCloseWoundsDelayTimer : Timer {
	private readonly Mobile _from;
	private readonly Squire _squire;

	public SquireCloseWoundsDelayTimer(Squire squire, Mobile from, TimeSpan delay) : base(delay) {
		_squire = squire;
		_from = from;
	}

	protected override void OnTick() {
		_from.Target = new SquirePassCloseWoundsTarget(_from, _squire);
	}
}

internal class SquireRemoveCurseDelayTimer : Timer {
	private readonly Mobile _from;
	private readonly Squire _squire;

	public SquireRemoveCurseDelayTimer(Squire squire, Mobile from, TimeSpan delay) : base(delay) {
		_squire = squire;
		_from = from;
	}

	protected override void OnTick() {
		_from.Target = new SquirePassRemoveCurseTarget(_from, _squire);
	}
}

internal class SquireSacredJourneyDelayTimer : Timer {
	private readonly Mobile _from;
	private readonly Squire _squire;

	public SquireSacredJourneyDelayTimer(Squire squire, Mobile from, TimeSpan delay) : base(delay) {
		_squire = squire;
		_from = from;
	}

	protected override void OnTick() {
		_from.Target = new SquirePassSacredJourneyTarget(_from, _squire);
	}
}

internal class SquireSelfCloseWoundsDelayTimer : Timer {
	private readonly Squire _squire;

	public SquireSelfCloseWoundsDelayTimer(Squire squire, TimeSpan delay) : base(delay) {
		_squire = squire;
	}

	protected override void OnTick() {
		_squire.Target?.Invoke(_squire, _squire);
	}
}

internal class SquireSelfCleanseByFireDelayTimer : Timer {
	private readonly Squire _squire;

	public SquireSelfCleanseByFireDelayTimer(Squire squire, TimeSpan delay) : base(delay) {
		_squire = squire;
	}

	protected override void OnTick() {
		_squire.Target?.Invoke(_squire, _squire);
	}
}

internal class SquirePassExplosionPotionTarget : Target {
	private readonly Squire _squire;

	public SquirePassExplosionPotionTarget(Mobile from, Squire squire) : base(20, false, TargetFlags.Beneficial) {
		_squire = squire;
	}

	protected override void OnTarget(Mobile from, object o) {
		DoOnTarget(from, o, _squire);
	}

	public static void DoOnTarget(Mobile from, object o, Squire squire) {
		squire.Target?.Invoke(squire, o);
	}
}

internal class SquireTargetCloseWoundsDelayTimer : Timer {
	private readonly Squire _squire;
	private readonly Mobile _target;

	public SquireTargetCloseWoundsDelayTimer(Squire squire, Mobile target, TimeSpan delay) : base(delay) {
		_squire = squire;
		_target = target;
	}

	protected override void OnTick() {
		_squire.Target?.Invoke(_squire, _target);
	}
}

internal class SquireTargetCleanseByFireDelayTimer : Timer {
	private readonly Squire _squire;
	private readonly Mobile _target;

	public SquireTargetCleanseByFireDelayTimer(Squire squire, Mobile target, TimeSpan delay) : base(delay) {
		_squire = squire;
		_target = target;
	}

	protected override void OnTick() {
		_squire.Target?.Invoke(_squire, _target);
	}
}

internal class SquirePainSpikeDelayTimer : Timer {
	private readonly Mobile _from;
	private readonly Squire _squire;

	public SquirePainSpikeDelayTimer(Squire squire, Mobile from, TimeSpan delay) : base(delay) {
		_squire = squire;
		_from = from;
	}

	protected override void OnTick() {
		_from.Target = new SquirePassPainSpikeTarget(_from, _squire);
	}
}

internal class SquirePoisonStrikeDelayTimer : Timer {
	private readonly Mobile _from;
	private readonly Squire _squire;

	public SquirePoisonStrikeDelayTimer(Squire squire, Mobile from, TimeSpan delay) : base(delay) {
		_squire = squire;
		_from = from;
	}

	protected override void OnTick() {
		_from.Target = new SquirePassPoisonStrikeTarget(_from, _squire);
	}
}

internal class SquirePassCleanseTarget : Target {
	private readonly Squire _squire;

	public SquirePassCleanseTarget(Mobile from, Squire squire) : base(20, false, TargetFlags.Beneficial) {
		_squire = squire;
	}

	protected override void OnTarget(Mobile from, object o) {
		DoOnTarget(from, o, _squire);
	}

	public static void DoOnTarget(Mobile from, object o, Squire squire) {
		if (o is Mobile m) {
			if (!m.Poisoned) {
				from.SendLocalizedMessage(1060176);
			}
			else {
				squire.Target?.Invoke(squire, o);
			}
		}
		else {
			from.SendMessage("This cannot be cleansed by fire.");
		}
	}
}

internal class SquirePassCloseWoundsTarget : Target {
	private readonly Squire _squire;

	public SquirePassCloseWoundsTarget(Mobile from, Squire squire) : base(20, false, TargetFlags.Beneficial) {
		_squire = squire;
	}

	protected override void OnTarget(Mobile from, object o) {
		DoOnTarget(from, o, _squire);
	}

	public static void DoOnTarget(Mobile from, object o, Squire squire) {
		if (o is not Mobile m) {
			from.SendMessage("This cannot have its wounds closed.");
			return;
		}

		if (!squire.InRange(m, 2)) {
			from.SendLocalizedMessage(1060178);
		}
		else if (m is BaseCreature { IsAnimatedDead: true }) {
			from.SendLocalizedMessage(1061654);
		}
		else if (m is BaseCreature { IsDeadBondedPet: true }) {
			from.SendLocalizedMessage(1060177);
		}
		else if (m.Hits >= m.HitsMax) {
			from.SendLocalizedMessage(500955);
		}
		else if (m.Poisoned || MortalStrike.IsWounded(m)) {
			from.LocalOverheadMessage(MessageType.Regular, 0x3B2, from == m ? 1005000 : 1010398);
		}
		else {
			squire.Target?.Invoke(squire, o);
		}
	}
}

internal class SquirePassRemoveCurseTarget : Target {
	private readonly Squire _squire;

	public SquirePassRemoveCurseTarget(Mobile from, Squire squire) : base(20, false, TargetFlags.Beneficial) {
		_squire = squire;
	}

	protected override void OnTarget(Mobile from, object o) {
		DoOnTarget(from, o, _squire);
	}

	public static void DoOnTarget(Mobile from, object o, Squire squire) {
		squire.Target?.Invoke(squire, o);
	}
}

internal class SquirePassSacredJourneyTarget : Target {
	private readonly Squire _squire;

	public SquirePassSacredJourneyTarget(Mobile from, Squire squire) : base(20, false, TargetFlags.Beneficial) {
		_squire = squire;
	}

	protected override void OnTarget(Mobile from, object o) {
		DoOnTarget(from, o, _squire);
	}

	public static void DoOnTarget(Mobile from, object o, Squire squire) {
		if (o is RecallRune or Runebook
			|| o is Key { KeyValue: not 0, Link: BaseBoat }
			|| o is HouseRaffleDeed deed && deed.ValidLocation()) {
			squire.Target?.Invoke(squire, o);
		}
		else {
			from.SendMessage("They cannot travel from this.");
		}
	}
}

internal class SquirePassPainSpikeTarget : Target {
	private readonly Squire _squire;

	public SquirePassPainSpikeTarget(Mobile from, Squire squire) : base(20, false, TargetFlags.None) {
		_squire = squire;
	}

	protected override void OnTarget(Mobile from, object o) {
		DoOnTarget(from, o, _squire);
	}

	public static void DoOnTarget(Mobile from, object o, Squire squire) {
		if (o is Mobile) {
			squire.Target?.Invoke(squire, o);
		}
		else {
			from.SendMessage("This cannot be attacked.");
		}
	}
}

internal class SquirePassPoisonStrikeTarget : Target {
	private readonly Squire _squire;

	public SquirePassPoisonStrikeTarget(Mobile from, Squire squire) : base(20, false, TargetFlags.None) {
		_squire = squire;
	}

	protected override void OnTarget(Mobile from, object o) {
		DoOnTarget(from, o, _squire);
	}

	public static void DoOnTarget(Mobile from, object o, Squire squire) {
		if (o is Mobile) {
			squire.Target?.Invoke(squire, o);
		}
		else {
			from.SendMessage("This cannot be attacked.");
		}
	}
}
