using System;
using Server;
using Server.Gumps;
using Server.Mobiles;
using Server.Network;
using SquireCommands = Server.Mobiles.Squire.SquireCommands;

namespace Server.Gumps;

public class SquireCommandGump : Gump
{
	public override bool Singleton => true;

	private const int CYellow = 2213;
	private const int CWhite = 2036;

	private const int ButtonArrow = 0x2716;
	private const int ButtonInfo = 0x9CF;

	private const int GumpWidth = 660;
	private const int TabY = 50;
	private const int ItemStep = 22;
	private const int C1X = 40;
	private const int C2X = 350;

	private static readonly (string Title, (string Label, SquireCommands Command)[] Items)[] _cats =
	[
		("General",
		[
			("Stop", SquireCommands.Stop),
			("Stay here", SquireCommands.Stay),
			("Follow me", SquireCommands.FollowMe),
			("Come here", SquireCommands.Come),
			("Guard (target)", SquireCommands.Guard),
			("Guard me", SquireCommands.GuardMe),
			("Mount", SquireCommands.Mount),
			("Dismount", SquireCommands.Dismount),
			("Open backpack", SquireCommands.Backpack),
			("Be quiet", SquireCommands.BeQuiet),
			("Talk again", SquireCommands.TalkAgain),
			("Meditate", SquireCommands.Meditate)
		]),
		("Combat",
		[
			("Attack (target)", SquireCommands.Attack),
			("Kill (target)", SquireCommands.Kill),
			("Heal (target)", SquireCommands.Heal),
			("Throw snowball", SquireCommands.Throw),
			("Throw explosion potion", SquireCommands.ThrowExplosion),
			("Weapon ability", SquireCommands.WeaponAbility),
			("Poison weapon", SquireCommands.Poison),
			("Provoke", SquireCommands.Provoke),
			("Discordance", SquireCommands.Discord),
			("Peacemaking", SquireCommands.MakePeace),
			("Hide", SquireCommands.Hide),
			("Spirit speak", SquireCommands.SpiritSpeak)
		]),
		("Equipment",
		[
			("Dress from pack", SquireCommands.Dress),
			("Undress all", SquireCommands.Undress),
			("Arm weapon", SquireCommands.Arm),
			("Unarm", SquireCommands.Unarm),
			("Equip quiver", SquireCommands.Quiver),
			("Save set 1", SquireCommands.CreateSetOne),
			("Equip set 1", SquireCommands.EquipSetOne),
			("Save set 2", SquireCommands.CreateSetTwo),
			("Equip set 2", SquireCommands.EquipSetTwo),
			("Save set 3", SquireCommands.CreateSetThree),
			("Equip set 3", SquireCommands.EquipSetThree)
		]),
		("Looting",
		[
			("Grab (target)", SquireCommands.Grab),
			("Grab all", SquireCommands.GrabAll),
			("Loot (target)", SquireCommands.Loot),
			("Loot all", SquireCommands.LootAll),
			("Unload loot", SquireCommands.Unload),
			("Steal (target)", SquireCommands.Steal),
			("Lockpick (target)", SquireCommands.Lockpick)
		]),
		("Info",
		[
			("Skills", SquireCommands.Skills),
			("Stats", SquireCommands.Stats),
			("Switches", SquireCommands.Switches),
			("Command list", SquireCommands.List),
			("Tithe", SquireCommands.Tithe),
			("Check tithing points", SquireCommands.CheckTithingPoints),
			("Play music", SquireCommands.PlayMusic)
		]),
		("Spells",
		[
			("Consecrate weapon", SquireCommands.Consecrate),
			("Divine fury", SquireCommands.DivineFury),
			("Dispel evil", SquireCommands.DispelEvil),
			("Enemy of one", SquireCommands.EnemyOfOne),
			("Holy light", SquireCommands.HolyLight),
			("Noble sacrifice", SquireCommands.NobleSacrifice),
			("Cleanse by fire", SquireCommands.CleanseByFire),
			("Close wounds", SquireCommands.CloseWounds),
			("Remove curse", SquireCommands.RemoveCurse),
			("Pain spike (necro)", SquireCommands.PainSpike),
			("Poison strike", SquireCommands.PoisonStrike),
			("Wraith form", SquireCommands.WraithForm),
			("Curse weapon", SquireCommands.CurseWeapon),
			("Wither", SquireCommands.Wither),
			("Lich form", SquireCommands.LichForm),
			("Vampiric embrace", SquireCommands.VampiricEmbrace)
		]),
		("Settings",
		[
			("Appearance", SquireCommands.Restyle),
			("Squire nickname", SquireCommands.ChangeSNickname),
			("How to call me", SquireCommands.ChangeNickname),
			("Rename yourself", SquireCommands.RenameSelf),
			("Change title", SquireCommands.ChangeTitle),
			("Assign team", SquireCommands.SetTeam)
		])
	];

	private readonly Mobile _viewer;
	private readonly Squire _squire;
	private readonly int _category;

	public SquireCommandGump(Mobile from, Squire squire, int category = 0) : base(50, 50)
	{
		_viewer = from;
		_squire = squire;
		_category = Math.Clamp(category, 0, _cats.Length - 1);
		BuildGump();
	}

	private void BuildGump()
	{
		if (_squire?.Deleted != false)
			return;

		var cat = _cats[_category];
		var rows = (cat.Items.Length + 1) / 2;
		var height = 118 + rows * ItemStep;

		AddPage(0);
		AddBackground(0, 0, GumpWidth, height, 2620);
		AddImageTiled(10, 10, GumpWidth - 20, height - 20, 2624);
		AddAlphaRegion(10, 10, GumpWidth - 20, height - 20);

		AddHtml(GumpWidth / 2 - 180, 18, 360, 25, ColorAndCenter("#FFCC00", $"Squire Commands: {_squire.Name}"), false, false);
		AddButton(GumpWidth - 40, 16, ButtonInfo, ButtonInfo, 1, GumpButtonType.Reply, 0);

		const int tabWidth = 92;
		for (var i = 0; i < _cats.Length; i++)
		{
			var x = 16 + i * tabWidth;
			AddButton(x, TabY + 2, ButtonArrow, ButtonArrow, 1000 + i, GumpButtonType.Reply, 0);
			AddLabel(x + 28, TabY, i == _category ? CYellow : CWhite, _cats[i].Title);
		}

		AddImageTiled(20, TabY + 26, GumpWidth - 40, 2, 96);

		for (var i = 0; i < cat.Items.Length; i++)
		{
			var col = i / rows;
			var row = i % rows;
			var x = col == 0 ? C1X : C2X;
			var y = TabY + 40 + row * ItemStep;

			AddButton(x, y + 2, ButtonArrow, ButtonArrow, 10 + i, GumpButtonType.Reply, 0);
			AddLabel(x + 28, y, CWhite, cat.Items[i].Label);
		}
	}

	public override void OnResponse(NetState sender, in RelayInfo info)
	{
		var from = sender.Mobile;

		if (from == null || _squire?.Deleted != false)
			return;

		switch (info.ButtonID)
		{
			case 0:
				break;
			case 1:
			{
				from.CloseGump<SquireCommandAboutGump>();
				from.SendGump(new SquireCommandAboutGump());
				from.SendGump(new SquireCommandGump(_viewer, _squire, _category));
				break;
			}
			default:
			{
				if (info.ButtonID >= 1000)
				{
					from.SendGump(new SquireCommandGump(_viewer, _squire, info.ButtonID - 1000));
					return;
				}

				var index = info.ButtonID - 10;
				var cat = _cats[_category];

				if (index >= 0 && index < cat.Items.Length
					&& from == _squire.ControlMaster && !_squire.IsDeadPet
					&& _squire.InRange(from.Location, 18))
				{
					from.SendGump(new SquireCommandGump(_viewer, _squire, _category));
					_squire.ExecuteCommand(from, cat.Items[index].Command);
				}

				break;
			}
		}
	}

	public static string ColorAndCenter(string color, string text) =>
		$"<CENTER><BASEFONT COLOR={color}>{text}</BASEFONT></CENTER>";
}

public class SquireCommandAboutGump : Gump
{
	public SquireCommandAboutGump() : base(100, 100)
	{
		const int width = 260;
		const int height = 150;

		AddPage(0);
		AddBackground(0, 0, width, height, 2620);
		AddImageTiled(10, 10, width - 20, height - 20, 2624);
		AddAlphaRegion(10, 10, width - 20, height - 20);

		AddHtml(10, 25, width - 20, 25, SquireCommandGump.ColorAndCenter("#FFD700", "Squire System v2.2.7"), false, false);
		AddHtml(10, 60, width - 20, 80,
			"<BASEFONT COLOR=#FFFFFF><CENTER>"
			+ "<BASEFONT COLOR=#88FF88>Author: MontegroXD (James Wolff)</BASEFONT><br><br>"
			+ "<BASEFONT COLOR=#FF0000>Refactored for ModernUO: Expa</BASEFONT><br><br>"
			+ "</CENTER></BASEFONT>", false, false);
	}
}
