using System;
using Server;
using Server.Mobiles;
using Server.Network;
using Server.HuePickers;

namespace Server.Gumps;

public class SquireCustomizeGump : DynamicGump
{
	public override bool Singleton => true;

	private readonly Squire _squire;

	private static readonly (int ItemID, int Name)[] _hairStyles =
	[
		(0x203B, 1011052),
		(0x203C, 1011053),
		(0x203D, 1011054),
		(0x2044, 1011055),
		(0x2045, 1011047),
		(0x204A, 1011050),
		(0x2047, 1011396),
		(0x2048, 1011048),
		(0x2049, 1011049)
	];

	private static readonly (int ItemID, int Name)[] _elfHairStyles =
	[
		(0x2fc0, 1074386),
		(0x2fc1, 1074387),
		(0x2fc2, 1074388),
		(0x2fce, 1074391),
		(0x2fcf, 1074392),
		(0x2fd1, 1074394),
		(0x2fcc, 1074385),
		(0x2fd0, 1074390)
	];

	private static readonly (int ItemID, int Name)[] _beardStyles =
	[
		(0x2041, 1011062),
		(0x203F, 1011060),
		(0x204B, 1015321),
		(0x203E, 1011061),
		(0x204C, 1015322),
		(0x2040, 1015323),
		(0x204D, 1011401)
	];
	public SquireCustomizeGump(Squire squire) : base(50, 50)
	{
		_squire = squire;
	}

	private void Resend(Mobile from) => from.SendGump(new SquireCustomizeGump(_squire));

	private static void AddStyleList(ref DynamicGumpBuilder builder, (int ItemID, int Name)[] styles, int x, int prefix, int clearId, int colorId, int labelWidth)
	{
		for (var i = 0; i < styles.Length; i++)
		{
			builder.AddButton(x, 70 + i * 20, 0x2716, 0x2716, prefix | i, GumpButtonType.Reply, 0);
			builder.AddHtmlLocalized(x + 35, 72 + i * 20, labelWidth, 18, styles[i].Name, 0x7FFF, false, false);
		}

		builder.AddButton(x, 70 + styles.Length * 20, 0x2716, 0x2716, clearId, GumpButtonType.Reply, 0);
		builder.AddHtmlLocalized(x + 35, 72 + styles.Length * 20, labelWidth, 18, 1011403, 0x7FFF, false, false);

		builder.AddButton(x, 70 + (styles.Length + 1) * 20, 0x2716, 0x2716, colorId, GumpButtonType.Reply, 0);
		builder.AddHtmlLocalized(x + 35, 72 + (styles.Length + 1) * 20, labelWidth, 18, 1011402, 0x7FFF, false, false);
	}

	protected override void BuildLayout(ref DynamicGumpBuilder builder)
	{
		var squire = _squire;

		builder.AddBackground(0, 0, 370, 370, 2620);
		builder.AddImageTiled(10, 10, 350, 350, 2624);
		builder.AddAlphaRegion(10, 10, 350, 350);

		builder.AddHtml(10, 12, 350, 18, "<center><basefont color=#FFCC00>SQUIRE CUSTOMIZATION MENU</basefont></center>", background: false, scrollbar: false);

		builder.AddHtmlLocalized(10, 42, 150, 18, 1062459, 0x35, false, false);
		AddStyleList(ref builder, squire.Race == Race.Elf ? _elfHairStyles : _hairStyles, 10, 0x100, 2, 3, 110);

		if (!squire.Female && squire.Race != Race.Elf)
		{
			builder.AddHtmlLocalized(160, 42, 210, 18, 1062460, 0x35, false, false);
			AddStyleList(ref builder, _beardStyles, 160, 0x200, 4, 5, 160);
		}
	}

	public override void OnResponse(NetState sender, in RelayInfo info)
	{
		var from = sender.Mobile;

		if (from != _squire.ControlMaster && from.AccessLevel < AccessLevel.GameMaster)
			return;

		switch (info.ButtonID)
		{
			case 0:
			{
				_squire.SayTo(from, "Thank you, master, I think I like it this way!");
				break;
			}
			case 1:
			{
				if (_squire.Female)
				{
					_squire.Body = 400;
					_squire.Female = false;
				}
				else
				{
					_squire.Body = 401;
					_squire.Female = true;
					_squire.FacialHairItemID = 0;
				}

				Resend(from);
				break;
			}
			case 2:
			{
				_squire.HairItemID = 0;
				Resend(from);
				break;
			}
			case 3:
			{
				if (_squire.HairItemID > 0)
					new SquireHuePicker(_squire, false, from).SendTo(from.NetState);
				else
					Resend(from);

				break;
			}
			case 4:
			{
				_squire.FacialHairItemID = 0;
				Resend(from);
				break;
			}
			case 5:
			{
				if (_squire.FacialHairItemID > 0)
					new SquireHuePicker(_squire, true, from).SendTo(from.NetState);
				else
					Resend(from);

				break;
			}
			default:
			{
				var buttonID = info.ButtonID;

				if ((buttonID & 0x100) != 0)
				{
					var styles = _squire.Race == Race.Elf ? _elfHairStyles : _hairStyles;
					var index = buttonID & 0xFF;

					if (index >= styles.Length)
						return;

					var hairHue = _squire.HairHue;
					_squire.HairItemID = 0;
					_squire.ProcessDelta();
					_squire.HairItemID = styles[index].ItemID;
					_squire.HairHue = hairHue;

					Resend(from);
				}
				else if ((buttonID & 0x200) != 0)
				{
					if (_squire.Female)
						return;

					var index = buttonID & 0xFF;

					if (index >= _beardStyles.Length)
						return;

					var beardHue = _squire.FacialHairHue;
					_squire.FacialHairItemID = 0;
					_squire.ProcessDelta();
					_squire.FacialHairItemID = _beardStyles[index].ItemID;
					_squire.FacialHairHue = beardHue;

					Resend(from);
				}

				break;
			}
		}
	}

	private class SquireHuePicker : HuePicker
	{
		private readonly Squire _squire;
		private readonly bool _facialHair;
		private readonly Mobile _from;

		public SquireHuePicker(Squire squire, bool facialHair, Mobile from) : base(0xFAB)
		{
			_squire = squire;
			_facialHair = facialHair;
			_from = from;
		}

		public override void OnResponse(int hue)
		{
			if (_facialHair)
				_squire.FacialHairHue = hue;
			else
				_squire.HairHue = hue;

			_from.SendGump(new SquireCustomizeGump(_squire));
		}
	}
}

public enum SquireLorePage
{
	Stats,
	Skills,
	Switches
}

public class SquireLoreGump : DynamicGump
{
	public override bool Singleton => true;

	private const int LabelColor = 0xFFFFFF;

	private readonly SquireLorePage _page;
	private readonly BaseCreature _squire;
	private readonly Mobile _from;

	private static int GetButtonID(int type, int index) => 1 + index * 15 + type;

	private static readonly (int Cliloc, Func<BaseCreature, int> Get)[] _damageElements =
	[
		(1061646, c => c.PhysicalDamage),
		(1061647, c => c.FireDamage),
		(1061648, c => c.ColdDamage),
		(1061649, c => c.PoisonDamage),
		(1061650, c => c.EnergyDamage),
	];

	private static readonly (int Cliloc, Func<BaseCreature, int> Get)[] _resistElements =
	[
		(1061646, c => c.PhysicalResistance),
		(1061647, c => c.FireResistance),
		(1061648, c => c.ColdResistance),
		(1061649, c => c.PoisonResistance),
		(1061650, c => c.EnergyResistance),
	];

	private static readonly SkillName[] _lockableSkills =
	[
	SkillName.Wrestling,
	SkillName.Tactics,
	SkillName.MagicResist,
	SkillName.Anatomy,
	SkillName.Swords,
	SkillName.Macing,
	SkillName.Fencing,
	SkillName.Archery,
	SkillName.Parry,
	SkillName.Healing,
	SkillName.Veterinary,
	SkillName.EvalInt,
	SkillName.Meditation,
	SkillName.AnimalLore,
	SkillName.Hiding,
	SkillName.Focus,
	SkillName.Musicianship,
	SkillName.Peacemaking,
	SkillName.Discordance,
	SkillName.Provocation,
	SkillName.Stealing,
	SkillName.Lockpicking,
	SkillName.SpiritSpeak,
	SkillName.Poisoning,
	SkillName.Chivalry,
	SkillName.Bushido,
	SkillName.Necromancy,
	];

	private static readonly Action<Squire, bool>[] _type3Setters =
	[
	( s, v ) => s._inspectable = v,
	( s, v ) => s._autoPickupAmmo = v,
	( s, v ) => s._squireBeQuiet = v,
	( s, v ) => s._desperateMasterRun = v,
	( s, v ) => s._autoUseHealthPotion = v,
	( s, v ) => s._autoUsePowerScroll = v,
	( s, v ) => s._autoEquipLoot = v,
	( s, v ) => s._autoRezAlly = v,
	( s, v ) => s._autoCastCloseWounds = v,
	( s, v ) => s._autoCastCleanseByFire = v,
	( s, v ) => s._autoCastCleanseByFireMaster = v,
	( s, v ) => s._autoCastCleanseByFireAlly = v,
	( s, v ) => s._autoCastCloseWoundsMaster = v,
	( s, v ) => s._autoCastCloseWoundsAlly = v,
	];

	private static readonly Action<Squire, bool>[] _type4Setters =
	[
	( s, v ) => s._autoHealSelf = v,
	( s, v ) => s._autoHealMaster = v,
	( s, v ) => s._autoHealOther = v,
	( s, v ) => s._autoHealAnimals = v,
	( s, v ) => s._autoUseCurePotion = v,
	( s, v ) => s._autoUseTScroll = v,
	( s, v ) => s._autoUseSpiritSpeak = v,
	( s, v ) => s._autoRezMaster = v,
	];

	private static readonly Action<Squire, bool>[] _type5Setters =
	[
	( s, v ) => s._onlyLootGoldAndMap = v,
	( s, v ) => s._autoLoot = v,
	( s, v ) => s._autoVampiricEmbrace = v,
	( s, v ) => s._convenientStackable = v,
	( s, v ) => s._lootGold = v,
	( s, v ) => s._lootMap = v,
	( s, v ) => s._lootZoogiFungus = v,
	( s, v ) => s._lootDaemonBone = v,
	];

	private static readonly ( Func<Squire, bool> Get, int Type, int Base, string Label )[] _switchColumn1 =
	[
	( s => s._inspectable, 3, 1, "Inspectable" ),
	( s => s._autoPickupAmmo, 3, 3, "Auto Pickup Ammo" ),
	( s => s._squireBeQuiet, 3, 5, "Be Quiet" ),
	( s => s._desperateMasterRun, 3, 7, "Desperate Master Run" ),
	( s => s._autoUseHealthPotion, 3, 9, "Auto Use Health Potion" ),
	( s => s._autoUsePowerScroll, 3, 11, "Auto Use Power Scroll" ),
	( s => s._autoEquipLoot, 3, 13, "Auto Equip Loot" ),
	( s => s._autoRezAlly, 3, 15, "Auto Rez Ally" ),
	( s => s._autoCastCloseWounds, 3, 17, "Close Wounds Self" ),
	( s => s._autoCastCloseWoundsMaster, 3, 25, "Close Wounds Master" ),
	( s => s._autoCastCloseWoundsAlly, 3, 27, "Close Wounds Ally" ),
	( s => s._onlyLootGoldAndMap, 5, 1, "Loot Only Select Items" ),
	( s => s._autoLoot, 5, 3, "Auto Loot" ),
	( s => s._lootGold, 5, 9, "Loot Gold" ),
	( s => s._lootMap, 5, 11, "Loot Treasure Maps" ),
	];

	private static readonly ( Func<Squire, bool> Get, int Type, int Base, string Label )[] _switchColumn2 =
	[
	( s => s._autoHealSelf, 4, 1, "Auto Heal Self" ),
	( s => s._autoHealMaster, 4, 3, "Auto Heal Master" ),
	( s => s._autoHealOther, 4, 5, "Auto Heal Others" ),
	( s => s._autoHealAnimals, 4, 7, "Auto Heal Animals" ),
	( s => s._autoUseCurePotion, 4, 9, "Auto Use Cure Potion" ),
	( s => s._autoUseTScroll, 4, 11, "Auto Use Training Scrl" ),
	( s => s._autoUseSpiritSpeak, 4, 13, "Auto Spirit Speak" ),
	( s => s._autoRezMaster, 4, 15, "Auto Rez Master" ),
	( s => s._autoCastCleanseByFire, 3, 19, "Cleanse By Fire Self" ),
	( s => s._autoCastCleanseByFireMaster, 3, 21, "Cleanse By Fire Master" ),
	( s => s._autoCastCleanseByFireAlly, 3, 23, "Cleanse By Fire Ally" ),
	( s => s._autoVampiricEmbrace, 5, 5, "Auto Cast Vampire" ),
	( s => s._convenientStackable, 5, 7, "Convenient Stackable Loot" ),
	( s => s._lootZoogiFungus, 5, 13, "Loot Zoogi Fungus" ),
	( s => s._lootDaemonBone, 5, 15, "Loot Daemon Bone" ),
	];

	private static readonly ( SkillName Skill, string Text, int Cliloc, int X, int Y, int BtnX, int BtnId )[] _skillRows =
	[
	( SkillName.Anatomy, null, 1044061, 20, 58, 195, 4 ),
	( SkillName.Archery, "Archery", 0, 20, 76, 195, 8 ),
	( SkillName.Chivalry, "Chivalry", 0, 20, 94, 195, 25 ),
	( SkillName.Fencing, "Fencing", 0, 20, 112, 195, 7 ),
	( SkillName.Macing, "Macefighting", 0, 20, 130, 195, 6 ),
	( SkillName.Parry, "Parrying", 0, 20, 148, 195, 9 ),
	( SkillName.MagicResist, "Spell resist", 0, 20, 166, 195, 3 ),
	( SkillName.Swords, "Swordsmanship", 0, 20, 184, 195, 5 ),
	( SkillName.Tactics, null, 1044087, 20, 202, 195, 2 ),
	( SkillName.Wrestling, null, 1044103, 20, 220, 195, 1 ),
	( SkillName.Bushido, "Bushido", 0, 20, 256, 195, 26 ),
	( SkillName.Healing, "Healing", 0, 20, 274, 195, 10 ),
	( SkillName.Necromancy, "Necromancy", 0, 20, 292, 195, 27 ),
	( SkillName.Veterinary, "Veterinary", 0, 20, 310, 195, 11 ),
	( SkillName.AnimalLore, "Animal Lore", 0, 220, 58, 395, 14 ),
	( SkillName.EvalInt, "Eval Int", 0, 220, 76, 395, 12 ),
	( SkillName.Meditation, null, 1044106, 220, 94, 395, 13 ),
	( SkillName.Focus, "Focus", 0, 220, 130, 395, 16 ),
	( SkillName.SpiritSpeak, "Spirit Speak", 0, 220, 148, 395, 23 ),
	( SkillName.Musicianship, "Musicianship", 0, 220, 202, 395, 17 ),
	( SkillName.Discordance, "Discordance", 0, 220, 184, 395, 19 ),
	( SkillName.Peacemaking, "Peacemaking", 0, 220, 220, 395, 18 ),
	( SkillName.Provocation, "Provocation", 0, 220, 238, 395, 20 ),
	( SkillName.Hiding, "Hiding", 0, 220, 274, 395, 15 ),
	( SkillName.Lockpicking, "Lockpicking", 0, 220, 292, 395, 22 ),
	( SkillName.Poisoning, "Poisoning", 0, 220, 310, 395, 24 ),
	( SkillName.Stealing, "Stealing", 0, 220, 328, 395, 21 ),
	];
	public SquireLoreGump(BaseCreature c, Mobile from, SquireLorePage page) : base(250, 50)
	{
		_squire = c;
		_from = from;
		_page = page;
	}

	private static bool CanControl(BaseCreature c, Mobile from) =>
		(c.Controlled && from == c.ControlMaster) || from.AccessLevel >= AccessLevel.GameMaster;

	public override void OnResponse(NetState sender, in RelayInfo info)
	{
		if (info.ButtonID == 100002)
		{
			if (_squire is Squire squire && squire.ControlMaster == _from && !squire.IsDeadPet)
				_from.SendGump(new SquireCommandGump(_from, squire));

			return;
		}

		if (info.ButtonID is 100001 or 100003)
		{
			var target = info.ButtonID == 100001 ? SquireLorePage.Skills : SquireLorePage.Switches;
			_from.SendGump(new SquireLoreGump(_squire, _from, target));
			return;
		}

		var buttonID = info.ButtonID - 1;
		var index = buttonID / 15;
		var type = buttonID % 15;

		BaseCreature c = _squire;

		switch (type)
		{
			default:
			{
				_from.CloseGump<SquireLoreGump>();
				break;
			}
			case 1:
			{
				if (!CanControl(c, _from))
					break;

				if (index >= 1 && index <= _lockableSkills.Length)
				{
					var skill = c.Skills[_lockableSkills[index - 1]];
					var nextLock = skill.Lock switch
					{
						SkillLock.Up => SkillLock.Down,
						SkillLock.Down => SkillLock.Locked,
						_ => SkillLock.Up
					};
					skill.SetLockNoRelay(nextLock);
					skill.Update();
				}

				Resend(SquireLorePage.Skills);
				break;
			}
			case 2:
			{
				var target = index switch
				{
					1 => SquireLorePage.Skills,
					3 => SquireLorePage.Switches,
					_ => SquireLorePage.Stats
				};
				_from.SendGump(new SquireLoreGump(c, _from, target));
				break;
			}
			case 3:
			case 4:
			case 5:
			{
				if (!CanControl(c, _from))
					break;

				var setters = type switch
				{
					3 => _type3Setters,
					4 => _type4Setters,
					_ => _type5Setters
				};

				if (index >= 1 && index <= setters.Length * 2 && c is Squire s)
					setters[(index - 1) / 2](s, index % 2 == 0);

				Resend(SquireLorePage.Switches);
				break;
			}
		}
	}

	private void Resend(SquireLorePage page)
	{
		_from.CloseGump<SquireLoreGump>();
		_from.SendGump(new SquireLoreGump(_squire, _from, page));
	}

	private static string Cell(string text) => $"<basefont color=#FFFFFF><div align=right>{text}</div></basefont>";

	private static string FormatSkill(BaseCreature c, SkillName name)
	{
		var skill = c.Skills[name];
		var val = skill.Value == 20 && skill.Base < 20 ? skill.Base : skill.Value;
		return $"<basefont color=#FFFFFF><div align=right>{val:F1}/{skill.Cap}</div></basefont>";
	}

	private static string FormatAttributes(int cur, int max) => max == 0 ? Cell("---") : Cell($"{cur}/{max}");

	private static string FormatStat(int val) => val == 0 ? Cell("---") : Cell($"{val}");

	private static string FormatElement(int val) => val <= 0 ? Cell("---") : Cell($"{val}%");

	protected override void BuildLayout(ref DynamicGumpBuilder builder)
	{
		var c = _squire;
		var from = _from;
		var page = _page;

		builder.AddPage();

		builder.AddHtml(100, 14, 210, 18, $"<basefont color=#FFFFFF><center><i>{c.Name}</i></center></basefont>", background: false, scrollbar: false);

		builder.AddButton(318, 17, 0x9CF, 0x9CF, 100002, GumpButtonType.Reply, 0);

		if (page == SquireLorePage.Stats)
			BuildStatsPage(ref builder, c, from);
		else if (page == SquireLorePage.Skills)
			BuildSkillsPage(ref builder, c, from);
		else
			BuildSwitchesPage(ref builder, c);
	}

	private void BuildStatsPage(ref DynamicGumpBuilder builder, BaseCreature c, Mobile from)
	{
		builder.AddBackground(0, 0, 420, 372, 2620);
		builder.AddImageTiled(10, 10, 400, 352, 2624);
		builder.AddAlphaRegion(10, 10, 400, 352);

		builder.AddHtml(20, 40, 160, 18, "<basefont color=#FFD57A>Attributes</basefont>", background: false, scrollbar: false);

		builder.AddHtmlLocalized(20, 58, 160, 18, 1049578, LabelColor, false, false);
		builder.AddHtml(127, 58, 75, 18, FormatAttributes(c.Hits, c.HitsMax), background: false, scrollbar: false);

		builder.AddHtmlLocalized(20, 76, 160, 18, 1049579, LabelColor, false, false);
		builder.AddHtml(127, 76, 75, 18, FormatAttributes(c.Stam, c.StamMax), background: false, scrollbar: false);

		builder.AddHtmlLocalized(20, 94, 160, 18, 1049580, LabelColor, false, false);
		builder.AddHtml(127, 94, 75, 18, FormatAttributes(c.Mana, c.ManaMax), background: false, scrollbar: false);

		builder.AddHtmlLocalized(20, 112, 160, 18, 1028335, LabelColor, false, false);
		builder.AddHtml(167, 112, 35, 18, FormatStat(c.Str), background: false, scrollbar: false);

		builder.AddHtmlLocalized(20, 130, 160, 18, 3000113, LabelColor, false, false);
		builder.AddHtml(167, 130, 35, 18, FormatStat(c.Dex), background: false, scrollbar: false);

		builder.AddHtmlLocalized(20, 148, 160, 18, 3000112, LabelColor, false, false);
		builder.AddHtml(167, 148, 35, 18, FormatStat(c.Int), background: false, scrollbar: false);

		builder.AddHtml(20, 166, 160, 18, "<basefont color=#FFD57A>Tithing Points: </basefont>", background: false, scrollbar: false);
		builder.AddHtml(127, 166, 75, 18, FormatStat(c.TithingPoints), background: false, scrollbar: false);

		builder.AddHtml(20, 220, 160, 18, "<basefont color=#FFD57A>Damage</basefont>", background: false, scrollbar: false);

		var y = 238;
		foreach (var (cliloc, get) in _damageElements)
		{
			builder.AddHtmlLocalized(20, y, 160, 18, cliloc, LabelColor, false, false);
			builder.AddHtml(167, y, 35, 18, FormatElement(get(c)), background: false, scrollbar: false);
			y += 18;
		}

		builder.AddHtml(125, 28, 160, 18, "<basefont color=#FFD57A><center>Stats</center></basefont>", background: false, scrollbar: false);

		builder.AddHtml(220, 40, 160, 18, "<basefont color=#FFD57A>Loyalty Rating</basefont>", background: false, scrollbar: false);
		builder.AddHtmlLocalized(220, 58, 160, 18, (!c.Controlled || c.Loyalty == 0) ? 1061643 : 1049595 + c.Loyalty / 10, LabelColor, false, false);

		if (c is Squire sq)
		{
			builder.AddHtml(220, 76, 160, 18, "<basefont color=#FFD57A>Master's Nickname</basefont>", background: false, scrollbar: false);
			builder.AddHtml(220, 94, 160, 18, $"<basefont color=#FFFFFF>{sq._masterNickname}</basefont>", background: false, scrollbar: false);

			builder.AddHtml(220, 112, 160, 18, $"<basefont color=#FFD57A>{sq.Name}'s Nickname</basefont>", background: false, scrollbar: false);
			builder.AddHtml(220, 130, 160, 18, $"<basefont color=#FFFFFF>{sq._squireNickname}</basefont>", background: false, scrollbar: false);

			builder.AddHtml(220, 148, 160, 18, $"<basefont color=#FFD57A>{sq.Name}'s Title</basefont>", background: false, scrollbar: false);
			builder.AddHtml(220, 166, 160, 18, $"<basefont color=#FFFFFF>{sq.Title}</basefont>", background: false, scrollbar: false);

			builder.AddHtml(220, 184, 160, 18, $"<basefont color=#FFD57A>{sq.Name}'s Team</basefont>", background: false, scrollbar: false);
			builder.AddHtml(220, 202, 160, 18, $"<basefont color=#FFFFFF>{sq._squireTeam}</basefont>", background: false, scrollbar: false);
		}

		builder.AddHtml(220, 220, 160, 18, "<basefont color=#FFD57A>Resistances</basefont>", background: false, scrollbar: false);

		y = 238;
		foreach (var (cliloc, get) in _resistElements)
		{
			builder.AddHtmlLocalized(220, y, 160, 18, cliloc, LabelColor, false, false);
			builder.AddHtml(357, y, 35, 18, FormatElement(get(c)), background: false, scrollbar: false);
			y += 18;
		}

		builder.AddHtml(347, 20, 160, 18, "<basefont color=#FFD57A>Skills</basefont>", background: false, scrollbar: false);
		builder.AddButton(377, 22, 5601, 5605, 100001, GumpButtonType.Reply, 0);

		if (CanControl(c, from))
		{
			builder.AddHtml(40, 20, 160, 18, "<basefont color=#FFD57A>Switches</basefont>", background: false, scrollbar: false);
			builder.AddButton(20, 21, 5603, 5607, 100003, GumpButtonType.Reply, 0);
		}
	}

	private void BuildSkillsPage(ref DynamicGumpBuilder builder, BaseCreature c, Mobile from)
	{
		builder.AddBackground(0, 0, 420, 372, 2620);
		builder.AddImageTiled(10, 10, 400, 352, 2624);
		builder.AddAlphaRegion(10, 10, 400, 352);

		builder.AddHtml(20, 40, 160, 18, "<basefont color=#FFD57A>Combat Skills</basefont>", background: false, scrollbar: false);
		builder.AddHtml(20, 238, 160, 18, "<basefont color=#FFD57A>Healing Abilities</basefont>", background: false, scrollbar: false);

		builder.AddHtml(125, 28, 160, 18, "<basefont color=#FFD57A><center>Skills</center></basefont>", background: false, scrollbar: false);

		builder.AddHtml(220, 40, 160, 18, "<basefont color=#FFD57A>Lore & Knowledge</basefont>", background: false, scrollbar: false);
		builder.AddHtml(220, 112, 160, 18, "<basefont color=#FFD57A>Miscellaneous</basefont>", background: false, scrollbar: false);
		builder.AddHtml(220, 166, 160, 18, "<basefont color=#FFD57A>Barding</basefont>", background: false, scrollbar: false);
		builder.AddHtml(220, 256, 160, 18, "<basefont color=#FFD57A>Thievery</basefont>", background: false, scrollbar: false);

		foreach (var (skill, text, cliloc, x, y, btnX, btnId) in _skillRows)
			AddSkillRow(ref builder, c, from, skill, text, cliloc, x, y, btnX, btnId);

		builder.AddHtml(40, 20, 160, 18, "<basefont color=#FFD57A>Stats</basefont>", background: false, scrollbar: false);
		builder.AddButton(20, 21, 5603, 5607, GetButtonID(2, 2), GumpButtonType.Reply, 0);

		if (CanControl(c, from))
		{
			builder.AddHtml(327, 20, 160, 18, "<basefont color=#FFD57A>Switches</basefont>", background: false, scrollbar: false);
			builder.AddButton(377, 22, 5601, 5605, 100003, GumpButtonType.Reply, 0);
		}
	}

	private void AddSkillRow(ref DynamicGumpBuilder builder, BaseCreature c, Mobile from, SkillName skill, string text, int cliloc, int x, int y, int btnX, int btnId)
	{
		if (cliloc > 0)
			builder.AddHtmlLocalized(x, y, 160, 18, cliloc, LabelColor, false, false);
		else
			builder.AddHtml(x, y, 160, 18, $"<basefont color=#FFFFFF>{text}</basefont>", background: false, scrollbar: false);

		builder.AddHtml(x + 80, y, 90, 18, FormatSkill(c, skill), background: false, scrollbar: false);

		if (!CanControl(c, from))
			return;

		var (up, down, locked) = (0x983, 0x985, 0x82C);
		var (btn, off) = c.Skills[skill].Lock switch
		{
			SkillLock.Down => (down, 4),
			SkillLock.Locked => (locked, 3),
			_ => (up, 4)
		};
		builder.AddButton(btnX, y + off, btn, btn, GetButtonID(1, btnId), GumpButtonType.Reply, 0);
	}

	private void BuildSwitchesPage(ref DynamicGumpBuilder builder, BaseCreature c)
	{
		builder.AddBackground(0, 0, 420, 400, 2620);
		builder.AddImageTiled(10, 10, 400, 380, 2624);
		builder.AddAlphaRegion(10, 10, 400, 380);

		var squire = (Squire)c;
		var canControl = CanControl(c, _from);

		var row = 0;
		foreach (var (get, type, baseIndex, label) in _switchColumn1)
			AddStatsOption(ref builder, 1, ++row, canControl && get(squire), type, baseIndex, $"<basefont color=#FFFFFF>{label}</basefont>");

		row = 0;
		foreach (var (get, type, baseIndex, label) in _switchColumn2)
			AddStatsOption(ref builder, 2, ++row, canControl && get(squire), type, baseIndex, $"<basefont color=#FFFFFF>{label}</basefont>");

		builder.AddHtml(125, 28, 160, 18, "<basefont color=#FFD57A><center>Switches</center></basefont>", background: false, scrollbar: false);

		builder.AddHtml(40, 20, 160, 18, "<basefont color=#FFD57A>Stats</basefont>", background: false, scrollbar: false);
		builder.AddButton(20, 21, 5603, 5607, GetButtonID(2, 2), GumpButtonType.Reply, 0);

		builder.AddHtml(347, 20, 160, 18, "<basefont color=#FFD57A>Skills</basefont>", background: false, scrollbar: false);
		builder.AddButton(377, 22, 5601, 5605, 100001, GumpButtonType.Reply, 0);
	}

	private void AddStatsOption(ref DynamicGumpBuilder builder, int columnNumber, int rowNumber, bool isEnabled, int buttonType, int buttonIndexBase, string label)
	{
		const int iconWidth = 25;
		const int trueIcon = 0xD3;
		const int falseIcon = 0xD2;
		const int labelWidth = 160;
		const int labelHeight = 18;
		const int rowHeight = 22;
		const int baseRowY = 30;
		const int columnWidth = 205;

		var x = columnNumber == 1 ? 20 : columnWidth * (columnNumber - 1);
		var icon = isEnabled ? trueIcon : falseIcon;
		var buttonIndex = isEnabled ? buttonIndexBase : buttonIndexBase + 1;

		builder.AddButton(x, baseRowY + rowHeight * rowNumber, icon, icon, GetButtonID(buttonType, buttonIndex), GumpButtonType.Reply, 0);
		builder.AddHtml(x + iconWidth, baseRowY + rowNumber * rowHeight, labelWidth, labelHeight, label, background: false, scrollbar: false);
	}
}
