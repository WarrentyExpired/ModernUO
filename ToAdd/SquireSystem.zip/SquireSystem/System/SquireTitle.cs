using System;
using Server;
using Server.Mobiles;
using Server.Network;

namespace Server.Gumps;

public enum SquireTitlePage
{
	PageOne,
	PageTwo,
	PageThree,
	PageFour,
	Server
}

public class SquireTitleGump : DynamicGump
{
	public override bool Singleton => true;

	private readonly SquireTitlePage _page;
	private readonly BaseCreature _squire;
	private readonly Mobile _from;

	private sealed record TitleEntry( Func<BaseCreature, string> Label, int Type, int Index, Func<BaseCreature, bool> Available, Func<BaseCreature, string> Title );

	private static int GetButtonID( int type, int index ) => 1 + ( index * 15 ) + type;

	private static double Sk( BaseCreature c, SkillName s ) => c.Skills[s].Base;

	private static bool Wpn( BaseCreature c, double v ) =>
		Sk( c, SkillName.Swords ) >= v || Sk( c, SkillName.Fencing ) >= v ||
		Sk( c, SkillName.Macing ) >= v || Sk( c, SkillName.Archery ) >= v;

	private static string GetPrefix( double skillValue ) => skillValue switch
	{
		>= 120.0 => "the Legendary ",
		>= 110.0 => "the Elder ",
		>= 100.0 => "the Grandmaster ",
		>= 90.0 => "the Master ",
		>= 80.0 => "the Adept ",
		>= 70.0 => "the Expert ",
		>= 60.0 => "the Journeyman ",
		>= 50.0 => "the Apprentice ",
		>= 40.0 => "the Novice ",
		>= 30.0 => "the Neophyte ",
		_ => "the "
	};

	private static TitleEntry T( string label, int type, int index, Func<BaseCreature, bool> available ) =>
		new( _ => label, type, index, available, _ => $"the {label}" );

	private static TitleEntry T( string label, int type, int index, Func<BaseCreature, bool> available, string title ) =>
		new( _ => label, type, index, available, _ => title );

	private static TitleEntry T( string label, int type, int index, Func<BaseCreature, bool> available, Func<BaseCreature, string> title ) =>
		new( _ => label, type, index, available, title );

	private static TitleEntry TG( string femaleLabel, string maleLabel, int type, int index, Func<BaseCreature, bool> available ) =>
		new( c => c.Female ? femaleLabel : maleLabel, type, index, available,
			c => c.Female ? $"the {femaleLabel}" : $"the {maleLabel}" );

	private static readonly ( SkillName Skill, string Name )[] _skillTitleNames =
	[
		( SkillName.Anatomy, "Biologist" ),
		( SkillName.AnimalLore, "Naturalist" ),
		( SkillName.Parry, "Duelist" ),
		( SkillName.Peacemaking, "Pacifier" ),
		( SkillName.Discordance, "Demoralizer" ),
		( SkillName.Healing, "Healer" ),
		( SkillName.Hiding, "Shade" ),
		( SkillName.Provocation, "Rouser" ),
		( SkillName.Lockpicking, "Infiltrator" ),
		( SkillName.Tactics, "Tactician" ),
		( SkillName.Musicianship, "Bard" ),
		( SkillName.Archery, "Archer" ),
		( SkillName.SpiritSpeak, "Medium" ),
		( SkillName.Stealing, "Pickpocket" ),
		( SkillName.EvalInt, "Scholar" ),
		( SkillName.Veterinary, "Veterinarian" ),
		( SkillName.Swords, "Swordsman" ),
		( SkillName.Macing, "Armsman" ),
		( SkillName.Fencing, "Fencer" ),
		( SkillName.Wrestling, "Wrestler" ),
		( SkillName.Focus, "Driven" ),
		( SkillName.Meditation, "Stoic" ),
	];

	private static readonly TitleEntry[] _pageOneEntries =
	[
		T( "Biologist", 2, 1, c => Sk( c, SkillName.Anatomy ) > 30.0 ),
		T( "Naturalist", 2, 2, c => Sk( c, SkillName.AnimalLore ) > 30.0 ),
		T( "Duelist", 2, 3, c => Sk( c, SkillName.Parry ) > 30.0 ),
		T( "Pacifier", 2, 4, c => Sk( c, SkillName.Peacemaking ) > 30.0 ),
		T( "Demoralizer", 2, 5, c => Sk( c, SkillName.Discordance ) > 30.0 ),
		T( "Healer", 2, 6, c => Sk( c, SkillName.Healing ) > 30.0 ),
		T( "Shade", 2, 7, c => Sk( c, SkillName.Hiding ) > 30.0 ),
		T( "Rouser", 2, 8, c => Sk( c, SkillName.Provocation ) > 30.0 ),
		T( "Infiltrator", 2, 9, c => Sk( c, SkillName.Lockpicking ) > 30.0 ),
		T( "Tactician", 2, 10, c => Sk( c, SkillName.Tactics ) > 30.0 ),
		T( "Bard", 2, 11, c => Sk( c, SkillName.Musicianship ) > 30.0 ),
		TG( "Shield Maiden", "He-Man", 2, 23, c => Sk( c, SkillName.Swords ) >= 100.0 && c.Str >= 125 ),
		T( "Musical Genius", 2, 25, c => Sk( c, SkillName.Musicianship ) >= 100.0 && Sk( c, SkillName.Peacemaking ) >= 100.0 && Sk( c, SkillName.Discordance ) >= 100.0 && Sk( c, SkillName.Provocation ) >= 100.0 ),
		T( "Shadow", 2, 27, c => Sk( c, SkillName.Hiding ) >= 100.0 && Sk( c, SkillName.Stealing ) >= 100.0 && Sk( c, SkillName.Lockpicking ) >= 100.0 ),
		T( "Knight", 2, 29, c => Sk( c, SkillName.Parry ) >= 100.0 && Sk( c, SkillName.Swords ) >= 100.0 ),
		T( "Captain Britannia", 2, 31, c => Sk( c, SkillName.Parry ) >= 100.0 && Sk( c, SkillName.Wrestling ) >= 100.0 && c.Str >= 100 ),
		T( "Piercing Shade", 2, 33, c => Sk( c, SkillName.Hiding ) >= 100.0 && Sk( c, SkillName.Fencing ) >= 100.0 ),
		T( "Shooting Shade", 2, 35, c => Sk( c, SkillName.Hiding ) >= 100.0 && Sk( c, SkillName.Archery ) >= 100.0 ),
		T( "Monk", 2, 37, c => Sk( c, SkillName.Healing ) >= 100.0 && Sk( c, SkillName.Wrestling ) >= 100.0 ),
		T( "Ranger", 2, 39, c => Sk( c, SkillName.Archery ) >= 70.0 ),
		T( "Archer", 2, 12, c => Sk( c, SkillName.Archery ) > 30.0 ),
		T( "Medium", 2, 13, c => Sk( c, SkillName.SpiritSpeak ) > 30.0 ),
		T( "Pickpocket", 2, 14, c => Sk( c, SkillName.Stealing ) > 30.0 ),
		T( "Scholar", 2, 15, c => Sk( c, SkillName.EvalInt ) > 30.0 ),
		T( "Veterinarian", 2, 16, c => Sk( c, SkillName.Veterinary ) > 30.0 ),
		T( "Swordsman", 2, 17, c => Sk( c, SkillName.Swords ) > 30.0 ),
		T( "Armsman", 2, 18, c => Sk( c, SkillName.Macing ) > 30.0 ),
		T( "Fencer", 2, 19, c => Sk( c, SkillName.Fencing ) > 30.0 ),
		T( "Wrestler", 2, 20, c => Sk( c, SkillName.Wrestling ) > 30.0 ),
		T( "Driven", 2, 21, c => Sk( c, SkillName.Focus ) > 30.0 ),
		T( "Stoic", 2, 22, c => Sk( c, SkillName.Meditation ) > 30.0 ),
		T( "Weapon Master", 2, 24, c => Sk( c, SkillName.Swords ) >= 90.0 && Sk( c, SkillName.Macing ) >= 90.0 && Sk( c, SkillName.Archery ) >= 90.0 && Sk( c, SkillName.Fencing ) >= 90.0 ),
		T( "Pugilist", 2, 26, c => Sk( c, SkillName.Wrestling ) >= 80.0 && c.Str >= 125 ),
		T( "Templar", 2, 28, c => Sk( c, SkillName.Parry ) >= 80.0 && ( Sk( c, SkillName.Swords ) >= 80.0 || Sk( c, SkillName.Macing ) >= 80.0 ) ),
		T( "Piercing Shield", 2, 30, c => Sk( c, SkillName.Fencing ) >= 100.0 && Sk( c, SkillName.Parry ) >= 100.0 ),
		T( "Striking Shade", 2, 32, c => Sk( c, SkillName.Hiding ) >= 100.0 && Sk( c, SkillName.Swords ) >= 100.0 ),
		T( "Crushing Shade", 2, 34, c => Sk( c, SkillName.Hiding ) >= 100.0 && Sk( c, SkillName.Macing ) >= 100.0 ),
		T( "Singing Shade", 2, 36, c => Sk( c, SkillName.Hiding ) >= 100.0 && Sk( c, SkillName.Musicianship ) >= 100.0 ),
		T( "Protector", 2, 38, c => Sk( c, SkillName.Healing ) >= 50.0 && Sk( c, SkillName.Swords ) >= 50.0 && Sk( c, SkillName.Parry ) >= 50.0 ),
		T( "Dedicated Healer", 2, 40, c => Sk( c, SkillName.Healing ) >= 80.0 && Sk( c, SkillName.Veterinary ) >= 80.0 ),
		T( "Strong", 2, 41, c => c.Str >= 125 ),
		T( "Dexterous", 2, 42, c => c.Dex >= 125 ),
		T( "Intelligent", 2, 43, c => c.Int >= 125 ),
		T( "Bardic Healer", 2, 44, c => Sk( c, SkillName.Healing ) >= 80.0 && Sk( c, SkillName.Musicianship ) >= 80.0 ),
		TG( "Priestess", "Priest", 2, 45, c => Sk( c, SkillName.Healing ) >= 80.0 ),
		T( "Cup Bearer", 2, 46, c => c.Str >= 10 && c.Dex >= 40 ),
		T( "Dapifer", 2, 47, c => c.Str >= 50 && c.Dex >= 40 ),
		T( "Doorward", 2, 48, c => Wpn( c, 60.0 ) && Sk( c, SkillName.Tactics ) >= 60.0 && c.Str >= 70 ),
		T( "Pursuivant", 2, 49, c => Wpn( c, 60.0 ) && Sk( c, SkillName.Tactics ) >= 60.0 ),
		T( "Herald", 2, 50, c => Wpn( c, 90.0 ) && Sk( c, SkillName.Tactics ) >= 90.0 ),
		T( "Jester", 2, 51, c => c.Str >= 20 && c.Dex >= 10 && c.Int >= 20 ),
		TG( "Lady in Waiting", "Gentleman in Waiting", 2, 52, c => c.Int >= 60 ),
		TG( "Lady of Honor", "Gentleman of Honor", 2, 53, c => c.Int >= 50 ),
		T( "Page", 2, 54, c => Wpn( c, 30.0 ) && Sk( c, SkillName.Tactics ) >= 30.0 && c.Str >= 30 ),
		T( "Pantler", 2, 55, c => Wpn( c, 50.0 ) && Sk( c, SkillName.Tactics ) >= 30.0 && c.Str >= 40 ),
		T( "Squire", 2, 56, _ => true ),
		T( "Steward", 2, 60, c => Wpn( c, 70.0 ) && Sk( c, SkillName.Tactics ) >= 70.0 && c.Str >= 60 ),
		T( "Jongleur", 2, 59, c => Sk( c, SkillName.Musicianship ) >= 30.0 && Sk( c, SkillName.Provocation ) >= 30.0 && Sk( c, SkillName.Peacemaking ) >= 30.0 && Sk( c, SkillName.Discordance ) >= 30.0 ),
		T( "Minstrel", 2, 57, c => Sk( c, SkillName.Musicianship ) >= 50.0 && Sk( c, SkillName.Provocation ) >= 50.0 && Sk( c, SkillName.Peacemaking ) >= 50.0 && Sk( c, SkillName.Discordance ) >= 50.0 ),
		T( "Troubadour", 2, 58, c => Sk( c, SkillName.Musicianship ) >= 90.0 && Sk( c, SkillName.Provocation ) >= 90.0 && Sk( c, SkillName.Peacemaking ) >= 90.0 && Sk( c, SkillName.Discordance ) >= 90.0 ),
	];

	private static readonly TitleEntry[] _pageTwoEntries =
	[
		T( "Dreamer", 4, 1, c => c.Int >= 40 ),
		T( "Landsknect", 4, 2, c => Sk( c, SkillName.Swords ) >= 80.0 && Sk( c, SkillName.Tactics ) >= 80.0 && Sk( c, SkillName.Parry ) >= 80.0 ),
		TG( "Crossbow-maiden", "Crossbow-man", 4, 3, c => Sk( c, SkillName.Archery ) >= 80.0 && Sk( c, SkillName.Tactics ) >= 80.0 ),
		TG( "Longbow-maiden", "Longbow-man", 4, 4, c => Sk( c, SkillName.Archery ) >= 80.0 && Sk( c, SkillName.Tactics ) >= 80.0 ),
		T( "Lancer", 4, 5, c => Sk( c, SkillName.Swords ) >= 90.0 && Sk( c, SkillName.Tactics ) >= 90.0 ),
		T( "Dragoon", 4, 6, c => Sk( c, SkillName.Swords ) >= 110.0 && Sk( c, SkillName.Tactics ) >= 110.0 ),
		T( "Calvary Archer", 4, 7, c => Sk( c, SkillName.Archery ) >= 110.0 && Sk( c, SkillName.Tactics ) >= 110.0 ),
		TG( "Maid", "Gentleman", 4, 8, c => c.Int >= 50 ),
		T( "Runner", 4, 9, c => c.Dex >= 60 ),
		T( "Sprinter", 4, 10, c => c.Dex >= 90 ),
		T( "Hammerdon", 4, 11, c => Sk( c, SkillName.Macing ) >= 110.0 && c.Str >= 125 ),
		T( "Healing Touch", 4, 12, c => Sk( c, SkillName.Healing ) >= 110.0 && Sk( c, SkillName.Anatomy ) >= 110.0 ),
		T( "Light Shade", 4, 13, c => Sk( c, SkillName.Healing ) >= 110.0 && Sk( c, SkillName.Hiding ) >= 110.0 ),
		TG( "Yeomaiden", "Yeoman", 4, 14, c => Sk( c, SkillName.Swords ) >= 60.0 && Sk( c, SkillName.Archery ) >= 60.0 ),
		T( "Attendant", 4, 15, c => Sk( c, SkillName.Tactics ) >= 50.0 && Sk( c, SkillName.Healing ) >= 60.0 ),
		T( "Dancer", 4, 16, c => Sk( c, SkillName.Wrestling ) >= 80.0 && Sk( c, SkillName.Musicianship ) >= 80.0 ),
		T( "Warrior", 4, 17, c => Sk( c, SkillName.Swords ) >= 80.0 && Sk( c, SkillName.Wrestling ) >= 80.0 && Sk( c, SkillName.Fencing ) >= 80.0 && Sk( c, SkillName.Tactics ) >= 80.0 && Sk( c, SkillName.Anatomy ) >= 80.0 ),
		T( "Freelancer", 4, 18, c => Sk( c, SkillName.Swords ) >= 50.0 && Sk( c, SkillName.Wrestling ) >= 50.0 && Sk( c, SkillName.Fencing ) >= 50.0 && Sk( c, SkillName.Tactics ) >= 50.0 && Sk( c, SkillName.Anatomy ) >= 50.0 && Sk( c, SkillName.Archery ) >= 50.0 ),
		T( "Thief", 4, 19, c => Sk( c, SkillName.Hiding ) >= 50.0 && Sk( c, SkillName.Stealing ) >= 50.0 ),
		T( "Dark Knight", 4, 20, c => Sk( c, SkillName.Hiding ) >= 90.0 && Sk( c, SkillName.Stealing ) >= 50.0 && Sk( c, SkillName.Parry ) >= 70.0 && ( Sk( c, SkillName.Swords ) >= 100.0 || Sk( c, SkillName.Macing ) >= 100.0 ) ),
		T( "Black Belt", 4, 21, c => Sk( c, SkillName.Wrestling ) >= 110.0 && Sk( c, SkillName.Tactics ) >= 110.0 && Sk( c, SkillName.Anatomy ) >= 110.0 ),
		T( "Devout", 4, 22, c => Sk( c, SkillName.Healing ) >= 110.0 && Sk( c, SkillName.Anatomy ) >= 110.0 ),
		T( "Hunter", 4, 23, c => Sk( c, SkillName.Archery ) >= 110.0 && Sk( c, SkillName.Tactics ) >= 110.0 ),
		T( "Defender", 4, 24, c => Sk( c, SkillName.Parry ) >= 70.0 ),
		T( "Wall", 4, 25, c => Sk( c, SkillName.Parry ) >= 100.0 ),
		T( "Gladiator", 4, 26, c => Sk( c, SkillName.Parry ) >= 100.0 && Sk( c, SkillName.Swords ) >= 100.0 ),
		T( "Sniper", 4, 27, c => Sk( c, SkillName.Archery ) >= 120.0 && Sk( c, SkillName.Tactics ) >= 120.0 && c.Dex >= 125 ),
		T( "Medic", 4, 28, c => Sk( c, SkillName.Healing ) >= 60.0 && Sk( c, SkillName.Anatomy ) >= 60.0 ),
		T( "Field Medic", 4, 29, c => Sk( c, SkillName.Healing ) >= 80.0 && Sk( c, SkillName.Anatomy ) >= 80.0 ),
		T( "Berserker", 4, 30, c => Sk( c, SkillName.Swords ) >= 100.0 && c.Str >= 100 ),
		T( "Ravager", 4, 31, c => Sk( c, SkillName.Macing ) >= 100.0 && c.Str >= 100 ),
		T( "Sword", 4, 32, c => Sk( c, SkillName.Swords ) >= 120.0 ),
		T( "Hammer", 4, 33, c => Sk( c, SkillName.Macing ) >= 120.0 ),
		T( "Bow", 4, 34, c => Sk( c, SkillName.Archery ) >= 120.0 ),
		T( "Point", 4, 35, c => Sk( c, SkillName.Fencing ) >= 120.0 ),
		T( "Bandage", 4, 36, c => Sk( c, SkillName.Healing ) >= 120.0 || Sk( c, SkillName.Veterinary ) >= 120.0 ),
		T( "Shield", 4, 37, c => Sk( c, SkillName.Parry ) >= 120.0 ),
		T( "Knife", 4, 38, c => Sk( c, SkillName.Stealing ) >= 120.0 ),
		T( "Cloak", 4, 39, c => Sk( c, SkillName.Hiding ) >= 120.0 ),
		T( "Weak", 4, 40, c => c.Str >= 10.0 ),
		T( "Slow", 4, 41, c => c.Dex >= 10.0 ),
		T( "Dim", 4, 42, c => c.Int >= 10.0 ),
		T( "Hidden", 4, 43, c => Sk( c, SkillName.Hiding ) >= 75.0 ),
		T( "Healing Blade", 4, 44, c => Sk( c, SkillName.Healing ) >= 75.0 && Sk( c, SkillName.Swords ) >= 75.0 ),
		T( "Song Sword", 4, 45, c => Sk( c, SkillName.Musicianship ) >= 75.0 && Sk( c, SkillName.Swords ) >= 75.0 ),
		T( "Caring Blade", 4, 46, c => Sk( c, SkillName.Veterinary ) >= 75.0 && Sk( c, SkillName.Swords ) >= 75.0 ),
		T( "Resting Sword", 4, 47, c => Sk( c, SkillName.Meditation ) >= 75.0 && Sk( c, SkillName.Swords ) >= 75.0 ),
		T( "Channeled Blade", 4, 48, c => Sk( c, SkillName.SpiritSpeak ) >= 75.0 && Sk( c, SkillName.Swords ) >= 75.0 ),
		T( "Stolen Sword", 4, 49, c => Sk( c, SkillName.Stealing ) >= 75.0 && Sk( c, SkillName.Swords ) >= 75.0 ),
		T( "Cutthroat", 4, 50, c => Sk( c, SkillName.Stealing ) >= 75.0 && Sk( c, SkillName.Swords ) >= 75.0 && Sk( c, SkillName.Hiding ) >= 75.0 ),
		T( "Spirit Channeler", 4, 51, c => Sk( c, SkillName.SpiritSpeak ) >= 90.0 && Sk( c, SkillName.Healing ) >= 90.0 ),
		T( "Fortune Teller", 4, 52, c => Sk( c, SkillName.SpiritSpeak ) >= 90.0 && Sk( c, SkillName.Meditation ) >= 90.0 ),
		T( "Hammer of Rest", 4, 53, c => Sk( c, SkillName.Macing ) >= 75.0 && Sk( c, SkillName.Meditation ) >= 75.0 ),
		T( "Channeled Hammer", 4, 54, c => Sk( c, SkillName.Macing ) >= 75.0 && Sk( c, SkillName.SpiritSpeak ) >= 75.0 ),
		T( "Hammer of Song", 4, 55, c => Sk( c, SkillName.Macing ) >= 75.0 && Sk( c, SkillName.Musicianship ) >= 75.0 ),
		T( "Healing Hammer", 4, 56, c => Sk( c, SkillName.Macing ) >= 75.0 && Sk( c, SkillName.Healing ) >= 75.0 ),
		T( "Caring Hammer", 4, 57, c => Sk( c, SkillName.Macing ) >= 75.0 && Sk( c, SkillName.Veterinary ) >= 75.0 ),
		T( "Singing Shot", 4, 58, c => Sk( c, SkillName.Archery ) >= 75.0 && Sk( c, SkillName.Musicianship ) >= 75.0 ),
		T( "Channeled Shot", 4, 59, c => Sk( c, SkillName.Archery ) >= 75.0 && Sk( c, SkillName.SpiritSpeak ) >= 75.0 ),
		T( "Healing Shot", 4, 60, c => Sk( c, SkillName.Archery ) >= 75.0 && Sk( c, SkillName.Healing ) >= 75.0 ),
	];

	private static readonly TitleEntry[] _pageThreeEntries =
	[
		T( "Assassin", 5, 1, c => Sk( c, SkillName.Poisoning ) > 30.0 ),
		T( "Toxic Shade", 5, 2, c => Sk( c, SkillName.Poisoning ) >= 100.0 && Sk( c, SkillName.Hiding ) >= 100.0 ),
		T( "Venomous Blade", 5, 3, c => Sk( c, SkillName.Poisoning ) >= 100.0 && Sk( c, SkillName.Swords ) >= 100.0 ),
		T( "Poison Shot", 5, 4, c => Sk( c, SkillName.Poisoning ) >= 100.0 && Sk( c, SkillName.Archery ) >= 100.0 ),
		T( "Traitorous Healer", 5, 5, c => Sk( c, SkillName.Poisoning ) >= 100.0 && Sk( c, SkillName.Healing ) >= 100.0 ),
		T( "Poisonous Point", 5, 6, c => Sk( c, SkillName.Poisoning ) >= 100.0 && Sk( c, SkillName.Fencing ) >= 100.0 ),
		T( "Singing Stab", 5, 7, c => Sk( c, SkillName.Musicianship ) >= 75.0 && Sk( c, SkillName.Fencing ) >= 75.0 ),
		T( "Healing Point", 5, 8, c => Sk( c, SkillName.Healing ) >= 75.0 && Sk( c, SkillName.Fencing ) >= 75.0 ),
		T( "Channelled Stab", 5, 9, c => Sk( c, SkillName.SpiritSpeak ) >= 75.0 && Sk( c, SkillName.Fencing ) >= 75.0 ),
		T( "Protected Point", 5, 10, c => Sk( c, SkillName.Parry ) >= 75.0 && Sk( c, SkillName.Fencing ) >= 75.0 ),
		T( "Rested Point", 5, 11, c => Sk( c, SkillName.Meditation ) >= 75.0 && Sk( c, SkillName.Fencing ) >= 75.0 ),
		T( "Serpent's Tooth", 5, 12, c => Sk( c, SkillName.Poisoning ) >= 75.0 && Sk( c, SkillName.Fencing ) >= 75.0 ),
		T( "Serpent's Fang", 5, 13, c => Sk( c, SkillName.Poisoning ) >= 75.0 && Sk( c, SkillName.Fencing ) >= 75.0 && Sk( c, SkillName.Tactics ) >= 75.0 && c.Dex >= 70 ),
		T( "Strong Poison", 5, 14, c => Sk( c, SkillName.Poisoning ) >= 80.0 && c.Str >= 75 ),
		T( "Quick Poison", 5, 15, c => Sk( c, SkillName.Poisoning ) >= 80.0 && c.Dex >= 75 ),
		T( "Smart Poison", 5, 16, c => Sk( c, SkillName.Poisoning ) >= 80.0 && c.Int >= 75 ),
		T( "Channelled Venom", 5, 17, c => Sk( c, SkillName.Poisoning ) >= 75.0 && Sk( c, SkillName.SpiritSpeak ) >= 75.0 ),
		T( "Villain", 5, 18, c => Sk( c, SkillName.Poisoning ) >= 100.0 && Sk( c, SkillName.Hiding ) >= 100.0 && Sk( c, SkillName.Stealing ) >= 100.0 ),
		T( "Blunt Poison", 5, 19, c => Sk( c, SkillName.Poisoning ) >= 75.0 && Sk( c, SkillName.Macing ) >= 75.0 ),
		T( "Stolen Venom", 5, 20, c => Sk( c, SkillName.Poisoning ) >= 75.0 && Sk( c, SkillName.Stealing ) >= 75.0 ),
		T( "Caring Point", 5, 21, c => Sk( c, SkillName.Veterinary ) >= 75.0 && Sk( c, SkillName.Fencing ) >= 75.0 ),
		T( "Caring Shot", 5, 22, c => Sk( c, SkillName.Veterinary ) >= 75.0 && Sk( c, SkillName.Archery ) >= 75.0 ),
		T( "Healing Shot", 5, 23, c => Sk( c, SkillName.Healing ) >= 75.0 && Sk( c, SkillName.Archery ) >= 75.0 ),
		T( "True Defender", 5, 24, c => Sk( c, SkillName.Parry ) >= 100.0 && Sk( c, SkillName.MagicResist ) >= 100.0 ),
		T( "Resistant Wall", 5, 25, c => Sk( c, SkillName.Parry ) >= 110.0 && Sk( c, SkillName.MagicResist ) >= 110.0 ),
		T( "Channelled Bubble", 5, 26, c => Sk( c, SkillName.SpiritSpeak ) >= 80.0 && Sk( c, SkillName.MagicResist ) >= 80.0 ),
		T( "Protector", 5, 27, c => Sk( c, SkillName.Swords ) >= 90.0 && Sk( c, SkillName.MagicResist ) >= 90.0 && Sk( c, SkillName.Parry ) >= 90.0 ),
		T( "Soldier", 5, 28, c => Sk( c, SkillName.Swords ) >= 50.0 && Sk( c, SkillName.Fencing ) >= 50.0 && Sk( c, SkillName.Macing ) >= 50.0 && Sk( c, SkillName.Archery ) >= 50.0 ),
		T( "Disciple", 5, 29, c => Sk( c, SkillName.MagicResist ) >= 30.0 && Sk( c, SkillName.Meditation ) >= 30.0 && Sk( c, SkillName.SpiritSpeak ) >= 30.0 && Sk( c, SkillName.Healing ) >= 30.0 && Sk( c, SkillName.Veterinary ) >= 30.0 ),
		T( "Mercenary", 5, 30, c => Wpn( c, 70.0 ) ),
		T( "Veteran", 5, 31, c => Sk( c, SkillName.Swords ) >= 95.0 && Sk( c, SkillName.Fencing ) >= 95.0 && Sk( c, SkillName.Macing ) >= 95.0 && Sk( c, SkillName.Archery ) >= 95.0 ),
		T( "Mentor", 5, 32, c => c.SkillsTotal >= 700.0 ),
		T( "Recruit", 5, 33, c => Sk( c, SkillName.Swords ) >= 20.0 && Sk( c, SkillName.Fencing ) >= 20.0 && Sk( c, SkillName.Macing ) >= 20.0 && Sk( c, SkillName.Archery ) >= 20.0 ),
		T( "Initiate", 5, 34, c => Sk( c, SkillName.Swords ) >= 35.0 && Sk( c, SkillName.Fencing ) >= 35.0 && Sk( c, SkillName.Macing ) >= 35.0 && Sk( c, SkillName.Archery ) >= 35.0 ),
		T( "True Assassin", 5, 35, c => Sk( c, SkillName.Poisoning ) >= 95.0 && Sk( c, SkillName.Fencing ) >= 95.0 && Sk( c, SkillName.Hiding ) >= 95.0 ),
		T( "Thrifty", 5, 36, c => c.Dex >= 80 && c.Int >= 80 ),
		T( "Poor", 5, 37, c => c.TotalGold <= 100 ),
		T( "Moderately Wealthy", 5, 38, c => c.TotalGold >= 1000 ),
		T( "Wealthy", 5, 39, c => c.TotalGold >= 5000 ),
		T( "Pretty Rich", 5, 40, c => c.TotalGold >= 10000 ),
		T( "Rich", 5, 41, c => c.TotalGold >= 50000 ),
		T( "Filthy Rich", 5, 42, c => c.TotalGold >= 100000 ),
		T( "Mysterious", 5, 43, c => Sk( c, SkillName.SpiritSpeak ) >= 90.0 && Sk( c, SkillName.Hiding ) >= 90.0 ),
		T( "Toxic Mystery", 5, 44, c => Sk( c, SkillName.SpiritSpeak ) >= 90.0 && Sk( c, SkillName.Hiding ) >= 90.0 && Sk( c, SkillName.Poisoning ) >= 90.0 ),
		T( "Athlete", 5, 45, c => c.Str >= 100 ),
		T( "Desperado", 5, 46, c => c.Dex >= 100 && Sk( c, SkillName.Archery ) >= 100.0 && Sk( c, SkillName.Tactics ) >= 100.0 && Sk( c, SkillName.Stealing ) >= 50.0 ),
		T( "Sneaky", 5, 47, c => c.Dex >= 100 && Sk( c, SkillName.Hiding ) >= 100.0 ),
		T( "Sword Artist", 5, 48, c => Sk( c, SkillName.Fencing ) >= 100.0 && Sk( c, SkillName.Swords ) >= 100.0 ),
		TG( "Huntress", "Hunter", 5, 49, c => Sk( c, SkillName.Archery ) >= 100.0 && Sk( c, SkillName.Swords ) >= 100.0 ),
		T( "Troublesome", 5, 50, c => Sk( c, SkillName.Stealing ) >= 60.0 && Sk( c, SkillName.Poisoning ) >= 60.0 ),
		T( "Acolyte", 5, 51, c => Sk( c, SkillName.Healing ) >= 60.0 && Sk( c, SkillName.Veterinary ) >= 60.0 && Sk( c, SkillName.SpiritSpeak ) >= 60.0 ),
		T( "Wingleader", 5, 52, c => Wpn( c, 90.0 ) && Sk( c, SkillName.Tactics ) >= 120.0 ),
		T( "Mama Jama", 5, 53, c => c.Str >= 110 && c.Int >= 70 && c.Dex >= 90 ),
		T( "Rum Thief", 5, 54, c => c.Dex >= 40 && Sk( c, SkillName.Stealing ) >= 50.0 ),
		T( "Red-Hand", 5, 55, c => c.Dex >= 80 && Sk( c, SkillName.Stealing ) >= 80.0 ),
		T( "Heretic", 5, 56, c => c.Dex >= 90 && Sk( c, SkillName.Stealing ) >= 90.0 ),
		T( "Sly", 5, 57, c => Sk( c, SkillName.Poisoning ) >= 90.0 && Sk( c, SkillName.Stealing ) >= 90.0 && Sk( c, SkillName.Hiding ) >= 90.0 && c.Int >= 80 ),
		T( "Glorious", 5, 58, c => Sk( c, SkillName.Parry ) >= 100.0 && Sk( c, SkillName.MagicResist ) >= 100.0 && c.Str >= 120 ),
		T( "Stalker", 5, 59, c => Sk( c, SkillName.Hiding ) >= 70.0 && c.Dex >= 90 ),
		T( "Deadeye", 5, 60, c => Sk( c, SkillName.Archery ) >= 120.0 && c.Dex >= 125, "the Stalker" ),
	];

	private static readonly TitleEntry[] _pageFourEntries =
	[
		T( "Paladin", 6, 1, c => Sk( c, SkillName.Chivalry ) > 30.0 ),
		T( "Holy Sword", 6, 2, c => Sk( c, SkillName.Chivalry ) > 75.0 && Sk( c, SkillName.Swords ) > 75.0 ),
		T( "Holy Hammer", 6, 3, c => Sk( c, SkillName.Chivalry ) > 75.0 && Sk( c, SkillName.Macing ) > 75.0 ),
		T( "Holy Striker", 6, 4, c => Sk( c, SkillName.Chivalry ) > 75.0 && Sk( c, SkillName.Fencing ) > 75.0 ),
		T( "Holy Channel", 6, 5, c => Sk( c, SkillName.Chivalry ) > 75.0 && Sk( c, SkillName.SpiritSpeak ) > 75.0 ),
		T( "Holy Shade", 6, 6, c => Sk( c, SkillName.Chivalry ) > 75.0 && Sk( c, SkillName.Hiding ) > 75.0 ),
		T( "Holy Healer", 6, 7, c => Sk( c, SkillName.Chivalry ) > 75.0 && Sk( c, SkillName.Healing ) > 75.0 ),
		T( "Holy Shield", 6, 8, c => Sk( c, SkillName.Chivalry ) > 75.0 && Sk( c, SkillName.Parry ) > 75.0 ),
		T( "Slightly Devoted", 6, 9, c => c.TithingPoints > 0 ),
		T( "Kinda Devoted", 6, 10, c => c.TithingPoints > 1000 ),
		T( "Devoted", 6, 11, c => c.TithingPoints > 10000 ),
		T( "Very Devoted", 6, 12, c => c.TithingPoints > 50000 ),
		T( "Extremely Devoted", 6, 13, c => c.TithingPoints > 100000 ),
		T( "True Paladin", 6, 14, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.Swords ) >= 100.0 && Sk( c, SkillName.Parry ) >= 100.0 ),
		T( "Holy Toxin", 6, 15, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.Poisoning ) >= 100.0 ),
		T( "Holy Shot", 6, 16, c => Sk( c, SkillName.Chivalry ) >= 75.0 && Sk( c, SkillName.Archery ) >= 75.0 ),
		T( "Blessed Ranger", 6, 17, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.Archery ) >= 100.0 ),
		T( "Caring Light", 6, 18, c => Sk( c, SkillName.Chivalry ) >= 75.0 && Sk( c, SkillName.Veterinary ) >= 75.0 ),
		T( "Holy Light", 6, 19, c => Sk( c, SkillName.Chivalry ) >= 75.0 && Sk( c, SkillName.Veterinary ) >= 75.0 && Sk( c, SkillName.Healing ) >= 75.0 ),
		T( "Holy Song", 6, 20, c => Sk( c, SkillName.Chivalry ) >= 75.0 && Sk( c, SkillName.Musicianship ) >= 75.0 ),
		T( "Strong Paladin", 6, 21, c => Sk( c, SkillName.Chivalry ) >= 100.0 && c.Str >= 100 ),
		T( "Smart Paladin", 6, 22, c => Sk( c, SkillName.Chivalry ) >= 100.0 && c.Int >= 100 ),
		T( "Quick Paladin", 6, 23, c => Sk( c, SkillName.Chivalry ) >= 100.0 && c.Dex >= 100 ),
		T( "Worthy", 6, 24, c => Sk( c, SkillName.Chivalry ) >= 50.0 ),
		T( "Despicable", 6, 25, c => Sk( c, SkillName.Poisoning ) >= 50.0 ),
		T( "Shining Shadow", 6, 26, c => Sk( c, SkillName.Poisoning ) >= 75.0 && Sk( c, SkillName.Chivalry ) >= 75.0 && Sk( c, SkillName.Hiding ) >= 75.0 && Sk( c, SkillName.Stealing ) >= 75.0 ),
		T( "Foetid", 6, 27, c => Sk( c, SkillName.Poisoning ) >= 75.0 ),
		T( "Holy Warrior", 6, 28, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Wpn( c, 100.0 ) ),
		TG( "Vixen", "Fox", 6, 29, _ => true ),
		T( "Holy Focus", 6, 30, c => Sk( c, SkillName.Focus ) >= 100.0 && Sk( c, SkillName.Chivalry ) >= 100.0 ),
		T( "Holy Tactician", 6, 31, c => Sk( c, SkillName.Tactics ) >= 100.0 && Sk( c, SkillName.Chivalry ) >= 100.0 ),
		T( "Holy Thief", 6, 32, c => Sk( c, SkillName.Stealing ) >= 100.0 && Sk( c, SkillName.Chivalry ) >= 100.0 ),
		T( "Faithless", 6, 33, c => Sk( c, SkillName.Chivalry ) == 0.0 ),
		T( "Humble", 6, 34, c => Sk( c, SkillName.Chivalry ) >= 25.0 && Sk( c, SkillName.Healing ) >= 25.0 && Sk( c, SkillName.Veterinary ) >= 25.0 ),
		TG( "Nun", "Priest", 6, 35, c => Sk( c, SkillName.Chivalry ) >= 50.0 && Sk( c, SkillName.Healing ) >= 50.0 && Sk( c, SkillName.Veterinary ) >= 50.0 ),
		T( "True Healer", 6, 36, c => Sk( c, SkillName.Chivalry ) >= 75.0 && Sk( c, SkillName.Healing ) >= 75.0 && Sk( c, SkillName.Veterinary ) >= 75.0 ),
		T( "True Holy Healer", 6, 37, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.Healing ) >= 100.0 && Sk( c, SkillName.Veterinary ) >= 100.0 ),
		T( "Ruffian", 6, 38, c => Sk( c, SkillName.Swords ) >= 100.0 && Sk( c, SkillName.Stealing ) >= 100.0 ),
		T( "Pure", 6, 39, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.Healing ) >= 100.0 && Sk( c, SkillName.Stealing ) == 0.0 && Sk( c, SkillName.Poisoning ) == 0.0 ),
		T( "Holy Templar", 6, 40, c => Sk( c, SkillName.Chivalry ) >= 80.0 && Sk( c, SkillName.Parry ) >= 80.0 && ( Sk( c, SkillName.Swords ) >= 80.0 || Sk( c, SkillName.Macing ) >= 80.0 ) ),
		T( "Invoker", 6, 41, c => Sk( c, SkillName.Provocation ) >= 110.0 ),
		T( "Holy Peacemaker", 6, 42, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.Peacemaking ) >= 100.0 ),
		T( "True Hope", 6, 43, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.Peacemaking ) >= 100.0 && Sk( c, SkillName.Healing ) >= 100.0 && Sk( c, SkillName.Veterinary ) >= 100.0 ),
		T( "Adventurous", 6, 44, c => Sk( c, SkillName.Swords ) >= 70.0 && Sk( c, SkillName.Archery ) >= 70.0 ),
		T( "Fighter", 6, 45, c => Sk( c, SkillName.Swords ) >= 70.0 && Sk( c, SkillName.Archery ) >= 70.0 && Sk( c, SkillName.Macing ) >= 70.0 && Sk( c, SkillName.Fencing ) >= 70.0 ),
		T( "Skilled", 6, 46, c => c.SkillsTotal >= 6000 ),
		T( "Human", 6, 47, c => c.Race == Race.Human || c.Race == Race.Elf, c => c.Race == Race.Human ? "the Human" : "the Elf" ),
		TG( "Girl", "Boy", 6, 48, _ => true ),
		TG( "Woman", "Man", 6, 49, _ => true ),
		TG( "Heroine", "Hero", 6, 50, c => Sk( c, SkillName.Chivalry ) >= 110.0 && Sk( c, SkillName.Swords ) >= 110.0 ),
		T( "Tempest", 6, 51, c => Sk( c, SkillName.Chivalry ) >= 90.0 && Sk( c, SkillName.Poisoning ) >= 90.0 && Sk( c, SkillName.Swords ) >= 90.0 && Sk( c, SkillName.Archery ) >= 90.0 && Sk( c, SkillName.Macing ) >= 90.0 && Sk( c, SkillName.Fencing ) >= 90.0 ),
		T( "Uber", 6, 52, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.Swords ) >= 100.0 && Sk( c, SkillName.Archery ) >= 100.0 && Sk( c, SkillName.Macing ) >= 100.0 && Sk( c, SkillName.Fencing ) >= 100.0 ),
		T( "Tank", 6, 53, c => Sk( c, SkillName.Chivalry ) >= 80.0 && Sk( c, SkillName.Parry ) >= 80.0 && Sk( c, SkillName.MagicResist ) >= 80.0 ),
		T( "Holy Bubble", 6, 54, c => Sk( c, SkillName.Chivalry ) >= 75.0 && Sk( c, SkillName.MagicResist ) >= 75.0 ),
		T( "Panzer", 6, 55, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.MagicResist ) >= 100.0 && Sk( c, SkillName.Parry ) >= 100.0 ),
		T( "Great Paladin", 6, 56, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.MagicResist ) >= 100.0 && Sk( c, SkillName.Parry ) >= 100.0 && Sk( c, SkillName.Swords ) >= 100.0 ),
		T( "Great Hammerdin", 6, 57, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.MagicResist ) >= 100.0 && Sk( c, SkillName.Parry ) >= 100.0 && Sk( c, SkillName.Macing ) >= 100.0 ),
		T( "Great Defender", 6, 58, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.MagicResist ) >= 100.0 && Sk( c, SkillName.Parry ) >= 100.0 && Sk( c, SkillName.Wrestling ) >= 100.0 ),
		T( "Great Piercer", 6, 59, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.MagicResist ) >= 100.0 && Sk( c, SkillName.Parry ) >= 100.0 && Sk( c, SkillName.Fencing ) >= 100.0 ),
		T( "Great Ranger", 6, 60, c => Sk( c, SkillName.Chivalry ) >= 100.0 && Sk( c, SkillName.MagicResist ) >= 100.0 && Sk( c, SkillName.Archery ) >= 100.0 ),
	];

	public SquireTitleGump( BaseCreature c, Mobile from, SquireTitlePage page ) : base( 250, 50 )
	{
		_squire = c;
		_from = from;
		_page = page;
	}

	private static TitleEntry[] GetEntries( SquireTitlePage page ) => page switch
	{
		SquireTitlePage.PageTwo => _pageTwoEntries,
		SquireTitlePage.PageThree => _pageThreeEntries,
		SquireTitlePage.PageFour => _pageFourEntries,
		_ => _pageOneEntries
	};

	private static TitleEntry FindEntry( TitleEntry[] entries, int index )
	{
		foreach( var entry in entries )
		{
			if( entry.Index == index )
				return entry;
		}
		return null;
	}

	public override void OnResponse( NetState sender, in RelayInfo info )
	{
		int buttonID = info.ButtonID - 1;
		int index = buttonID / 15;
		int type = buttonID % 15;

		BaseCreature c = _squire;
		SquireTitlePage page = _page;

		switch( type )
		{
			default:
			{
				_from.CloseGump<SquireTitleGump>();
				break;
			}
			case 1:
			{
				var target = index switch
				{
					2 => SquireTitlePage.PageTwo,
					3 => SquireTitlePage.PageThree,
					4 => SquireTitlePage.PageFour,
					_ => SquireTitlePage.PageOne
				};
				_from.SendGump( new SquireTitleGump( c, _from, target ) );
				break;
			}
			case 2:
			{
				if( index >= 1 && index <= 22 )
				{
					var (skill, name) = _skillTitleNames[index - 1];
					_squire.Title = GetPrefix( c.Skills[skill].Base ) + name;
				}
				else
				{
					var entry = FindEntry( _pageOneEntries, index );
					if( entry != null )
						_squire.Title = entry.Title( c );
				}
				Resend( SquireTitlePage.PageOne );
				break;
			}
			case 3:
			{
				if( index == 1 )
					_squire.Title = "";
				Resend( SquireTitlePage.PageOne );
				break;
			}
			case 4:
			case 5:
			case 6:
			{
				var entry = FindEntry( GetEntries( page ), index );
				if( entry != null )
					_squire.Title = entry.Title( c );
				Resend( page );
				break;
			}
		}
	}

	private void Resend( SquireTitlePage page )
	{
		_from.CloseGump<SquireTitleGump>();
		_from.SendGump( new SquireTitleGump( _squire, _from, page ) );
	}

	protected override void BuildLayout( ref DynamicGumpBuilder builder )
	{
		var c = _squire;
		var from = _from;
		var page = _page;

		from.CloseGump<SquireTitleGump>();

		builder.AddPage();

		builder.AddBackground( 0, 0, 460, 422, 5054 );
		builder.AddImageTiled( 10, 10, 440, 402, 2624 );
		builder.AddAlphaRegion( 10, 10, 440, 402 );

		builder.AddHtml( 120, 10, 210, 18, $"<basefont color=#FFFFFF><center><i>{c.Name}</i></center></basefont>", background: false, scrollbar: false );

		var pageName = page switch
		{
			SquireTitlePage.PageTwo => "Two",
			SquireTitlePage.PageThree => "Three",
			SquireTitlePage.PageFour => "Four",
			_ => "One"
		};
		builder.AddHtml( 145, 24, 160, 18, $"<basefont color=#FFD57A><center>Titles Page: {pageName}</center></basefont>", background: false, scrollbar: false );

		builder.AddHtml( 49, 20, 160, 18, "<basefont color=#FFD57A>None</basefont>", background: false, scrollbar: false );
		builder.AddButton( 20, 14, 0x9A8, 0x9AA, GetButtonID( 3, 1 ), GumpButtonType.Reply, 0 );

		var entries = GetEntries( page );
		AddColumn( ref builder, c, entries, 0, 20 );
		AddColumn( ref builder, c, entries, 20, 160 );
		AddColumn( ref builder, c, entries, 40, 300 );

		if( ( c.Controlled && from == c.ControlMaster ) || from.AccessLevel >= AccessLevel.GameMaster )
		{
			var (label, navIndex) = page switch
			{
				SquireTitlePage.PageTwo => ( "Page Three", 3 ),
				SquireTitlePage.PageThree => ( "Page Four", 4 ),
				SquireTitlePage.PageFour => ( "Page One", 1 ),
				_ => ( "Page Two", 2 )
			};
			builder.AddHtml( 353, 20, 160, 18, $"<basefont color=#FFD57A>{label}</basefont>", background: false, scrollbar: false );
			builder.AddButton( 417, 22, 5601, 5605, GetButtonID( 1, navIndex ), GumpButtonType.Reply, 0 );
		}
	}

	private static void AddColumn( ref DynamicGumpBuilder builder, BaseCreature c, TitleEntry[] entries, int start, int x )
	{
		int end = Math.Min( start + 20, entries.Length );

		for( int i = start; i < end; i++ )
		{
			int y = 40 + ( i - start ) * 18;
			var entry = entries[i];
			if( entry.Available( c ) )
			{
				builder.AddHtml( x + 18, y, 160, 18, $"<basefont color=#FFD57A>{entry.Label( c )}</basefont>", background: false, scrollbar: false );
				builder.AddButton( x, y + 2, 0x845, 0x846, GetButtonID( entry.Type, entry.Index ), GumpButtonType.Reply, 0 );
			}
			else
			{
				builder.AddHtml( x + 18, y, 160, 18, "<basefont color=#808080>???</basefont>", background: false, scrollbar: false );
			}
		}
	}
}
