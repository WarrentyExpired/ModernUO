using System;
using Server;
using Server.Items;
using Server.Mobiles;
using Server.Network;
using Server.Gumps;
using System.Collections.Generic;
using Server.Targeting;
using Server.Prompts;

namespace Server.Mobiles;
	public class SquireNewNickname : Prompt
	{
		private Squire _squire;

		public SquireNewNickname( Squire squire )
		{
			_squire = squire;
		}

		public override void OnResponse( Mobile from, string text )
		{
			_squire.SetNickname( from, text );
		}
	}

	public class NewSquireNickname : Prompt
	{
		private Squire _squire;

		public NewSquireNickname( Squire squire )
		{
			_squire = squire;
		}

		public override void OnResponse( Mobile from, string text )
		{
			_squire.SetSNickname( from, text );
		}
	}

	public class SquirePack
	{
		public static bool CheckAccess( BaseCreature squire, Mobile from )
		{
			if ( from == squire || from.AccessLevel >= AccessLevel.GameMaster )
				return true;

			if ( from.Alive && squire.Controlled && !squire.IsDeadPet && from == squire.ControlMaster )
				return true;

			return false;
		}

		public static void TryPackOpen( BaseCreature squire, Mobile from )
		{
			if ( squire.IsDeadPet )
				return;

			Container item = squire.Backpack;

			if ( CheckAccess( squire, from ) )
				if ( item != null )
					from.Use( item );
		}
	}

	public class SquireSpiritSpeakTimer : Timer
	{
		private Squire _squire;
		public SquireSpiritSpeakTimer( Squire squire ) : base( TimeSpan.FromMinutes( 2.0 ) )
		{
			_squire = squire;
		}

		protected override void OnTick()
		{
			_squire.CanHearGhosts = false;
			_squire._spiritWorldConnected = false;
			_squire.FixedParticles( 0x375A, 1, 15, 9501, 2100, 4, EffectLayer.Waist );
			if( !_squire._squireBeQuiet )
			{
				SquireDialog.DoSquireDialog( _squire, SquireDialogTree.SpiritChannelFades );
			}
		}
	}

	public class SquireSpiritAnimTimer : Timer
	{
		private Squire _squire;
		public SquireSpiritAnimTimer( Squire squire ) : base( TimeSpan.FromSeconds( 0.1 ) )
		{
			_squire = squire;
		}

		protected override void OnTick()
		{
			_squire.Animate( 17, 7, 1, true, false, 0 );
		}
	}

	public class SquireQuiver
	{
		public static bool CheckAccess( BaseCreature squire, Mobile from )
		{
			if ( from == squire || from.AccessLevel >= AccessLevel.GameMaster )
				return true;

			if ( from.Alive && squire.Controlled && !squire.IsDeadPet && from == squire.ControlMaster )
				return true;

			return false;
		}

		public static void TryPackOpen( BaseCreature squire, Mobile from )
		{
			if ( squire.IsDeadPet )
				return;

			Item QuiverCheck = squire.FindItemOnLayer( Layer.Cloak );

			if( QuiverCheck is BaseQuiver )
			{
				Container item = (Container)QuiverCheck;

				if ( CheckAccess( squire, from ) )
				{
					if ( item != null )
					{
						from.Use( item );
						if( !((Squire)squire)._squireBeQuiet )
						{
							SquireDialog.DoSquireDialog( (Squire)squire, SquireDialogTree.OpenQuiver );
						}
					}
				}
			}
			else
			{
				if( !((Squire)squire)._squireBeQuiet )
				{
					SquireDialog.DoSquireDialog( (Squire)squire, SquireDialogTree.NotAQuiver );
				}
			}
		}
	}

	public class NewSquireTeam : Prompt
	{
		private Squire _squire;

		public NewSquireTeam( Squire squire )
		{
			_squire = squire;
		}

		public override void OnResponse( Mobile from, string text )
		{
			_squire.SetSquireTeam( from, text );
		}
	}
