using Server;
using Server.Gumps;
using Server.Mobiles;
using Server.Targeting;

namespace Server.Commands;

public class SquireLoreTarget : Target
{
    private readonly SquireLorePage _page;
    private readonly string _aspect;

    public SquireLoreTarget(SquireLorePage page, string aspect) : base(15, false, TargetFlags.None)
    {
        _page = page;
        _aspect = aspect;
    }

    protected override void OnTarget(Mobile from, object targ)
    {
        if (targ is PlayerMobile)
        {
            from.SendMessage($"You cannot use this gump to view PlayerMobile's {_aspect}.");
            return;
        }

        if (targ is Squire squire)
        {
            from.SendGump(new SquireLoreGump(squire, from, _page));
            from.SendMessage("Displaying Squire Lore Gump");
            return;
        }

        from.SendMessage("Unable to display gump.");
    }
}

public class SquireSkills
{
    public static void Initialize() => CommandSystem.Register("SquireSkills", AccessLevel.GameMaster, SquireSkills_OnCommand);

    [Usage("SquireSkills")]
    [Description("Investigates the skills of a creature using the Squire Lore Gump window.")]
    private static void SquireSkills_OnCommand(CommandEventArgs e)
    {
        e.Mobile.Target = new SquireLoreTarget(SquireLorePage.Skills, "skills");
        e.Mobile.SendMessage("Who's skills do you wish to see?");
    }
}

public class SquireStats
{
    public static void Initialize() => CommandSystem.Register("SquireStats", AccessLevel.GameMaster, SquireStats_OnCommand);

    [Usage("SquireStats")]
    [Description("Investigates the stats of a creature using the Squire Lore Gump window.")]
    private static void SquireStats_OnCommand(CommandEventArgs e)
    {
        e.Mobile.Target = new SquireLoreTarget(SquireLorePage.Stats, "stats");
        e.Mobile.SendMessage("Who's stats do you wish to see?");
    }
}

public class SquireSwitches
{
    public static void Initialize() => CommandSystem.Register("SquireSwitches", AccessLevel.GameMaster, SquireSwitches_OnCommand);

    [Usage("SquireSwitches")]
    [Description("Investigates the switches of a creature using the Squire Lore Gump window.")]
    private static void SquireSwitches_OnCommand(CommandEventArgs e)
    {
        e.Mobile.Target = new SquireLoreTarget(SquireLorePage.Switches, "switches");
        e.Mobile.SendMessage("Who's switches do you wish to see?");
    }
}
