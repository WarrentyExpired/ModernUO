# SquireSystem — Features Guide
The squire is a full-fledged AI companion: battle partner, healer, looter and bard in one. Counts as 3 pet slots.

---

## 1. Getting a Squire

1. Buy a **Squire Contract (5000 gp)** from the **Squire Representative** (squire guild representative).
2. Use the contract — the squire appears next to you.
3. Squires are **bonded from the start**: on death they do not vanish but turn into a ghost and can be resurrected.

## 2. Control

### Speech commands
Say out loud (near the squire):
- **"<squire name> <command>"** — command one: `attack`, `kill`, `guard`, `guard me`, `come`, `stop`, `stay`, `follow me`, `mount`, `dismount`, `dress`, `undress`, `arm`, `unarm`, `grab all`, `loot all`, `unload`, `list`, `stats`, `skills`, `switches`, `tithe`, `hide`, `spirit speak`, `poison`…
- **"all <command>"** — command all your squires at once (all attack, all stay…).
- **Nicknames:** set nicknames for yourself and the squire ("How to call me" / "Squire nickname" in Settings) — commands work by nickname too.

### Command gump (pet button)
Double-clicking the squire opens a categorized command gump: **General, Combat, Equipment, Looting, Info, Spells, Settings**. Everything available by speech is also a button.

### Lore gump (Stats page)
Pet button → three pages:
- **Stats** — hits/stam/mana, stats, tithing, loyalty, nicknames, title, command, resists, damage.
- **Skills** — 27 skills with values and **locks** (Up/Down/Locked — same as players).
- **Switches** — ~30 automations (see section 4).

## 3. Training

Instructors (Combat / Healing / Barding / Thieving) sell **training contracts (500 gp, Bushido 300)**:
- target the contract at the squire — the skill rises instantly;
- up to 30.0 — one contract; then +15 / +5 / +2 / +1 depending on the current value;
- at 100.0 the contract is not consumed (the squire says it is not ready to learn more).

## 4. Automations (Switches)

| Group | What it does |
|---|---|
| **Healing** | Auto Heal Self / Master / Others / Animals; Auto Cure Potion; Auto Spirit Speak; Auto Rez Master; Auto Rez Ally |
| **Chivalry** | Close Wounds (Self/Master/Ally); Cleanse by Fire (Self/Master/Ally) |
| **Looting** | Auto Loot; Loot Only Select Items; filters Gold / Treasure Maps / Zoogi Fungus / Daemon Bone; Convenient Stackable Loot; Auto Equip Loot |
| **Misc** | Auto Pickup Ammo (arrows into the quiver); Auto Use Health Potion; Auto Use Training/Power Scroll; Desperate Master Run; Be Quiet; Auto Cast Vampire (Vampiric Embrace) |
| **Social** | **Inspectable** — allow other players to view your squire via the spyglass |

## 5. Looting

- **Grab All / Loot All** — loot all corpses nearby (radius 3).
- **Loot (target a corpse)**, **Grab (target an item)**.
- **Unload** — hand over the entire squire's pack to yourself.
- Player corpses are **never** touched; "blue" corpses — only via Loot All.

## 6. Abilities

- **Healing:** bandages (Healing/Veterinary), heals animals too; resurrects the master (Spirit Speak + bandage) and allies.
- **Chivalry:** tithing at an ankh ("Name tithe"), Close Wounds, Cleanse by Fire, Consecrate Weapon, Divine Fury, Enemy of One, Holy Light, Noble Sacrifice, Remove Curse, Dispel Evil.
- **Necromancy:** Vampiric Embrace, Wraith Form, Lich Form, Curse Weapon, Pain Spike, Poison Strike, Wither (needs a Necromancy book and skill).
- **Bushido:** Confidence, Lightning Strike, etc. (needs a Bushido book).
- **Barding:** provoke / peace / discord by target.
- **Thieving:** steal, lockpick, hiding, poisoning — via targets; criminal flag goes to the squire.
- **Explosion potions, snowballs** — by target.

## 7. Squire Room (Carrier Pigeon)

Tell the **innkeeper** (`vendor room`) or the **house room attendant** (`room`): for 300 gp the squire "goes to a room" and you receive a **Carrier Pigeon**. Double-click the pigeon — the squire returns to you.
⚠️ The pigeon knows only its owners; don't lose it — deleting the pigeon means losing the squire.

## 8. Customization

- **Settings → Appearance (restyle):** hairstyle, beard, hues (including elven styles).
- **Rename yourself, Change title** — titles by skill: Neophyte (30) → Legendary (120).
- **Assign team** — squad name for "all" commands and display.

## 9. Spyglass (Squire Inspection Spyglass, 200 gp)

Lets other players view Stats/Skills/Switches of your squire — **only if the "Inspectable" switch is on**. The squire cannot be controlled through the spyglass.

## 10. Tips

- "Be Quiet" disables all squire chatter.
- The squire picks up arrows/bolts from the ground into the quiver automatically (Auto Pickup Ammo).
- "Desperate Master Run" — the squire flees danger if the master dies.
- Every command is available by speech and by gump — use whichever is convenient.
