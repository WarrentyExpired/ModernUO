using System.Collections.Generic;
using ModernUO.Serialization;
using Server;
using Server.Items;
namespace Server.Mobiles;

[SerializationGenerator(0, false)]
public partial class SquireCombatInstructor : BaseVendor
{
	private readonly List<SBInfo> _sBInfos = [];
	protected override List<SBInfo> SBInfos => _sBInfos;

	[Constructible]
	public SquireCombatInstructor() : base("the squire combat instructor")
	{
		SetSkill(SkillName.Fencing, 75.0, 85.0);
		SetSkill(SkillName.Macing, 75.0, 85.0);
		SetSkill(SkillName.Swords, 75.0, 85.0);
		SetSkill(SkillName.Chivalry, 100.0);
	}

	public override void InitSBInfo()
	{
		_sBInfos.Add(new SBSquireCombatInstructor());
	}
	
	public override void InitOutfit()
	{
		AddItem(new RingmailChest());
		AddItem(new RingmailLegs());
		AddItem(new RingmailArms());
		AddItem(new RingmailGloves());

		AddItem(Utility.Random(3) switch
		{
			0 => new BodySash(0x482),
			1 => new Doublet(0x482),
			_ => new Tunic(0x482)
		});

		AddItem(new Broadsword());

		var shield = new MetalKiteShield();
		shield.Hue = Utility.RandomNondyedHue();
		AddItem(shield);

		Utility.AssignRandomHair(this);

		AddItem(Utility.Random(2) == 0 ? new Boots() : new ThighBoots());

		PackGold(100, 200);
	}
}
