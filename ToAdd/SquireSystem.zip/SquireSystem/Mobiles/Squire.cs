using System;
using System.Collections.Generic;
using ModernUO.Serialization;
using Server;
using Server.Collections;
using Server.ContextMenus;
using Server.Gumps;
using Server.Items;
using Server.Logging;
using Server.Misc;
using Server.Network;
using Server.SkillHandlers;
using Server.Spells;
using Server.Spells.Bushido;
using Server.Spells.Necromancy;

namespace Server.Mobiles;

[CorpseName("a squire's corpse")]
[SerializationGenerator(0, false)]
public partial class Squire : BaseCreature
{
    private static readonly ILogger _logger = LogFactory.GetLogger(typeof(Squire));

    public static void Initialize() => _logger.Information("[Squire] System initialized.");

    public DateTime _delay, _musicDelay, _throwDelay, _hideDelay, _annoyanceDelay, _pickUpEmoteDelay, _strengthDelay,
        _agilityDelay, _healthDelay, _cureDelay, _lockpickDelay, _stealingDelay, _spiritDelay, _meditateDelay,
        _spellCastDelay, _weaponAbilityDelay, _autoLootDelay;

    [SerializableField(33)] public Item _weaponSetOneSlotOne;
    [SerializableField(34)] public Item _weaponSetOneSlotTwo;
    [SerializableField(35)] public Item _weaponSetTwoSlotOne;
    [SerializableField(36)] public Item _weaponSetTwoSlotTwo;
    [SerializableField(37)] public Item _weaponSetThreeSlotOne;
    [SerializableField(38)] public Item _weaponSetThreeSlotTwo;

    [SerializableField(51)] public string _masterNickname;
    [SerializableField(50)] public string _squireNickname;
    [SerializableField(7)] public string _squireTeam;

    [SerializableField(48)] public bool _autoHealAnimals;

    public bool _inspectable;
    public bool _squireBeQuiet;
    public bool _spiritWorldConnected;

    [SerializableField(46), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoUseHealthPotion;
    [SerializableField(45), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoUseCurePotion;
    [SerializableField(44), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoHealSelf;
    [SerializableField(43), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoHealMaster;
    [SerializableField(42), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoHealOther;
    [SerializableField(41), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoPickupAmmo;
    [SerializableField(40), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _desperateMasterRun;
    [SerializableField(39), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoUsePowerScroll;
    [SerializableField(32), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoUseTScroll;
    [SerializableField(31), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoEquipLoot;
    [SerializableField(28), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoUseSpiritSpeak;
    [SerializableField(29), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoRezMaster;
    [SerializableField(30), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoRezAlly;
    [SerializableField(26), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoCastCloseWounds;
    [SerializableField(27), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoCastCleanseByFire;
    [SerializableField(12), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoUseWeaponAbility;
    [SerializableField(8), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoCastCloseWoundsMaster;
    [SerializableField(9), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoCastCleanseByFireMaster;
    [SerializableField(10), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoCastCloseWoundsAlly;
    [SerializableField(11), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoCastCleanseByFireAlly;
    [SerializableField(13), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoCastConfidence;
    [SerializableField(14), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoLightningStrike;
    [SerializableField(15), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoEvasion;
    [SerializableField(16), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoCounterAttack;
    [SerializableField(17), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoMomentumStrike;
    [SerializableField(18), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoHonorableExecution;
    [SerializableField(19), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoPainSpike;
    [SerializableField(20), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoPoisonStrike;
    [SerializableField(21), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoWraithForm;
    [SerializableField(22), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoCurseWeapon;
    [SerializableField(23), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoWither;
    [SerializableField(24), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoLichForm;
    [SerializableField(25), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoVampiricEmbrace;
    [SerializableField(5), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _onlyLootGoldAndMap;
    [SerializableField(6), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _autoLoot;
    [SerializableField(4), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _convenientStackable;
    [SerializableField(3), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _lootGold;
    [SerializableField(2), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _lootMap;
    [SerializableField(1), SerializedCommandProperty(AccessLevel.GameMaster), InvalidateProperties]
    public bool _lootZoogiFungus;
    [SerializableField(0), InvalidateProperties]
    public bool _lootDaemonBone;

    [CommandProperty(AccessLevel.GameMaster)]
    public string Nickname
    {
        get => _masterNickname;
        set
        {
            _masterNickname = value;
            InvalidateProperties();
        }
    }

    [CommandProperty(AccessLevel.GameMaster)]
    public string SNickname
    {
        get => _squireNickname;
        set
        {
            _squireNickname = value;
            InvalidateProperties();
        }
    }

    [CommandProperty(AccessLevel.GameMaster)]
    public string STeam
    {
        get => _squireTeam;
        set
        {
            _squireTeam = value;
            InvalidateProperties();
        }
    }

    [CommandProperty(AccessLevel.GameMaster)]
    public bool HealAnimals
    {
        get => _autoHealAnimals;
        set
        {
            _autoHealAnimals = value;
            InvalidateProperties();
        }
    }

    [CommandProperty(AccessLevel.GameMaster), SerializableProperty(49, useField: nameof(_inspectable))]
    public bool Inspectable
    {
        get => _inspectable;
        set
        {
            _inspectable = value;
            InvalidateProperties();
        }
    }

    [CommandProperty(AccessLevel.GameMaster), SerializableProperty(47, useField: nameof(_squireBeQuiet))]
    public bool SquireBeQuiet
    {
        get => _squireBeQuiet;
        set
        {
            _squireBeQuiet = value;
            InvalidateProperties();
        }
    }

    public enum SquireCommands
    {
        None = 0, Restyle, Stop, Stay, Follow, FollowMe, Come,
        Throw, ChangeNickname, ChangeSNickname, Heal, Dress, Undress,
        Mount, Dismount, Stats, Unload, List, Arm, Grab, GrabAll,
        Loot, LootAll, Attack, Kill, Guard, GuardMe, RenameSelf,
        Backpack, PlayMusic, Provoke, Discord, MakePeace, Hide,
        BeQuiet, TalkAgain, DrinkAgility, DrinkPoison, DrinkRefresh,
        DrinkStrength, DrinkCure, DrinkHealth, Steal, Lockpick,
        CreateSetOne, EquipSetOne, Unarm, CreateSetTwo, EquipSetTwo,
        CreateSetThree, EquipSetThree, SpiritSpeak, ChangeTitle,
        Quiver, Poison, Skills, Switches, Tithe, Meditate, Consecrate,
        DivineFury, DispelEvil, EnemyOfOne, HolyLight, NobleSacrifice,
        CleanseByFire, CloseWounds, RemoveCurse, ThrowExplosion,
        WeaponAbility, WeaponAbilityOne, WeaponAbilityTwo,
        CheckTithingPoints, SetTeam, Confidence, LightningStrike,
        Evasion, CounterAttack, MomentumStrike, HonorableExecution,
        PainSpike, PoisonStrike, WraithForm, CurseWeapon, Wither, LichForm, VampiricEmbrace,
        Commands,
    }

    private static readonly Dictionary<string, int> _keywords = new(StringComparer.OrdinalIgnoreCase)
    {
    [" "] = 0,
    ["restyle"] = 1,
    ["stop"] = 2,
    ["stay"] = 3,
    ["follow"] = 4,
    ["follow me"] = 5,
    ["come"] = 6,
    ["throw"] = 7,
    ["change my nickname"] = 8,
    ["change your nickname"] = 9,
    ["heal"] = 10,
    ["dress"] = 11,
    ["undress"] = 12,
    ["mount"] = 13,
    ["dismount"] = 14,
    ["stats"] = 15,
    ["unload"] = 16,
    ["list"] = 17,
    ["arm"] = 18,
    ["grab"] = 19,
    ["grab all"] = 20,
    ["loot"] = 21,
    ["loot all"] = 22,
    ["attack"] = 23,
    ["kill"] = 24,
    ["guard"] = 25,
    ["guard me"] = 26,
    ["rename yourself"] = 27,
    ["backpack"] = 28,
    ["play music"] = 29,
    ["provoke"] = 30,
    ["discord"] = 31,
    ["make peace"] = 32,
    ["hide"] = 33,
    ["be quiet"] = 34,
    ["talk again"] = 35,
    ["drink agility"] = 36,
    ["drink poison"] = 37,
    ["drink refresh"] = 38,
    ["drink strength"] = 39,
    ["drink cure"] = 40,
    ["drink health"] = 41,
    ["steal"] = 42,
    ["lockpick"] = 43,
    ["create set one"] = 44,
    ["equip set one"] = 45,
    ["unarm"] = 46,
    ["create set two"] = 47,
    ["equip set two"] = 48,
    ["create set three"] = 49,
    ["equip set three"] = 50,
    ["spirit speak"] = 51,
    ["change title"] = 52,
    ["quiver"] = 53,
    ["poison"] = 54,
    ["skills"] = 55,
    ["switches"] = 56,
    ["tithe"] = 57,
    ["meditate"] = 58,
    ["consecrate weapon"] = 59,
    ["divine fury"] = 60,
    ["dispel evil"] = 61,
    ["enemy of one"] = 62,
    ["holy light"] = 63,
    ["noble sacrifice"] = 64,
    ["cleanse by fire"] = 65,
    ["close wounds"] = 66,
    ["remove curse"] = 67,
    ["throw explosion"] = 68,
    ["weapon ability"] = 69,
    ["weapon ability one"] = 70,
    ["weapon ability two"] = 71,
    ["check tithing points"] = 72,
    ["set team"] = 73,
    ["Confidence"] = 74,
    ["LightningStrike"] = 75,
    ["Evasion"] = 76,
    ["CounterAttack"] = 77,
    ["MomentumStrike"] = 78,
    ["HonorableExecution"] = 79,
    ["PainSpike"] = 80,
    ["PoisonStrike"] = 81,
    ["WraithForm"] = 82,
    ["CurseWeapon"] = 83,
    ["Wither"] = 84,
    ["LichForm"] = 85,
    ["VampiricEmbrace"] = 86,
    ["commands"] = 87
    };

    public override void GetSpeeds(out double activeSpeed, out double passiveSpeed)
    {
        activeSpeed = 0.2;
        passiveSpeed = 0.4;
    }

    private void ChangeAIToDefault() => ChangeAIType(AIType.AI_Melee);

    [Constructible]
    public Squire() : base(AIType.AI_Melee, FightMode.Closest, 10, 1)
    {
        SpeechHue = Utility.RandomDyedHue();
        Nickname = "Master";
        SNickname = "Squire";

        IsBonded = true;
        ControlSlots = 3;

        _autoUseHealthPotion = true;
        _autoUseCurePotion = true;
        _autoHealSelf = true;
        _autoHealMaster = true;
        _autoHealOther = true;
        _autoPickupAmmo = true;
        _desperateMasterRun = true;

        SetStr(45, 55);
        SetDex(15, 25);
        SetInt(10, 15);
        SetSkill(SkillName.Wrestling, 20.0, 30.0);
        SetSkill(SkillName.Anatomy, 20.0, 30.0);
        SetSkill(SkillName.Tactics, 20.0, 30.0);
        SetSkill(SkillName.Swords, 20.0, 30.0);
        SetSkill(SkillName.Macing, 20.0, 30.0);
        SetSkill(SkillName.Fencing, 20.0, 30.0);
        SetSkill(SkillName.Archery, 20.0, 30.0);
        SetSkill(SkillName.MagicResist, 20.0, 30.0);
        SetSkill(SkillName.Chivalry, 20.0, 30.0);
        SetSkill(SkillName.Bushido, 20.0, 30.0);
        SetSkill(SkillName.Necromancy, 20.0, 30.0);

        Skills.Cap = 50000;
        StatCap = 450;

        if (Female = Utility.RandomBool())
        {
            if (Utility.Random(5) == 1)
            {
                Body = 0x25E;
                Race = Race.Elf;
            }
            else
            {
                Body = 0x191;
            }

            Hue = Utility.Random(0x3EA, 0x422 - 0x3EA);
            Utility.AssignRandomHair(this, Body == 0x25E);
        }
        else
        {
            if (Utility.Random(5) == 1)
            {
                Body = 0x25D;
                Race = Race.Elf;
            }
            else
            {
                Body = 0x190;
            }

            Hue = Utility.Random(0x3EA, 0x422 - 0x3EA);
            Utility.AssignRandomHair(this, Body == 0x25D);

            if (Body == 0x190)
            {
                Utility.AssignRandomFacialHair(this, HairHue);
            }
        }

        RandomizeName();

        AddItem(Utility.Random(6) switch
        {
            0 => new Kryss(),
            1 => new Scimitar(),
            2 => new WarAxe(),
            3 => new Cutlass(),
            4 => new HammerPick(),
            _ => new WarFork()
        });

        AddItem(new RingmailChest());
        AddItem(new RingmailLegs());
        AddItem(new RingmailArms());
        AddItem(new RingmailGloves());
        AddItem(new Boots());

        if (Backpack == null)
        {
            AddItem(new Backpack());
        }

        Backpack.Movable = false;
    }

    private void RandomizeName()
    {
        if (Body == 0x191)
        {
            Name = NameList.RandomName("female");
        }
        else if (Body == 0x25E)
        {
            Name = NameList.RandomName("female elf brigand");
        }
        else if (Body == 0x25D)
        {
            Name = NameList.RandomName("male elf brigand");
        }
        else
        {
            Name = NameList.RandomName("male");
        }
    }

    [CommandProperty(AccessLevel.GameMaster)]
    public override int HitsMax
    {
        get
        {
            var strOffs = AosAttributes.GetValue(this, AosAttribute.BonusHits);

            if (strOffs > 25)
            {
                strOffs = 25;
            }

            return Str / 2 + 50 + strOffs;
        }
    }

    [CommandProperty(AccessLevel.GameMaster)]
    public override int StamMax => base.StamMax + AosAttributes.GetValue(this, AosAttribute.BonusStam);

    [CommandProperty(AccessLevel.GameMaster)]
    public override int ManaMax =>
        base.ManaMax + AosAttributes.GetValue(this, AosAttribute.BonusMana) + (Race == Race.Elf ? 20 : 0);

    public override FoodType FavoriteFood =>
        FoodType.Eggs | FoodType.Fish | FoodType.Meat | FoodType.FruitsAndVeggies;

    public override bool HandlesOnSpeech(Mobile from) => true;

    public override void OnSpeech(SpeechEventArgs e)
    {
        var from = e.Mobile;

        if (ControlMaster != from || IsDeadPet)
        {
            base.OnSpeech(e);
            return;
        }

        var isSNickname = false;
        var command = -1;

        if (MatchPrefix(e.Speech, "all"))
        {
            _keywords.TryGetValue(e.Speech[4..], out command);

            if (command >= 0 && ExecuteCommand(from, (SquireCommands)command, false, true))
            {
                e.Handled = true;
                return;
            }

            base.OnSpeech(e);
            return;
        }
        else if (MatchPrefix(e.Speech, Name))
        {
            _keywords.TryGetValue(e.Speech[(Name.Length + 1)..], out command);
        }
        else if (_squireNickname != null && MatchPrefix(e.Speech, _squireNickname))
        {
            isSNickname = true;
            _keywords.TryGetValue(e.Speech[(_squireNickname.Length + 1)..], out command);
        }

        if (command >= 0 && ExecuteCommand(from, (SquireCommands)command, isSNickname))
        {
            e.Handled = true;
            return;
        }

        base.OnSpeech(e);
    }

    private static bool MatchPrefix(string speech, string prefix) =>
        speech.Length > prefix.Length && speech.StartsWith(prefix + ' ', StringComparison.OrdinalIgnoreCase);

    public bool ExecuteCommand(Mobile from, SquireCommands command, bool isSNickname = false, bool isSquireTeam = false)
    {
        if (ControlMaster != from || IsDeadPet)
        {
            return false;
        }

        switch (command)
        {
            case SquireCommands.Restyle:
                from.SendGump(new SquireCustomizeGump(this));
                break;
            case SquireCommands.Dress:
                if (!_squireBeQuiet)
                {
                    Say("I shall attempt to equip all the items in my pack.");
                }

                DressFromBackpack(from, true);
                break;
            case SquireCommands.Undress:
                if (!_squireBeQuiet)
                {
                    Say("I shall pack away everything I am wearing.");
                }

                PackWornItems();
                break;
            case SquireCommands.Mount:
                if (Mount == null)
                {
                    var mount = FindMyMount(Backpack);

                    if (mount == null)
                    {
                        from.Target = new MountTarget(from, this);
                    }
                    else
                    {
                        mount.Rider = this;
                    }
                }

                break;
            case SquireCommands.Dismount:
                if (Mount != null)
                {
                    var mount = FindMyMount(null);

                    if (mount != null)
                    {
                        mount.Rider = null;

                        if (mount is EtherealMount ethereal)
                        {
                            Backpack.DropItem(ethereal);
                        }
                        else
                        {
                            ((BaseMount)mount).ControlOrder = OrderType.Follow;
                        }
                    }
                }

                break;
            case SquireCommands.Stats:
                from.SendGump(new SquireLoreGump(this, from, SquireLorePage.Stats));
                break;
            case SquireCommands.ChangeNickname:
                if (!_squireBeQuiet)
                {
                    Say("What would you like me to call you?");
                }

                from.Prompt = new SquireNewNickname(this);
                break;
            case SquireCommands.ChangeSNickname:
                if (!_squireBeQuiet)
                {
                    Say("What would you like to call me?");
                }

                from.Prompt = new NewSquireNickname(this);
                break;
            case SquireCommands.Unload:
                if (!_squireBeQuiet)
                {
                    Say("I shall give you everything in my pack.");
                }

                GiveAllTo(from);
                break;
            case SquireCommands.List:
                Say("I am carrying:");

                foreach (var item in Backpack.Items)
                {
                    if (item != null)
                    {
                        Say($"{item.Amount} {item.GetType().Name}");
                    }
                }

                break;
            case SquireCommands.Arm:
                {
                    var weapon = Backpack.FindItemByType(typeof(BaseWeapon));
                    var shield = Backpack.FindItemByType(typeof(BaseShield));

                    if (weapon == null && shield == null)
                    {
                        if (!_squireBeQuiet)
                        {
                            Say("I have no weapons to arm myself with.");
                        }
                    }
                    else
                    {
                        if (shield != null)
                        {
                            Backpack.DropItem(shield);
                            OnDragDrop(from, shield);
                        }

                        if (weapon != null)
                        {
                            Backpack.DropItem(weapon);
                            OnDragDrop(from, weapon);
                        }
                    }

                    break;
                }
            case SquireCommands.Grab:
                from.Target = new GrabItemTarget(from, this);
                break;
            case SquireCommands.GrabAll:
                GrabItems(false, _onlyLootGoldAndMap);
                break;
            case SquireCommands.Loot:
                from.Target = new LootCorpseTarget(from, this);
                break;
            case SquireCommands.LootAll:
                GrabItems(true, _onlyLootGoldAndMap);
                break;
            case SquireCommands.Heal:
                from.Target = new HealTarget(from, this);
                break;
            case SquireCommands.RenameSelf:
                RandomizeName();
                SquireDialog.DoSquireDialog(this, SquireDialogTree.SquiresNewName);
                break;
            case SquireCommands.Backpack:
                SquirePack.TryPackOpen(this, from);
                SquireDialog.DoSquireDialog(this, SquireDialogTree.ShowingOffASquiresBackpack);
                break;
            case SquireCommands.Hide:
                if (Core.Now > _hideDelay)
                {
                    UseSkill(SkillName.Hiding);

                    if (!Hidden)
                    {
                        SquireDialog.DoSquireDialog(this, SquireDialogTree.HideFailure);
                    }

                    _hideDelay = Core.Now + TimeSpan.FromSeconds(10);
                }
                else
                {
                    SquireDialog.DoSquireDialog(this, SquireDialogTree.TooSoonToHide);
                }

                break;
            case SquireCommands.PlayMusic:
            case SquireCommands.Provoke:
            case SquireCommands.Discord:
            case SquireCommands.MakePeace:
                UseInstrument(from, command);
                break;
            case SquireCommands.Throw:
                if (Backpack.FindItemByType(typeof(SnowPile)) == null)
                {
                    SquireDialog.DoSquireDialog(this, SquireDialogTree.MissingSnow);
                }
                else if (Core.Now > _throwDelay)
                {
                    from.Target = new ThrowTarget(from, this);
                }
                else
                {
                    SquireDialog.DoSquireDialog(this, SquireDialogTree.TooSoonToPackSnow);
                }

                break;
            case SquireCommands.Attack:
            case SquireCommands.Kill:
                SetRandomWeaponAbility();

                if ((isSNickname || isSquireTeam) && !IsDeadPet && CheckControlChance(from))
                {
                    AIObject.BeginPickTarget(from, OrderType.Attack);
                }

                return false;
            case SquireCommands.Guard:
            case SquireCommands.GuardMe:
                SetRandomWeaponAbility();

                if ((isSNickname || isSquireTeam) && !IsDeadPet && CheckControlChance(from))
                {
                    ControlTarget = null;
                    ControlOrder = OrderType.Guard;
                }

                return false;
            case SquireCommands.Come:
            case SquireCommands.Stop:
            case SquireCommands.Stay:
                if ((isSNickname || isSquireTeam) && CheckControlChance(from))
                {
                    ControlTarget = null;
                    ControlOrder = command switch
                    {
                        SquireCommands.Come => OrderType.Come,
                        SquireCommands.Stop => OrderType.Stop,
                        _ => OrderType.Stay
                    };
                }

                return false;
            case SquireCommands.Follow:
                if (isSNickname || isSquireTeam)
                {
                    AIObject.BeginPickTarget(from, OrderType.Follow);
                }

                return false;
            case SquireCommands.FollowMe:
                if ((isSNickname || isSquireTeam) && CheckControlChance(from))
                {
                    ControlTarget = from;
                    ControlOrder = OrderType.Follow;
                }

                return false;
            case SquireCommands.BeQuiet:
                if (!_squireBeQuiet)
                {
                    _squireBeQuiet = true;
                    SquireDialog.DoSquireDialog(from, this, SquireDialogTree.ToldToShutUp, null, null);
                }

                break;
            case SquireCommands.TalkAgain:
                if (_squireBeQuiet)
                {
                    _squireBeQuiet = false;
                    SquireDialog.DoSquireDialog(from, this, SquireDialogTree.CanTalkAgain, null, null);
                }

                break;
            case SquireCommands.DrinkAgility:
                TryDrinkPotion<BaseAgilityPotion>(ref _agilityDelay, TimeSpan.FromMinutes(2.0), SquireDialogTree.AgilityPotion);
                break;
            case SquireCommands.DrinkStrength:
                TryDrinkPotion<BaseStrengthPotion>(ref _strengthDelay, TimeSpan.FromMinutes(2.0), SquireDialogTree.StrengthPotion);
                break;
            case SquireCommands.DrinkRefresh:
                TryDrinkPotion<BaseRefreshPotion>(Stam < StamMax, SquireDialogTree.RefreshPotion, SquireDialogTree.TooSoonToDrink);
                break;
            case SquireCommands.DrinkCure:
                TryDrinkPotion<BaseCurePotion>(Poisoned, SquireDialogTree.CurePotion, SquireDialogTree.CantCurePotion);
                break;
            case SquireCommands.DrinkPoison:
                TryDrinkPotion<BasePoisonPotion>(true, SquireDialogTree.PoisonPotion, SquireDialogTree.NoPotions);
                break;
            case SquireCommands.DrinkHealth:
                {
                    var heal = Backpack.FindItemByType(typeof(BaseHealPotion));

                    if (heal == null)
                    {
                        SquireDialog.DoSquireDialog(this, SquireDialogTree.NoPotions);
                    }
                    else if (Hits >= HitsMax)
                    {
                        SquireDialog.DoSquireDialog(this, SquireDialogTree.CantHealthPotion);
                    }
                    else if (Poisoned)
                    {
                        SquireDialog.DoSquireDialog(this, SquireDialogTree.StillPoisoned);
                    }
                    else if (MortalStrike.IsWounded(this))
                    {
                        SquireDialog.DoSquireDialog(this, SquireDialogTree.MortallyWoundedHP);
                    }
                    else if (Core.Now <= _healthDelay)
                    {
                        SquireDialog.DoSquireDialog(this, SquireDialogTree.TooSoonToDrink);
                    }
                    else
                    {
                        ((BasePotion)heal).Drink(this);
                        _healthDelay = Core.Now + TimeSpan.FromSeconds(10);
                        SquireDialog.DoSquireDialog(this, SquireDialogTree.HealthPotion);
                    }

                    break;
                }
            case SquireCommands.Steal:
                if (Core.Now > _stealingDelay)
                {
                    SquireDialog.DoSquireDialog(this, SquireDialogTree.WhatShouldISteal);
                    from.Target = new SquireStealingTarget(from, this);
                }
                else
                {
                    SquireDialog.DoSquireDialog(this, SquireDialogTree.TooSoonToSteal);
                }

                break;
            case SquireCommands.Lockpick:
                if (Core.Now <= _lockpickDelay)
                {
                    SquireDialog.DoSquireDialog(this, SquireDialogTree.TooSoonToLockpick);
                }
                else if (Backpack.FindItemByType(typeof(Lockpick)) is not Lockpick lockpick)
                {
                    SquireDialog.DoSquireDialog(this, SquireDialogTree.MissingLockpicks);
                }
                else
                {
                    from.Target = new SquireLockpickTarget(this, lockpick);
                    _lockpickDelay = Core.Now + TimeSpan.FromSeconds(4.0);
                }

                break;
            case SquireCommands.Unarm:
                {
                    var firstHand = FindItemOnLayer(Layer.OneHanded);
                    var secondHand = FindItemOnLayer(Layer.TwoHanded);

                    if (firstHand != null)
                    {
                        Backpack.DropItem(firstHand);
                    }

                    if (secondHand != null)
                    {
                        Backpack.DropItem(secondHand);
                    }

                    if (firstHand != null || secondHand != null)
                    {
                        Annoy(SquireDialogTree.Unarmed, 10);
                    }

                    break;
                }
            case SquireCommands.CreateSetOne:
            case SquireCommands.CreateSetTwo:
            case SquireCommands.CreateSetThree:
                CreateWeaponSet(from, SetIndex(command));
                break;
            case SquireCommands.EquipSetOne:
            case SquireCommands.EquipSetTwo:
            case SquireCommands.EquipSetThree:
                EquipWeaponSet(from, SetIndex(command));
                break;
            case SquireCommands.SpiritSpeak:
                SquireSpeaksWithSpirits();
                break;
            case SquireCommands.ChangeTitle:
                from.SendGump(new SquireTitleGump(this, from, SquireTitlePage.PageOne));
                break;
            case SquireCommands.Quiver:
                SquireQuiver.TryPackOpen(this, from);
                break;
            case SquireCommands.Poison:
                SquireDialog.DoSquireDialog(this, SquireDialogTree.PoisonToApply);
                from.Target = new SquirePoisonTarget(from, this);
                break;
            case SquireCommands.Skills:
                from.SendGump(new SquireLoreGump(this, from, SquireLorePage.Skills));
                break;
            case SquireCommands.Switches:
                from.SendGump(new SquireLoreGump(this, from, SquireLorePage.Switches));
                break;
            case SquireCommands.Tithe:
                SquireTithing();
                break;
            case SquireCommands.Meditate:
                if (Core.Now > _meditateDelay)
                {
                    UseSkill(SkillName.Meditation);
                    _meditateDelay = Core.Now + TimeSpan.FromSeconds(10.0);
                }
                else
                {
                    SquireDialog.DoSquireDialog(this, SquireDialogTree.TooSoonToMeditate);
                }

                break;
            case SquireCommands.ThrowExplosion:
                {
                    var explosion = Backpack.FindItemByType(typeof(BaseExplosionPotion));

                    if (explosion != null)
                    {
                        ((BasePotion)explosion).Drink(this);
                        from.Target = new SquirePassExplosionPotionTarget(from, this);
                    }
                    else
                    {
                        SquireDialog.DoSquireDialog(this, SquireDialogTree.NoExplosionPotion);
                    }

                    break;
                }
            case SquireCommands.WeaponAbility:
                SetRandomWeaponAbility();
                break;
            case SquireCommands.WeaponAbilityOne:
                if (Weapon is BaseWeapon primaryWeapon)
                {
                    WeaponAbility.SetCurrentAbility(this, primaryWeapon.PrimaryAbility);
                }
                break;
            case SquireCommands.WeaponAbilityTwo:
                if (Weapon is BaseWeapon secondaryWeapon)
                {
                    WeaponAbility.SetCurrentAbility(this, secondaryWeapon.SecondaryAbility);
                }
                break;
            case SquireCommands.CheckTithingPoints:
                Say($"I now have {TithingPoints} tithing points.");
                break;
            case SquireCommands.SetTeam:
                if (!_squireBeQuiet)
                {
                    Say("What team would you like to assign me to?");
                }

                from.Prompt = new NewSquireTeam(this);
                break;
            case SquireCommands.Commands:
                from.SendGump(new SquireCommandGump(from, this));
                break;
            default:
                return TryCastSquireSpell(from, command);
        }

        return true;
    }

    private static int SetIndex(SquireCommands command) => command switch
    {
        SquireCommands.CreateSetTwo or SquireCommands.EquipSetTwo => 1,
        SquireCommands.CreateSetThree or SquireCommands.EquipSetThree => 2,
        _ => 0
    };

    private void UseInstrument(Mobile from, SquireCommands command)
    {
        if (Backpack.FindItemByType(typeof(BaseInstrument)) is not BaseInstrument instrument)
        {
            SquireDialog.DoSquireDialog(this, SquireDialogTree.MissingInstrument);
            return;
        }

        if (Core.Now <= _musicDelay)
        {
            SquireDialog.DoSquireDialog(this, SquireDialogTree.TooSoonToPlayMusic);
            return;
        }

        _musicDelay = Core.Now + TimeSpan.FromSeconds(command is SquireCommands.Provoke or SquireCommands.Discord ? 10 : 6);

        switch (command)
        {
            case SquireCommands.PlayMusic:
                instrument.OnDoubleClick(this);
                instrument.ConsumeUse(this);
                break;
            case SquireCommands.Provoke:
                from.Target = new ProvokeTargetOne(from, this, instrument);
                break;
            case SquireCommands.Discord:
                from.Target = new SquireDiscordanceTarget(from, this, instrument);
                break;
            case SquireCommands.MakePeace:
                from.Target = new SquirePeacemakingTarget(from, this, instrument);
                break;
        }
    }

    private void TryDrinkPotion<T>(ref DateTime cooldown, TimeSpan cooldownLength, SquireDialogTree success)
    {
        var potion = Backpack.FindItemByType(typeof(T));

        if (potion == null)
        {
            SquireDialog.DoSquireDialog(this, SquireDialogTree.NoPotions);
        }
        else if (Core.Now <= cooldown)
        {
            SquireDialog.DoSquireDialog(this, SquireDialogTree.TooSoonToDrink);
        }
        else
        {
            ((BasePotion)potion).Drink(this);
            cooldown = Core.Now + cooldownLength;
            SquireDialog.DoSquireDialog(this, success);
        }
    }

    private void TryDrinkPotion<T>(bool canDrink, SquireDialogTree success, SquireDialogTree fail)
    {
        var potion = Backpack.FindItemByType(typeof(T));

        if (potion == null)
        {
            SquireDialog.DoSquireDialog(this, SquireDialogTree.NoPotions);
        }
        else if (!canDrink)
        {
            SquireDialog.DoSquireDialog(this, fail);
        }
        else
        {
            ((BasePotion)potion).Drink(this);
            SquireDialog.DoSquireDialog(this, success);
        }
    }

    private void PackWornItems()
    {
        using var worn = PooledRefList<Item>.Create();

        foreach (var item in Items)
        {
            worn.Add(item);
        }

        for (var i = worn.Count - 1; i >= 0; --i)
        {
            var item = worn[i];

            if ((item is BaseQuiver || item is not (Container or IMountItem)) && item.Layer is not (Layer.FacialHair or Layer.Hair))
            {
                Backpack.DropItem(item);
            }
        }
    }

    private void GiveAllTo(Mobile to)
    {
        using var items = PooledRefList<Item>.Create();

        foreach (var item in Backpack.Items)
        {
            items.Add(item);
        }

        for (var i = items.Count - 1; i >= 0; --i)
        {
            to.AddToBackpack(items[i]);
        }
    }

    private void Annoy(SquireDialogTree tree, int seconds = 30)
    {
        if (Core.Now > _annoyanceDelay)
        {
            SquireDialog.DoSquireDialog(this, tree);
            _annoyanceDelay = Core.Now + TimeSpan.FromSeconds(seconds);
        }
    }

    private sealed record SquireSpellInfo(
        SquireCommands Command,
        Type BookType,
        SquireDialogTree MissingBookDialog,
        SkillName Skill,
        int TitheRequired,
        int ManaRequired,
        double SkillRequired,
        double CastDelay,
        Action<Squire, Mobile> Cast
    );

    private static readonly SquireSpellInfo[] _squireSpells =
    [
        new( SquireCommands.Confidence, typeof( BookOfBushido ), SquireDialogTree.NoBushidoBook, SkillName.Bushido, 0, 10, 15.0, 6.0,
            ( sq, from ) => new Server.Spells.Bushido.Confidence( sq, null ).Cast() ),
        new( SquireCommands.LightningStrike, typeof( BookOfBushido ), SquireDialogTree.NoBushidoBook, SkillName.Bushido, 0, 10, 50.0, 4.0,
            ( sq, from ) => SamuraiMove.SetCurrentMove( sq, new Server.Spells.Bushido.LightningStrike() ) ),
        new( SquireCommands.Evasion, typeof( BookOfBushido ), SquireDialogTree.NoBushidoBook, SkillName.Bushido, 0, 10, 60.0, 6.0,
            ( sq, from ) => new Server.Spells.Bushido.Evasion( sq, null ).Cast() ),
        new( SquireCommands.CounterAttack, typeof( BookOfBushido ), SquireDialogTree.NoBushidoBook, SkillName.Bushido, 0, 10, 40.0, 6.0,
            ( sq, from ) => new Server.Spells.Bushido.CounterAttack( sq, null ).Cast() ),
        new( SquireCommands.MomentumStrike, typeof( BookOfBushido ), SquireDialogTree.NoBushidoBook, SkillName.Bushido, 0, 10, 70.0, 6.0,
            ( sq, from ) => SamuraiMove.SetCurrentMove( sq, new Server.Spells.Bushido.MomentumStrike() ) ),
        new( SquireCommands.HonorableExecution, typeof( BookOfBushido ), SquireDialogTree.NoBushidoBook, SkillName.Bushido, 0, 10, 25.0, 6.0,
            ( sq, from ) => SamuraiMove.SetCurrentMove( sq, new Server.Spells.Bushido.HonorableExecution() ) ),
        new( SquireCommands.CurseWeapon, typeof( NecromancerSpellbook ), SquireDialogTree.NoNecroBook, SkillName.Necromancy, 0, 10, 10.0, 6.0,
            ( sq, from ) => new Server.Spells.Necromancy.CurseWeaponSpell( sq, null ).Cast() ),
        new( SquireCommands.PainSpike, typeof( NecromancerSpellbook ), SquireDialogTree.NoNecroBook, SkillName.Necromancy, 0, 10, 20.0, 6.0,
            ( sq, from ) =>
            {
                new Server.Spells.Necromancy.PainSpikeSpell( sq, null ).Cast();
                new SquirePainSpikeDelayTimer( sq, from, TimeSpan.FromSeconds( 1.5 ) ).Start();
            } ),
        new( SquireCommands.WraithForm, typeof( NecromancerSpellbook ), SquireDialogTree.NoNecroBook, SkillName.Necromancy, 0, 10, 20.0, 6.0,
            ( sq, from ) => new Server.Spells.Necromancy.WraithFormSpell( sq, null ).Cast() ),
        new( SquireCommands.PoisonStrike, typeof( NecromancerSpellbook ), SquireDialogTree.NoNecroBook, SkillName.Necromancy, 0, 10, 50.0, 6.0,
            ( sq, from ) =>
            {
                new Server.Spells.Necromancy.PoisonStrikeSpell( sq, null ).Cast();
                new SquirePoisonStrikeDelayTimer( sq, from, TimeSpan.FromSeconds( 1.5 ) ).Start();
            } ),
        new( SquireCommands.Wither, typeof( NecromancerSpellbook ), SquireDialogTree.NoNecroBook, SkillName.Necromancy, 0, 10, 60.0, 6.0,
            ( sq, from ) => new Server.Spells.Necromancy.WitherSpell( sq, null ).Cast() ),
        new( SquireCommands.LichForm, typeof( NecromancerSpellbook ), SquireDialogTree.NoNecroBook, SkillName.Necromancy, 0, 10, 70.0, 6.0,
            ( sq, from ) => new Server.Spells.Necromancy.LichFormSpell( sq, null ).Cast() ),
        new( SquireCommands.VampiricEmbrace, typeof( NecromancerSpellbook ), SquireDialogTree.NoNecroBook, SkillName.Necromancy, 0, 10, 98.9, 6.0,
            ( sq, from ) => new Server.Spells.Necromancy.VampiricEmbraceSpell( sq, null ).Cast() ),
        new( SquireCommands.Consecrate, typeof( BookOfChivalry ), SquireDialogTree.NoChivalryBook, SkillName.Chivalry, 10, 10, 15.0, 4.0,
            ( sq, from ) => new Server.Spells.Chivalry.ConsecrateWeaponSpell( sq, null ).Cast() ),
        new( SquireCommands.DivineFury, typeof( BookOfChivalry ), SquireDialogTree.NoChivalryBook, SkillName.Chivalry, 10, 15, 25.0, 4.0,
            ( sq, from ) => new Server.Spells.Chivalry.DivineFurySpell( sq, null ).Cast() ),
        new( SquireCommands.DispelEvil, typeof( BookOfChivalry ), SquireDialogTree.NoChivalryBook, SkillName.Chivalry, 10, 10, 35.0, 4.0,
            ( sq, from ) => new Server.Spells.Chivalry.DispelEvilSpell( sq, null ).Cast() ),
        new( SquireCommands.EnemyOfOne, typeof( BookOfChivalry ), SquireDialogTree.NoChivalryBook, SkillName.Chivalry, 10, 20, 45.0, 4.0,
            ( sq, from ) => new Server.Spells.Chivalry.EnemyOfOneSpell( sq, null ).Cast() ),
        new( SquireCommands.HolyLight, typeof( BookOfChivalry ), SquireDialogTree.NoChivalryBook, SkillName.Chivalry, 10, 10, 55.0, 4.0,
            ( sq, from ) => new Server.Spells.Chivalry.HolyLightSpell( sq, null ).Cast() ),
        new( SquireCommands.NobleSacrifice, typeof( BookOfChivalry ), SquireDialogTree.NoChivalryBook, SkillName.Chivalry, 30, 20, 65.0, 4.0,
            ( sq, from ) => new Server.Spells.Chivalry.NobleSacrificeSpell( sq, null ).Cast() ),
        new( SquireCommands.CleanseByFire, typeof( BookOfChivalry ), SquireDialogTree.NoChivalryBook, SkillName.Chivalry, 10, 10, 5.0, 4.0,
            ( sq, from ) =>
            {
                new Server.Spells.Chivalry.CleanseByFireSpell( sq, null ).Cast();
                new SquireCleanseDelayTimer( sq, from, TimeSpan.FromSeconds( 1.0 ) ).Start();
            } ),
        new( SquireCommands.CloseWounds, typeof( BookOfChivalry ), SquireDialogTree.NoChivalryBook, SkillName.Chivalry, 10, 10, 0.0, 4.0,
            ( sq, from ) =>
            {
                new Server.Spells.Chivalry.CloseWoundsSpell( sq, null ).Cast();
                new SquireCloseWoundsDelayTimer( sq, from, TimeSpan.FromSeconds( 1.5 ) ).Start();
            } ),
        new( SquireCommands.RemoveCurse, typeof( BookOfChivalry ), SquireDialogTree.NoChivalryBook, SkillName.Chivalry, 10, 20, 5.0, 4.0,
            ( sq, from ) =>
            {
                new Server.Spells.Chivalry.RemoveCurseSpell( sq, null ).Cast();
                new SquireRemoveCurseDelayTimer( sq, from, TimeSpan.FromSeconds( 1.5 ) ).Start();
            } ),
    ];

    private bool TryCastSquireSpell(Mobile from, SquireCommands command)
    {
        SquireSpellInfo info = null;

        foreach (var spell in _squireSpells)
        {
            if (spell.Command == command)
            {
                info = spell;
                break;
            }
        }

        if (info == null)
        {
            return false;
        }

        if (Backpack.FindItemByType(info.BookType) == null)
        {
            SquireDialog.DoSquireDialog(this, info.MissingBookDialog);
            return true;
        }

        if (info.TitheRequired > 0 && TithingPoints < info.TitheRequired)
        {
            SquireDialog.DoSquireDialog(this, SquireDialogTree.NotEnoughTithe);
            return true;
        }

        if (Mana < info.ManaRequired)
        {
            SquireDialog.DoSquireDialog(this, SquireDialogTree.NotEnoughMana);
            return true;
        }

        if (Skills[info.Skill].Value <= info.SkillRequired)
        {
            SquireDialog.DoSquireDialog(this, SquireDialogTree.NotEnoughSpellSkill);
            return true;
        }

        if (Core.Now <= _spellCastDelay)
        {
            SquireDialog.DoSquireDialog(this, SquireDialogTree.TooSoonToCastASpell);
            return true;
        }

        info.Cast(this, from);
        _spellCastDelay = Core.Now + TimeSpan.FromSeconds(info.CastDelay);
        return true;
    }

    private void SetRandomWeaponAbility()
    {
        if (Weapon is not BaseWeapon weapon)
        {
            return;
        }

        var ability = Utility.RandomBool() ? weapon.PrimaryAbility : weapon.SecondaryAbility;
        WeaponAbility.SetCurrentAbility(this, ability);
    }

    private Item GetWeaponSetSlot(int setIndex, bool first) => setIndex switch
    {
        0 => first ? _weaponSetOneSlotOne : _weaponSetOneSlotTwo,
        1 => first ? _weaponSetTwoSlotOne : _weaponSetTwoSlotTwo,
        _ => first ? _weaponSetThreeSlotOne : _weaponSetThreeSlotTwo
    };

    private void SetWeaponSetSlot(int setIndex, bool first, Item item)
    {
        switch (setIndex)
        {
            case 0:
                if (first) _weaponSetOneSlotOne = item; else _weaponSetOneSlotTwo = item;
                break;
            case 1:
                if (first) _weaponSetTwoSlotOne = item; else _weaponSetTwoSlotTwo = item;
                break;
            default:
                if (first) _weaponSetThreeSlotOne = item; else _weaponSetThreeSlotTwo = item;
                break;
        }
    }

    private void CreateWeaponSet(Mobile from, int setIndex)
    {
        var firstHand = FindItemOnLayer(Layer.OneHanded);
        var secondHand = FindItemOnLayer(Layer.TwoHanded);

        SetWeaponSetSlot(setIndex, true, firstHand);
        SetWeaponSetSlot(setIndex, false, secondHand);

        SquireDialog.DoSquireDialog(this, firstHand == null && secondHand == null
            ? SquireDialogTree.EmptyHands
            : SquireDialogTree.SuccessfulSetCreation);
    }

    private void EquipWeaponSet(Mobile from, int setIndex)
    {
        var firstHand = FindItemOnLayer(Layer.OneHanded);
        var secondHand = FindItemOnLayer(Layer.TwoHanded);

        EquipWeaponSetSlot(from, setIndex, true, firstHand);
        EquipWeaponSetSlot(from, setIndex, false, secondHand);

        DressFromBackpack(from, false);
    }

    private void EquipWeaponSetSlot(Mobile from, int setIndex, bool first, Item current)
    {
        var slot = GetWeaponSetSlot(setIndex, first);

        if (slot != null)
        {
            if (slot.IsChildOf(Backpack) || slot.IsChildOf(from.Backpack))
            {
                Backpack.DropItem(slot);
                OnDragDrop(this, slot);
            }
            else if (slot != current)
            {
                SquireDialog.DoSquireDialog(this, first
                    ? SquireDialogTree.FirstHandMissing
                    : SquireDialogTree.SecondHandMissing);
            }
        }
        else if (current != null)
        {
            Backpack.DropItem(current);
        }
    }

    private void DressFromBackpack(Mobile from, bool includeWeapons)
    {
        using var items = PooledRefList<Item>.Create();

        foreach (var item in Backpack.Items)
        {
            items.Add(item);
        }

        for (var i = items.Count - 1; i >= 0; --i)
        {
            var item = items[i];

            if (item is BaseClothing or BaseArmor or BaseJewel or BaseQuiver
                || includeWeapons && (item is BaseWeapon or BaseShield))
            {
                Backpack.DropItem(item);
                OnDragDrop(from, item);
            }
        }
    }

    public override void OnDoubleClick(Mobile from)
    {
        if (from == ControlMaster && !IsDeadPet && from.InRange(Location, 12))
        {
            from.SendGump(new SquireCommandGump(from, this));
            return;
        }

        base.OnDoubleClick(from);
    }

    public void SetNickname(Mobile from, string newNickname)
    {
        if (from.AccessLevel < AccessLevel.GameMaster && from != ControlMaster)
        {
            if (!_squireBeQuiet)
            {
                Say($"Why would I call you anything other than {from.Name}?");
            }

            return;
        }

        if (!from.Alive)
        {
            if (!_squireBeQuiet)
            {
                Say("What was that?");
            }

            return;
        }

        _masterNickname = newNickname.Length == 0 ? "Master" : newNickname;

        SquireDialog.DoSquireDialog(this, SquireDialogTree.MasterHasANewNickname);
    }

    public void SetSNickname(Mobile from, string newSNickname)
    {
        if (from.AccessLevel < AccessLevel.GameMaster && from != ControlMaster)
        {
            if (!_squireBeQuiet)
            {
                Say("Who are you to rename me?");
            }

            return;
        }

        if (!from.Alive)
        {
            if (!_squireBeQuiet)
            {
                Say("What was that?");
            }

            return;
        }

        _squireNickname = newSNickname.Length == 0 ? "Squire" : newSNickname;

        SquireDialog.DoSquireDialog(this, SquireDialogTree.SquireHasANewNickname);
    }

    public void SetSquireTeam(Mobile from, string newTeam)
    {
        if (from.AccessLevel < AccessLevel.GameMaster && from != ControlMaster)
        {
            if (!_squireBeQuiet)
            {
                Say("Who are you to tell me what team I belong to?");
            }

            return;
        }

        if (!from.Alive)
        {
            if (!_squireBeQuiet)
            {
                Say("What was that?");
            }

            return;
        }

        _squireTeam = newTeam.Length == 0 ? "Squire" : newTeam;

        SquireDialog.DoSquireDialog(this, SquireDialogTree.SquireHasANewTeam);
    }

    public override void OnThink()
    {
        base.OnThink();

        if (!Controlled)
        {
            return;
        }

        if (Core.Now > _delay)
        {
            var chivalryBook = Backpack.FindItemByType(typeof(BookOfChivalry));

            if (Hits > 0 && AutoVampiricEmbrace
                && !TransformationSpellHelper.UnderTransformation(this, typeof(Server.Spells.Necromancy.VampiricEmbraceSpell))
                && Backpack.FindItemByType(typeof(NecromancerSpellbook)) != null && Core.Now > _spellCastDelay
                && Skills.Necromancy.Value >= 99 && Mana >= 10)
            {
                new Server.Spells.Necromancy.VampiricEmbraceSpell(this, null).Cast();
                _spellCastDelay = Core.Now + TimeSpan.FromSeconds(6.0);
            }

            if (Hits > 0 && _autoLoot && Core.Now > _autoLootDelay)
            {
                _autoLootDelay = Core.Now + TimeSpan.FromSeconds(0.5);
                GrabItems(true, true, true);
            }

            var healthPotion = Backpack.FindItemByType(typeof(BaseHealPotion));
            var curePotion = Backpack.FindItemByType(typeof(BaseCurePotion));

            if (!TryHealSelf(chivalryBook, healthPotion, curePotion) && Hits >= HitsMax - 10 && ControlMaster != null)
            {
                TryHealMaster(ControlMaster, chivalryBook);
            }
        }

        if (Loyalty < BaseCreature.MaxLoyalty)
        {
            CheckFeedSelf();
        }

        if (_autoPickupAmmo
            && (FindItemOnLayer(Layer.TwoHanded) is BaseRanged || FindItemOnLayer(Layer.OneHanded) is BaseRanged))
        {
            GrabAmmo(false);
        }

        if (Core.Now > _weaponAbilityDelay && _autoUseWeaponAbility)
        {
            SetRandomWeaponAbility();
            _weaponAbilityDelay = Core.Now + TimeSpan.FromSeconds(30);
        }
    }

    private bool TryHealSelf(Item chivalryBook, Item healthPotion, Item curePotion)
    {
        if (_autoUseHealthPotion && healthPotion != null && Core.Now > _healthDelay && Hits <= HitsMax / 2
            && !Poisoned && !MortalStrike.IsWounded(this))
        {
            ((BasePotion)healthPotion).Drink(this);
            _healthDelay = Core.Now + TimeSpan.FromSeconds(10);
            SquireDialog.DoSquireDialog(this, SquireDialogTree.HealthPotion);
            return true;
        }

        if (_autoCastCloseWounds && chivalryBook != null && !IsDeadPet && Mana >= 10 && TithingPoints >= 10
            && Core.Now > _spellCastDelay && Hits <= HitsMax / 3 * 2 && !Poisoned && !MortalStrike.IsWounded(this))
        {
            new Server.Spells.Chivalry.CloseWoundsSpell(this, null).Cast();
            new SquireSelfCloseWoundsDelayTimer(this, TimeSpan.FromSeconds(1.5)).Start();
            _spellCastDelay = Core.Now + TimeSpan.FromSeconds(4.0);
            return true;
        }

        if (_autoUseCurePotion && curePotion != null && Poisoned && Core.Now > _cureDelay)
        {
            ((BasePotion)curePotion).Drink(this);
            _cureDelay = Core.Now + TimeSpan.FromSeconds(4);
            SquireDialog.DoSquireDialog(this, SquireDialogTree.CurePotion);
            return true;
        }

        if (_autoCastCleanseByFire && chivalryBook != null && !IsDeadPet && Mana >= 10 && TithingPoints >= 10
            && Core.Now > _spellCastDelay && Hits >= HitsMax / 3 * 2 && Poisoned)
        {
            new Server.Spells.Chivalry.CleanseByFireSpell(this, null).Cast();
            new SquireSelfCleanseByFireDelayTimer(this, TimeSpan.FromSeconds(1.0)).Start();
            _spellCastDelay = Core.Now + TimeSpan.FromSeconds(4.0);
            return true;
        }

        if (_autoHealSelf && Hits < HitsMax - 10 && BandageContext.GetContext(this) == null)
        {
            var bandage = Backpack.FindItemByType(typeof(Bandage));

            if (bandage != null && BandageContext.BeginHeal(this, this) != null)
            {
                bandage.Consume(1);
                RevealingAction();
                _delay = Core.Now + TimeSpan.FromSeconds(11);
                return true;
            }
        }

        return false;
    }

    private void TryHealMaster(Mobile m, Item chivalryBook)
    {
        if (!InRange(ControlMaster, Bandage.Range))
        {
            if (_autoHealMaster && m.Hidden && m.Alive && m.Hits < m.HitsMax - 10)
            {
                Annoy(SquireDialogTree.ASquiresConcern);
            }
            else if (_desperateMasterRun && m.Alive && m.Hits < m.HitsMax / 2)
            {
                if (ControlOrder == OrderType.Stay)
                {
                    Annoy(SquireDialogTree.ASquiresStay);
                }
                else
                {
                    AIObject.MoveTo(m, true, 1);
                }
            }
        }
        else if (_autoHealMaster && !m.Hidden)
        {
            if (m.Alive && m.Poisoned)
            {
                if (_autoCastCleanseByFireMaster && chivalryBook != null && !IsDeadPet && Mana >= 10 && TithingPoints >= 10
                    && Core.Now > _spellCastDelay && Hits >= HitsMax / 3 * 2)
                {
                    CastCleanseByFireOn(m);
                }
                else
                {
                    BandageHeal(m, SquireDialogTree.SquireCuresMaster, 4, SkillCheck.Cure);
                }
            }
            else if (m.Alive && _autoCastCloseWoundsMaster && chivalryBook != null && !IsDeadPet && Mana >= 10 && TithingPoints >= 10
                && Core.Now > _spellCastDelay && m.Hits <= m.HitsMax / 3 * 2 && !m.Poisoned && !MortalStrike.IsWounded(m))
            {
                CastCloseWoundsOn(m);
            }
            else if (m.Alive && m.Hits < m.HitsMax - 10)
            {
                BandageHeal(m, SquireDialogTree.SquireHealsMaster, 4);
            }
            else if (!m.Alive)
            {
                if (_autoUseSpiritSpeak && Core.Now > _spiritDelay)
                {
                    SquireSpeaksWithSpirits();
                }

                if (_autoRezMaster)
                {
                    BandageHeal(m, SquireDialogTree.SquireRezsMaster, 9, SkillCheck.Resurrect);
                }
            }
        }

        if (m.Hits > m.HitsMax - 10 && !m.Poisoned && m.Alive)
        {
            foreach (var search in GetMobilesInRange(Bandage.Range))
            {
                if (search is BaseCreature bc && bc != this && bc.Controlled && bc.ControlMaster == ControlMaster
                    && CanSee(bc) && bc.Hits < bc.HitsMax - 10
                    && (_autoHealAnimals || bc.Body == 0x191 || bc.Body == 0x190 || bc.Body == 0x25D || bc.Body == 0x25E))
                {
                    AutoHealAlly(bc);
                    break;
                }
            }
        }
    }

    private void CastCleanseByFireOn(Mobile target)
    {
        new Server.Spells.Chivalry.CleanseByFireSpell(this, null).Cast();
        new SquireTargetCleanseByFireDelayTimer(this, target, TimeSpan.FromSeconds(1.0)).Start();
        _spellCastDelay = Core.Now + TimeSpan.FromSeconds(4.0);
    }

    private void CastCloseWoundsOn(Mobile target)
    {
        new Server.Spells.Chivalry.CloseWoundsSpell(this, null).Cast();
        new SquireTargetCloseWoundsDelayTimer(this, target, TimeSpan.FromSeconds(1.5)).Start();
        _spellCastDelay = Core.Now + TimeSpan.FromSeconds(4.0);
    }

    private enum SkillCheck
    {
        None,
        Cure,
        Resurrect,
        VeterinaryCure,
        VeterinaryResurrect
    }

    private bool BandageHeal(Mobile target, SquireDialogTree dialog, int delaySeconds,
        SkillCheck skillCheck = SkillCheck.None, BaseCreature dialogTarget = null)
    {
        switch (skillCheck)
        {
            case SkillCheck.Cure when Skills.Healing.Value < 60.0 || Skills.Anatomy.Value < 60.0:
            case SkillCheck.Resurrect when Skills.Healing.Value < 80.0 || Skills.Anatomy.Value < 80.0:
            case SkillCheck.VeterinaryCure when Skills.Veterinary.Value < 60.0 || Skills.AnimalLore.Value < 60.0:
            case SkillCheck.VeterinaryResurrect when Skills.Veterinary.Value < 80.0 || Skills.AnimalLore.Value < 80.0:
                return false;
        }

        var bandage = Backpack.FindItemByType(typeof(Bandage));

        if (bandage == null || BandageContext.BeginHeal(this, target) == null)
        {
            return false;
        }

        bandage.Consume(1);
        RevealingAction();
        SquireDialog.DoSquireDialog(this, dialog, dialogTarget, null);
        _delay = Core.Now + TimeSpan.FromSeconds(delaySeconds);
        return true;
    }

    private void CheckFeedSelf()
    {
        if (IsDeadPet || Backpack == null || Loyalty >= BaseCreature.MaxLoyalty || Utility.RandomDouble() < 0.5)
        {
            return;
        }

        ++Loyalty;
        Stam += 15;
        Hunger = 10;

        if (!_squireBeQuiet)
        {
            Emote("*Looks happier.*");
        }

        if (!IsBondable || IsBonded || ControlMaster?.Skills[SkillName.AnimalTaming].Value < MinTameSkill)
        {
            return;
        }

        if (BondingBegin == DateTime.MinValue)
        {
            BondingBegin = Core.Now;
        }
        else if (BondingBegin + BondingDelay <= Core.Now)
        {
            IsBonded = true;
            BondingBegin = DateTime.MinValue;
            ControlMaster.SendLocalizedMessage(1049666);
            InvalidateProperties();
        }
    }

    public void GrabItems(bool ignoreNoteriety, bool goldAndMapOnly) => GrabItems(ignoreNoteriety, goldAndMapOnly, false);

    public void GrabItems(bool ignoreNoteriety, bool goldAndMapOnly, bool autoLootMode)
    {
        using var items = PooledRefList<Item>.Create();
        using var myItems = PooledRefList<Item>.Create();
        var rejected = false;
        var canthold = false;
        var lootAdded = false;

        if (!_squireBeQuiet && !autoLootMode)
        {
            Emote("*Rummages through items on the ground.*");
        }

        foreach (var item in GetItemsInRange(3))
        {
            if (item.Movable)
            {
                if (IsFilteredLoot(item) || !goldAndMapOnly)
                {
                    items.Add(item);
                }
            }
            else if (item is Corpse corpse
                && (ignoreNoteriety || corpse.Owner == this
                    || NotorietyHandlers.CorpseNotoriety(this, corpse) != Notoriety.Innocent))
            {
                if (corpse.Owner?.Player == true)
                {
                    if (!_squireBeQuiet && !autoLootMode)
                    {
                        SquireDialog.DoSquireDialog(null, this, SquireDialogTree.RefusesToLootPlayers, null, null);
                    }
                }
                else
                {
                    if (!_squireBeQuiet && !autoLootMode)
                    {
                        Emote("*Rummages through items in a corpse.*");
                    }

                    foreach (var corpseItem in corpse.Items)
                    {
                        if (corpse.Owner == this)
                        {
                            myItems.Add(corpseItem);
                        }
                        else if (IsFilteredLoot(corpseItem) || !goldAndMapOnly)
                        {
                            items.Add(corpseItem);
                        }
                    }
                }
            }
        }

        foreach (var item in items)
        {
            if (Backpack == null || !Backpack.CheckHold(this, item, false, true))
            {
                canthold = true;
                continue;
            }

            if (item.Stackable && _convenientStackable && Backpack.TryDropItem(this, item, false))
            {
                continue;
            }

            var isRejected = false;
            LRReason reason;
            NextActionTime = Core.TickCount + 5000;
            Lift(item, item.Amount, out isRejected, out reason);

            if (isRejected)
            {
                rejected = true;
                continue;
            }

            lootAdded = true;

            if (AutoEquipLoot)
            {
                Drop(this, Point3D.Zero);
            }
            else
            {
                Drop(Backpack, new Point3D(Utility.Random(29, 108), Utility.Random(34, 94), 0));
            }
        }

        foreach (var item in myItems)
        {
            if (Backpack == null || !Backpack.CheckHold(this, item, false, true))
            {
                canthold = true;
                continue;
            }

            Backpack.DropItem(item);
            lootAdded = true;
        }

        if (autoLootMode)
        {
            return;
        }

        if (lootAdded)
        {
            PlaySound(0x2E6);
        }

        if (!_squireBeQuiet)
        {
            if (canthold)
            {
                Say("I can't hold more items.");
            }

            if (rejected)
            {
                Say("I could not pick up all of the items.");
            }
        }
    }

    private bool IsFilteredLoot(Item item) =>
        _lootGold && item is Gold
        || _lootMap && item is TreasureMap
        || _lootZoogiFungus && item is ZoogiFungus
        || _lootDaemonBone && item is DaemonBone;

    public void GrabAmmo(bool ignoreNoteriety)
    {
        using var items = PooledRefList<Item>.Create();

        foreach (var item in GetItemsInRange(2))
        {
            if (item.Movable && item is Arrow or Bolt)
            {
                items.Add(item);
            }
        }

        foreach (var item in items)
        {
            if (Backpack == null || !Backpack.CheckHold(this, item, false, true))
            {
                continue;
            }

            var isRejected = false;
            LRReason reason;
            NextActionTime = Core.TickCount + 5000;
            Lift(item, item.Amount, out isRejected, out reason);

            if (isRejected)
            {
                continue;
            }

            Drop(this, Point3D.Zero);

            if (Core.Now > _pickUpEmoteDelay)
            {
                if (!_squireBeQuiet)
                {
                    Emote("*Retrieves ammunition.*");
                }

                _pickUpEmoteDelay = Core.Now + TimeSpan.FromSeconds(10);
            }
        }
    }

    public override bool CheckGold(Mobile from, Item dropped) => dropped is not Gold && base.CheckGold(from, dropped);

    public IMount FindMyMount(Container pack)
    {
        foreach (var item in pack?.Items ?? Items)
        {
            if (item is IMountItem mountItem)
            {
                return mountItem.Mount;
            }

            if (item.Layer == Layer.Mount)
            {
                return (IMount)item;
            }
        }

        return null;
    }

    public override bool IsSnoop(Mobile from) => !SquirePack.CheckAccess(this, from) && base.IsSnoop(from);

    public override bool OnDragDrop(Mobile from, Item dropped)
    {
        if ((ControlMaster != from && this != from) || IsDeadPet)
        {
            return base.OnDragDrop(from, dropped);
        }

        if (dropped is Bandage or Food)
        {
            Backpack.DropItem(dropped);
            from.SendMessage($"You give {Name} supplies.");
            return true;
        }

        if (dropped is Gold)
        {
            Backpack.DropItem(dropped);
            from.SendMessage($"You give {Name} gold.");
            return true;
        }

        if (dropped is PowerScroll powerScroll)
        {
            Backpack.DropItem(dropped);

            if (_autoUsePowerScroll)
            {
                if (powerScroll.CanUse(this))
                {
                    powerScroll.Use(this);
                    SquireDialog.DoSquireDialog(this, SquireDialogTree.UsePowerScroll);
                }
                else
                {
                    SquireDialog.DoSquireDialog(this, SquireDialogTree.CantUsePowerScroll);
                }
            }

            return true;
        }

        if (dropped is Arrow or Bolt)
        {
            Backpack.DropItem(dropped);
            from.SendMessage($"You give {Name} ammunition.");
            return true;
        }

        if (dropped is STrainingContract contract)
        {
            Backpack.DropItem(dropped);

            if (_autoUseTScroll)
            {
                contract.OnDoubleClick(this);
            }

            return true;
        }

        if (dropped is BaseWeapon weapon)
        {
            if (weapon.AosStrengthReq > Str)
            {
                Annoy(SquireDialogTree.ThisIsTooHeavy, 20);
                from.AddToBackpack(dropped);
            }
            else
            {
                DropConflicting(weapon, Layer.TwoHanded);
                DropConflicting(weapon, Layer.OneHanded);
                DropConflicting(weapon, Layer.FirstValid);
                Backpack.DropItem(dropped);
                Annoy(SquireDialogTree.ThankYou, 20);
                AddItem(dropped);
                from.SendMessage($"You give {Name} a weapon.");
                return true;
            }
        }
        else if (dropped is BaseShield shield)
        {
            if (shield.AosStrReq > Str)
            {
                Annoy(SquireDialogTree.ThisIsTooHeavy, 20);
                from.AddToBackpack(dropped);
            }
            else
            {
                var twoHanded = FindItemOnLayer(Layer.TwoHanded);

                if (twoHanded != null && shield.CheckConflictingLayer(this, twoHanded, Layer.TwoHanded))
                {
                    from.AddToBackpack(twoHanded);
                    SquireDialog.DoSquireDialog(this, SquireDialogTree.UnequipsTwoHandedForShield);
                }

                var firstValid = FindItemOnLayer(Layer.FirstValid);

                if (firstValid != null && shield.CheckConflictingLayer(this, firstValid, Layer.FirstValid))
                {
                    from.AddToBackpack(firstValid);
                }

                Backpack.DropItem(dropped);
                Annoy(SquireDialogTree.ThankYou, 20);
                AddItem(dropped);
                from.SendMessage($"You give {Name} a shield.");
                return true;
            }
        }
        else if (dropped is BaseQuiver quiver)
        {
            var cloak = FindItemOnLayer(Layer.Cloak);

            if (cloak != null && quiver.CheckConflictingLayer(this, cloak, Layer.Cloak))
            {
                from.AddToBackpack(cloak);
            }

            Backpack.DropItem(dropped);
            Annoy(SquireDialogTree.ThankYou, 20);
            AddItem(dropped);
            from.SendMessage($"You give {Name} a quiver.");
            return true;
        }
        else if (dropped is BaseArmor armor)
        {
            if (armor.AosStrReq > Str)
            {
                Annoy(SquireDialogTree.ThisIsTooHeavy, 20);
                from.AddToBackpack(dropped);
            }
            else if (!armor.AllowMaleWearer && Body.IsMale)
            {
                from.SendLocalizedMessage(1010388);
                from.AddToBackpack(armor);
            }
            else if (!armor.AllowFemaleWearer && Body.IsFemale)
            {
                from.SendMessage("Only males can wear this.");
                from.AddToBackpack(armor);
            }
            else
            {
                var equipped = FindItemOnLayer(dropped.Layer);

                if (equipped != null)
                {
                    from.AddToBackpack(equipped);
                }

                Backpack.DropItem(dropped);
                Annoy(SquireDialogTree.ThankYou, 20);
                AddItem(dropped);
                from.SendMessage($"You give {Name} armor.");
                return true;
            }
        }
        else if (dropped is BaseClothing or BaseJewel)
        {
            var equipped = FindItemOnLayer(dropped.Layer);

            if (equipped != null)
            {
                from.AddToBackpack(equipped);
            }

            Backpack.DropItem(dropped);
            Annoy(SquireDialogTree.ThankYou, 20);
            AddItem(dropped);
            from.SendMessage($"You give {Name}{(dropped is BaseJewel ? " jewelry." : " clothing.")}");
            return true;
        }
        else
        {
            AddToBackpack(dropped);
            return true;
        }

        return base.OnDragDrop(from, dropped);
    }

    private void DropConflicting(BaseWeapon weapon, Layer layer)
    {
        var equipped = FindItemOnLayer(layer);

        if (equipped != null && weapon.CheckConflictingLayer(this, equipped, layer))
        {
            Backpack.DropItem(equipped);
        }
    }

    public override bool CheckNonlocalDrop(Mobile from, Item item, Item target) => SquirePack.CheckAccess(this, from);

    public override bool AllowEquipFrom(Mobile from) => SquirePack.CheckAccess(this, from);

    public override bool CheckNonlocalLift(Mobile from, Item item) => SquirePack.CheckAccess(this, from);

    private bool HasRangedEquipped()
    {
        if (FindItemOnLayer(Layer.TwoHanded) is BaseRanged)
        {
            Say("I have a ranged weapon");
            return true;
        }

        return false;
    }

    public override void OnItemAdded(Item item)
    {
        base.OnItemAdded(item);

        if (item is not BaseRanged)
        {
            return;
        }

        Say("I will use this ranged weapon from now on");
        PlaySound(0x511);
        FixedParticles(0x376A, 1, 14, 5045, EffectLayer.Waist);
        ChangeAIType(AIType.AI_Archer);
    }

    public override void OnItemRemoved(Item item)
    {
        base.OnItemRemoved(item);

        if (item is not BaseRanged)
        {
            return;
        }

        Say("I will change to melee");
        PlaySound(0x511);
        FixedParticles(0x376A, 1, 14, 5045, EffectLayer.Waist);
        ChangeAIToDefault();
    }

    public override bool OnBeforeDeath()
    {
        if (!IsBonded)
        {
            IsBonded = true;
        }

        return base.OnBeforeDeath();
    }

    public override void OnDeath(Container c)
    {
        c.DropItem(new SquireDeathShroud());
        base.OnDeath(c);
    }

    public override void OnAfterResurrect()
    {
        if (Backpack == null)
        {
            AddItem(new Backpack { Movable = false });
        }

        base.OnAfterResurrect();
    }

    private sealed class BackpackEntry : ContextMenuEntry
    {
        private readonly Squire _squire;
        private readonly Mobile _from;

        public BackpackEntry(Squire squire, Mobile from) : base(6145, 12)
        {
            _squire = squire;
            _from = from;
        }

        public override void OnClick(Mobile from, IEntity target)
        {
            SquirePack.TryPackOpen(_squire, _from);

            if (!_squire._squireBeQuiet)
            {
                SquireDialog.DoSquireDialog(_from, _squire, SquireDialogTree.ShowingOffASquiresBackpack, null, null);
            }
        }
    }

    public override void AddCustomContextEntries(Mobile from, ref PooledRefList<ContextMenuEntry> list)
    {
        if (from.Alive && SquirePack.CheckAccess(this, from))
        {
            list.Add(new BackpackEntry(this, from));
        }

        base.AddCustomContextEntries(from, ref list);
    }

    public void AutoHealAlly(BaseCreature bc)
    {
        if (bc?.Controlled != true || bc.ControlMaster == null || bc.ControlMaster != ControlMaster
            || !InRange(bc, Bandage.Range) || bc.Hidden)
        {
            return;
        }

        var humanoid = bc.Body == 0x191 || bc.Body == 0x190 || bc.Body == 0x25D || bc.Body == 0x25E;

        if (humanoid ? !_autoHealOther : !_autoHealAnimals)
        {
            return;
        }

        var chivalryBook = Backpack.FindItemByType(typeof(BookOfChivalry));

        if (bc.Alive && bc.Poisoned)
        {
            if (_autoCastCleanseByFireAlly && chivalryBook != null && !IsDeadPet && Mana >= 10 && TithingPoints >= 10
                && Core.Now > _spellCastDelay && Hits >= HitsMax / 3 * 2)
            {
                CastCleanseByFireOn(bc);
            }
            else
            {
                BandageHeal(bc, humanoid ? SquireDialogTree.SquireCuresHumanoid : SquireDialogTree.SquireCuresAnimal, 4,
                    humanoid ? SkillCheck.Cure : SkillCheck.VeterinaryCure, bc);
            }
        }
        else if (bc.Alive && bc.Hits < bc.HitsMax - 10)
        {
            if (_autoCastCloseWoundsAlly && chivalryBook != null && !IsDeadPet && Mana >= 10 && TithingPoints >= 10
                && Core.Now > _spellCastDelay && bc.Hits <= bc.HitsMax / 3 * 2 && !bc.Poisoned && !MortalStrike.IsWounded(bc))
            {
                CastCloseWoundsOn(bc);
            }
            else
            {
                BandageHeal(bc, SquireDialogTree.SquireHealsWounded, 4, dialogTarget: bc);
            }
        }
        else if (!bc.Alive)
        {
            BandageHeal(bc, humanoid ? SquireDialogTree.SquireRezsHumanoid : SquireDialogTree.SquireRezsAnimal, 9,
                humanoid ? SkillCheck.Resurrect : SkillCheck.VeterinaryResurrect, bc);
        }
    }

    public void SquireSpeaksWithSpirits()
    {
        if (Core.Now <= _spiritDelay)
        {
            if (!_spiritWorldConnected && !_squireBeQuiet)
            {
                SquireDialog.DoSquireDialog(null, this, SquireDialogTree.TooSoonToSpiritSpeak, null, null);
            }
            else if (_spiritWorldConnected && _squireBeQuiet)
            {
                SquireDialog.DoSquireDialog(null, this, SquireDialogTree.StillConnectedToSpirits, null, null);
            }

            return;
        }

        RevealingAction();
        var anim = new SquireSpiritAnimTimer(this);

        if (CheckSkill(SkillName.SpiritSpeak, 0, 100))
        {
            if (!CanHearGhosts)
            {
                var secs = Skills[SkillName.SpiritSpeak].Base / 50 * 90;

                if (secs < 15)
                {
                    secs = 15;
                }

                var timer = new SquireSpiritSpeakTimer(this)
                {
                    Delay = TimeSpan.FromSeconds(secs)
                };

                _spiritDelay = Core.Now + timer.Delay;
                timer.Start();
                CanHearGhosts = true;
                _spiritWorldConnected = true;
            }

            PlaySound(0x24A);
            Emote("Anh Mi Sah Ko");
            anim.Start();
            SquireDialog.DoSquireDialog(this, SquireDialogTree.SpiritSpeakSuccess);
        }
        else
        {
            PlaySound(0x24A);
            Emote("Anh Mi Sah Ko");
            anim.Start();
            SquireDialog.DoSquireDialog(this, SquireDialogTree.SpiritSpeakFail);
            _spiritDelay = Core.Now + TimeSpan.FromSeconds(10);
            CanHearGhosts = false;
            _spiritWorldConnected = false;
        }
    }

    private bool IsAnkhNearby()
    {
        foreach (var item in GetItemsInRange(8))
        {
            if (item.ItemID is 0x3 or 0x4)
            {
                return true;
            }
        }

        if (Map != null && Map != Map.Internal)
        {
            for (var x = X - 8; x <= X + 8; ++x)
            {
                for (var y = Y - 8; y <= Y + 8; ++y)
                {
                    foreach (var tile in Map.Tiles.GetStaticAndMultiTiles(x, y))
                    {
                        if (tile.ID is 0x3 or 0x4)
                        {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    public void SquireTithing()
    {
        if (!IsAnkhNearby())
        {
            SquireDialog.DoSquireDialog(this, SquireDialogTree.NoAnkhNearby);
            return;
        }

        if (TotalGold < 1)
        {
            SquireDialog.DoSquireDialog(this, SquireDialogTree.NoGoldToTithe);
            return;
        }

        var gold = Backpack?.FindItemByType(typeof(Gold));

        if (gold == null || gold.Amount <= 0)
        {
            return;
        }

        var devotion = gold.Amount;
        gold.Consume(devotion);
        SquireDialog.DoSquireDialog(this, SquireDialogTree.TitheSuccess);
        TithingPoints += devotion;
        PlaySound(0x243);
        PlaySound(0x2E6);

        if (!_squireBeQuiet)
        {
            SayTo(ControlMaster, $"I now have {TithingPoints} tithing points.");
        }
    }

    public override int GetMaxResistance(ResistanceType type)
    {
        if (Core.ML && Race == Race.Elf && type == ResistanceType.Energy)
        {
            return 85;
        }

        return 80;
    }

    public override double RacialSkillBonus => 20;

    [AfterDeserialization]
    private void AfterDeserialization()
    {
        if (HasRangedEquipped())
        {
            ChangeAIType(AIType.AI_Archer);
        }
    }
}
