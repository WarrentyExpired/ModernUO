using System;
using Server.Collections;
using ModernUO.Serialization;
using Server;
using Server.Items;
using Server.Mobiles;
using Server.Network;
using Server.Gumps;
using Server.Misc;
using Server.SkillHandlers;
using System.Collections.Generic;
using Server.Targeting;
using Server.Prompts;
using Server.ContextMenus;
using Server.Multis;

namespace Server.Mobiles;

public class ChangeARumorMessagePrompt : Prompt
{
	private readonly RoomAttendant _roomAttendant;
	private readonly int _rumorIndex;

	public ChangeARumorMessagePrompt(RoomAttendant roomAttendant, int rumorIndex)
	{
		_roomAttendant = roomAttendant;
		_rumorIndex = rumorIndex;
	}

	public override void OnCancel(Mobile from)
	{
		OnResponse(from, "");
	}

	public override void OnResponse(Mobile from, string text)
	{
		if (text.Length > 130)
			text = text[..130];

		_roomAttendant.EndChangeRumor(from, _rumorIndex, text);
	}
}

public class ChangeARumorKeywordPrompt : Prompt
{
	private readonly RoomAttendant _roomAttendant;
	private readonly int _rumorIndex;

	public ChangeARumorKeywordPrompt(RoomAttendant roomAttendant, int rumorIndex)
	{
		_roomAttendant = roomAttendant;
		_rumorIndex = rumorIndex;
	}

	public override void OnCancel(Mobile from)
	{
		OnResponse(from, "");
	}

	public override void OnResponse(Mobile from, string text)
	{
		if (text.Length > 130)
			text = text[..130];

		_roomAttendant.EndChangeKeyword(from, _rumorIndex, text);
	}
}

public class ChangeATipMessagePrompt : Prompt
{
	private readonly RoomAttendant _roomAttendant;

	public ChangeATipMessagePrompt(RoomAttendant roomAttendant)
	{
		_roomAttendant = roomAttendant;
	}

	public override void OnCancel(Mobile from)
	{
		OnResponse(from, "");
	}

	public override void OnResponse(Mobile from, string text)
	{
		if (text.Length > 130)
			text = text[..130];

		_roomAttendant.EndChangeTip(from, text);
	}
}

public class RoomAttendantRumor
{
	public string Message { get; set; }
	public string Keyword { get; set; }

	public RoomAttendantRumor(string message, string keyword)
	{
		Message = message;
		Keyword = keyword;
	}
}

public class ManageRoomAttendantEntry : ContextMenuEntry
{
	private readonly Mobile _from;
	private readonly RoomAttendant _roomAttendant;

	public ManageRoomAttendantEntry(Mobile from, RoomAttendant roomAttendant) : base(6151, 12)
	{
		_from = from;
		_roomAttendant = roomAttendant;
	}

	public override void OnClick(Mobile from, IEntity target)
	{
		_roomAttendant.BeginManagement(_from);
	}
}

[SerializationGenerator(0, false)]
public partial class RoomAttendant : BaseVendor
{
	private Mobile _owner;
	private BaseHouse _house;
	private string _tipMessage;

	[SerializableField(3)]
	private string[] _rumorMessages;

	[SerializableField(4)]
	private string[] _rumorKeywords;

	private static readonly Dictionary<string, int> _keywords = new(StringComparer.OrdinalIgnoreCase)
	{
		[" "] = 0,
		["room"] = 1,
		["help"] = 2
	};

	[CommandProperty(AccessLevel.GameMaster)]
	[SerializableProperty(1, useField: nameof(_owner))]
	public Mobile Owner
	{
		get => _owner;
		set => _owner = value;
	}

	[SerializableProperty(0, useField: nameof(_house))]
	public BaseHouse House
	{
		get => _house;
		set => _house = value;
	}

	[CommandProperty(AccessLevel.GameMaster)]
	[SerializableProperty(2, useField: nameof(_tipMessage))]
	public string TipMessage
	{
		get => _tipMessage;
		set => _tipMessage = value;
	}

	public override bool IsActiveBuyer => false;

	public override bool DisallowAllMoves => true;
	public override bool NoHouseRestrictions => true;

	public override VendorShoeType ShoeType => Utility.RandomBool() ? VendorShoeType.ThighBoots : VendorShoeType.Boots;

	public override bool GetGender() => false;

	public override void InitOutfit()
	{
		base.InitOutfit();
		Backpack?.Delete();
	}

	public override void InitBody()
	{
		base.InitBody();

		Hue = Body == 0x340 || Body == 0x402 ? 0 : 0x83F4;

		Backpack?.Delete();
	}

	public RoomAttendant(Mobile owner, BaseHouse house) : base("the room attendant")
	{
		Blessed = true;
		_owner = owner;
		House = house;
		_rumorMessages = new string[3];
		_rumorKeywords = new string[3];

		LoadSBInfo();
	}

	public override bool HandlesOnSpeech(Mobile from) => InRange(from, 3) || base.HandlesOnSpeech(from);

	public override void OnAfterDelete()
	{
		base.OnAfterDelete();
		House = null;
	}

	public override bool OnBeforeDeath()
	{
		if (!base.OnBeforeDeath())
			return false;

		if (FindItemOnLayer(Layer.Shoes) is Sandals shoes)
			shoes.Hue = 0;

		return true;
	}

	public override void OnSpeech(SpeechEventArgs e)
	{
		var from = e.Mobile;
		var bank = from.FindBankNoCreate();

		var command = -1;

		if (MatchPrefix(e.Speech, "vendor"))
			_keywords.TryGetValue(e.Speech[7..], out command);
		else if (Name != null && MatchPrefix(e.Speech, Name))
			_keywords.TryGetValue(e.Speech[(Name.Length + 1)..], out command);
		else if (MatchPrefix(e.Speech, "attendant"))
			_keywords.TryGetValue(e.Speech[10..], out command);

		switch (command)
		{
			case 1:
			{
				if ((from.Backpack == null || from.Backpack.GetAmount(typeof(Gold)) < 300) && (bank == null || Banker.GetBalance(from) < 300))
				{
					SayTo(from, "Thou dost not have enough gold, not even in thy bank account.");
				}
				else
				{
					SayTo(from, "I need three hundred gold for the carrier pigeon rental.");
					from.Target = new RoomTarget(this);
				}

				break;
			}
			case 2:
			{
				SayTo(from, "For a fee I can rent a carrier pigeon for you to call your squire with from their room.");
				break;
			}
			default:
			{
				base.OnSpeech(e);

				if (e.Handled || !InRange(e.Mobile, 3))
					break;

				for (var i = 0; i < _rumorMessages.Length; ++i)
				{
					if (_rumorMessages[i] == null && _rumorKeywords[i] == null)
						continue;

					var keyword = _rumorKeywords[i];

					if (keyword == null || (keyword = keyword.Trim()).Length == 0)
						continue;

					if (!string.Equals(keyword, e.Speech, StringComparison.OrdinalIgnoreCase))
						continue;

					var message = _rumorMessages[i];

					if (message == null || (message = message.Trim()).Length == 0)
						continue;

					PublicOverheadMessage(MessageType.Regular, 0x3B2, false, message);
				}

				break;
			}
		}
	}

	private static bool MatchPrefix(string speech, string prefix) =>
		speech.Length > prefix.Length && speech.StartsWith(prefix + ' ', StringComparison.OrdinalIgnoreCase);

	public override bool CheckGold(Mobile from, Item dropped)
	{
		if (dropped is not Gold g)
			return false;

		if (g.Amount > 50)
		{
			PrivateOverheadMessage(MessageType.Regular, 0x3B2, false, "I cannot accept so large a tip!", from.NetState);
			return false;
		}

		var tip = _tipMessage;

		if (tip == null || (tip = tip.Trim()).Length == 0)
		{
			PrivateOverheadMessage(MessageType.Regular, 0x3B2, false, "It would not be fair of me to take your money and not offer you information in return.", from.NetState);
			return false;
		}

		Direction = GetDirectionTo(from);
		PrivateOverheadMessage(MessageType.Regular, 0x3B2, false, tip, from.NetState);

		g.Delete();
		return true;
	}

	public bool IsOwner(Mobile from)
	{
		if (from == null || from.Deleted || Deleted)
			return false;

		if (from.AccessLevel > AccessLevel.GameMaster)
			return true;

		return _owner == from;
	}

	public override void GetContextMenuEntries(Mobile from, ref PooledRefList<ContextMenuEntry> list)
	{
		base.GetContextMenuEntries(from, ref list);

		if (IsOwner(from) && from.InLOS(this))
			list.Add(new ManageRoomAttendantEntry(from, this));
	}

	public void BeginManagement(Mobile from)
	{
		if (!IsOwner(from))
			return;

		from.SendGump(new RoomAttendantGump(from, this));
	}

	public void Dismiss() => Delete();

	public void BeginChangeRumor(Mobile from, int index)
	{
		if (index < 0 || index >= _rumorMessages.Length)
			return;

		from.Prompt = new ChangeARumorMessagePrompt(this, index);
		PrivateOverheadMessage(MessageType.Regular, 0x3B2, false, "Say what news you would like me to tell our guests.", from.NetState);
	}

	public void EndChangeRumor(Mobile from, int index, string text)
	{
		if (index < 0 || index >= _rumorMessages.Length)
			return;

		_rumorMessages[index] = text;

		from.Prompt = new ChangeARumorKeywordPrompt(this, index);
		PrivateOverheadMessage(MessageType.Regular, 0x3B2, false, "What keyword should a guest say to me to get this news?", from.NetState);
	}

	public void EndChangeKeyword(Mobile from, int index, string text)
	{
		if (index < 0 || index >= _rumorMessages.Length)
			return;

		_rumorKeywords[index] = text;

		PrivateOverheadMessage(MessageType.Regular, 0x3B2, false, "I'll pass on the message.", from.NetState);
	}

	public void RemoveRumor(Mobile from, int index)
	{
		if (index < 0 || index >= _rumorMessages.Length)
			return;

		_rumorMessages[index] = null;
		_rumorKeywords[index] = null;
	}

	public RoomAttendantRumor[] Rumors
	{
		get
		{
			var rumors = new RoomAttendantRumor[_rumorMessages.Length];

			for (var i = 0; i < rumors.Length; ++i)
			{
				rumors[i] = _rumorMessages[i] != null || _rumorKeywords[i] != null
					? new RoomAttendantRumor(_rumorMessages[i], _rumorKeywords[i])
					: null;
			}

			return rumors;
		}
	}

	public void BeginChangeTip(Mobile from)
	{
		from.Prompt = new ChangeATipMessagePrompt(this);
		PrivateOverheadMessage(MessageType.Regular, 0x3B2, false, "Say what you want me to tell guests when they give me a good tip.", from.NetState);
	}

	public void EndChangeTip(Mobile from, string text)
	{
		_tipMessage = text;
		PrivateOverheadMessage(MessageType.Regular, 0x3B2, false, "I'll say that to anyone who gives me a good tip.", from.NetState);
	}

	public void RemoveTip(Mobile from)
	{
		_tipMessage = null;
	}

	public void BeginChangeAppearance(Mobile from)
	{
		from.CloseGump<PlayerVendorCustomizeGump>();
		from.SendGump(new PlayerVendorCustomizeGump(this, from));
	}

	public void ChangeGender(Mobile from)
	{
		Female = !Female;

		if (Female)
		{
			Body = 401;
			Name = NameList.RandomName("female");
			FacialHairItemID = 0;
		}
		else
		{
			Body = 400;
			Name = NameList.RandomName("male");
		}
	}

	private readonly List<SBInfo> _sBInfos = [];
	protected override List<SBInfo> SBInfos => _sBInfos;

	public override void InitSBInfo()
	{
		if (Title == "the room attendant")
		{
			if (_sBInfos.Count == 0)
				_sBInfos.Add(new SBRoomAttendant());
		}
		else
		{
			_sBInfos.Clear();
		}
	}

	private class RoomTarget : Target
	{
		private readonly RoomAttendant _roomAttendant;

		public RoomTarget(RoomAttendant roomAttendant) : base(12, false, TargetFlags.None)
		{
			_roomAttendant = roomAttendant;
		}

		protected override void OnTarget(Mobile from, object s)
		{
			if (s == from)
			{
				_roomAttendant.Say("Haha! Sorry! I thought we were rooming someone else... You may sleep here for free.");
			}
			else if (s is PlayerMobile)
			{
				_roomAttendant.Say("Haha! Sorry! I think the sir or madam may speak for themselves.");
			}
			else if (s is not Squire)
			{
				_roomAttendant.Say("That... Doesn't look like a squire to me.");
			}
			else
			{
				var squi = (BaseCreature)s;

				if (squi.Combatant != null && squi.InRange(squi.Combatant, 12) && squi.Map == squi.Combatant.Map)
				{
					_roomAttendant.SayTo(from, "Your squire seems to be distracted...");
				}
				else if (!(squi.Controlled && squi.ControlMaster == from))
				{
					_roomAttendant.SayTo(from, "That is not your squire to room.");
				}
				else if (squi.Mounted)
				{
					_roomAttendant.SayTo(from, "This is not a stable, please have your squire dismount before I rent them a room.");
				}
				else if (squi.Summoned)
				{
					_roomAttendant.SayTo(from, "How did you summon a squire with magic?");
				}
				else if (!squi.Alive)
				{
					_roomAttendant.SayTo(from, "I do not provide rooms for ghosts.");
				}
				else if (squi is Squire && squi.Controlled && from == squi.ControlMaster && from.Backpack != null && from.Backpack.ConsumeTotal(typeof(Gold), 300) || Banker.Withdraw(from, 300))
				{
					RoomAFunctions.Room(from, squi, true);
				}
				else
				{
					_roomAttendant.SayTo(from, "I will not room... That.");
				}
			}
		}
	}

	private class RoomEntry : ContextMenuEntry
	{
		private readonly RoomAttendant _attendant;
		private readonly Mobile _from;

		public RoomEntry(RoomAttendant roomAttendant, Mobile from) : base(560, 12)
		{
			_attendant = roomAttendant;
			_from = from;
		}

		public override void OnClick(Mobile from, IEntity target)
		{
			var bank = _from.FindBankNoCreate();

			if ((_from.Backpack == null || _from.Backpack.GetAmount(typeof(Gold)) < 300) && Banker.GetBalance(_from) < 300)
			{
				_attendant.SayTo(_from, "Thou dost not have enough gold, not even in thy bank account.");
			}
			else
			{
				_attendant.SayTo(_from, "I need three hundred gold for the carrier pigeon rental.");
				_from.Target = new RoomTarget(_attendant);
			}
		}
	}

	public override void AddCustomContextEntries(Mobile from, ref PooledRefList<ContextMenuEntry> list)
	{
		if (from.Alive)
		{
			list.Add(new RoomEntry(this, from));
		}

		base.AddCustomContextEntries(from, ref list);
	}
}

public class RoomAttendantGump : DynamicGump
{
	public override bool Singleton => true;

	private readonly Mobile _from;
	private readonly RoomAttendant _roomAttendant;

	private static int GetButtonID(int type, int index) => 1 + index * 6 + type;

	public RoomAttendantGump(Mobile from, RoomAttendant roomAttendant) : base(0, 0)
	{
		_from = from;
		_roomAttendant = roomAttendant;
	}

	private void RenderBackground(ref DynamicGumpBuilder builder)
	{
		builder.AddPage(0);

		builder.AddBackground(30, 40, 585, 410, 5054);

		builder.AddImage(30, 40, 9251);
		builder.AddImage(180, 40, 9251);
		builder.AddImage(30, 40, 9253);
		builder.AddImage(30, 130, 9253);
		builder.AddImage(598, 40, 9255);
		builder.AddImage(598, 130, 9255);
		builder.AddImage(30, 433, 9257);
		builder.AddImage(180, 433, 9257);
		builder.AddImage(30, 40, 9250);
		builder.AddImage(598, 40, 9252);
		builder.AddImage(598, 433, 9258);
		builder.AddImage(30, 433, 9256);

		builder.AddItem(30, 40, 6816);
		builder.AddItem(30, 125, 6817);
		builder.AddItem(30, 233, 6817);
		builder.AddItem(30, 341, 6817);
		builder.AddItem(580, 40, 6814);
		builder.AddItem(588, 125, 6815);
		builder.AddItem(588, 233, 6815);
		builder.AddItem(588, 341, 6815);

		builder.AddBackground(183, 25, 280, 30, 5054);

		builder.AddImage(180, 25, 10460);
		builder.AddImage(434, 25, 10460);
		builder.AddImage(560, 20, 1417);

		builder.AddHtml(223, 32, 200, 40, "ATTENDANT CUSTOMIZATION MENU", background: false, scrollbar: false);
		builder.AddBackground(243, 433, 150, 30, 5054);

		builder.AddImage(240, 433, 10460);
		builder.AddImage(375, 433, 10460);
	}

	private static void AddBackButton(ref DynamicGumpBuilder builder, int page)
	{
		builder.AddButton(338, 437, 4014, 4016, 0, GumpButtonType.Page, page);
		builder.AddHtml(290, 440, 35, 40, "Back", background: false, scrollbar: false);
	}

	private static void AddMenuEntry(ref DynamicGumpBuilder builder, int x, int y, string label, int page) =>
		AddMenuEntry(ref builder, x, y, label, page, 380, 20);

	private static void AddMenuEntry(ref DynamicGumpBuilder builder, int x, int y, string label, int page, int width, int height) =>
		AddMenuEntry(ref builder, x, y, label, 0, GumpButtonType.Page, page, width, height, 40);

	private static void AddMenuEntry(ref DynamicGumpBuilder builder, int x, int y, string label, int buttonId, GumpButtonType type, int param, int width, int height, int labelOffset)
	{
		builder.AddButton(x, y, 4005, 4007, buttonId, type, param);
		builder.AddHtml(x + labelOffset, y, width, height, label, background: false, scrollbar: false);
	}

	private void RenderCategories(ref DynamicGumpBuilder builder)
	{
		builder.AddPage(1);

		AddMenuEntry(ref builder, 130, 120, "Message Control", 2, 200, 40);
		AddMenuEntry(ref builder, 130, 200, "Customize your room attendant", 8, 200, 40);
		AddMenuEntry(ref builder, 130, 280, "Dismiss your room attendant", 3, 200, 40);

		builder.AddButton(338, 437, 4014, 4016, 0, GumpButtonType.Reply, 0);
		builder.AddHtml(290, 440, 35, 40, "Back", background: false, scrollbar: false);

		builder.AddItem(574, 43, 5360);
	}

	private void RenderMessageManagement(ref DynamicGumpBuilder builder)
	{
		builder.AddPage(2);

		AddMenuEntry(ref builder, 130, 120, "Add or change a message and keyword", 4);
		AddMenuEntry(ref builder, 130, 200, "Remove a message and keyword from your room attendant", 5);
		AddMenuEntry(ref builder, 130, 280, "Add or change your room attendant's tip message", 6);
		AddMenuEntry(ref builder, 130, 360, "Delete your room attendant's tip message", 7);

		AddBackButton(ref builder, 1);

		builder.AddItem(580, 46, 4030);
	}

	private void RenderDismissConfirmation(ref DynamicGumpBuilder builder)
	{
		builder.AddPage(3);

		builder.AddHtml(170, 160, 380, 20, "Are you sure you want to dismiss your room attendant?", background: false, scrollbar: false);

		AddMenuEntry(ref builder, 205, 280, "Yes", GetButtonID(0, 0), GumpButtonType.Reply, 0, 100, 20, 35);
		AddMenuEntry(ref builder, 395, 280, "No", 0, GumpButtonType.Reply, 0, 100, 20, 35);

		AddBackButton(ref builder, 1);

		builder.AddItem(574, 43, 5360);
		builder.AddItem(584, 34, 6579);
	}

	private void RenderRumorList(ref DynamicGumpBuilder builder, int page, string title, int type, int titleX)
	{
		builder.AddPage(page);

		builder.AddHtml(titleX, 60, 500, 25, title, background: false, scrollbar: false);

		var rumors = _roomAttendant.Rumors;

		for (var i = 0; i < rumors.Length; ++i)
		{
			var rumor = rumors[i];

			builder.AddHtml(100, 70 + i * 120, 50, 20, "Message", background: false, scrollbar: false);
			builder.AddHtml(100, 90 + i * 120, 450, 40, rumor == null ? "No current message" : rumor.Message, background: true, scrollbar: false);
			builder.AddHtml(100, 130 + i * 120, 50, 20, "Keyword", background: false, scrollbar: false);
			builder.AddHtml(100, 150 + i * 120, 450, 40, rumor == null ? "None" : rumor.Keyword, background: true, scrollbar: false);

			builder.AddButton(60, 90 + i * 120, 4005, 4007, GetButtonID(type, i), GumpButtonType.Reply, 0);
		}

		AddBackButton(ref builder, 2);

		builder.AddItem(580, 46, 4030);
	}

	private void RenderTip(ref DynamicGumpBuilder builder, int page, string title, int type)
	{
		builder.AddPage(page);

		builder.AddHtml(250, 95, 500, 20, title, background: false, scrollbar: false);
		builder.AddHtml(100, 190, 50, 20, "Message", background: false, scrollbar: false);
		builder.AddHtml(100, 210, 450, 40, _roomAttendant.TipMessage == null ? "No current message" : _roomAttendant.TipMessage, background: true, scrollbar: false);

		builder.AddButton(60, 210, 4005, 4007, GetButtonID(type, 0), GumpButtonType.Reply, 0);

		AddBackButton(ref builder, 2);

		builder.AddItem(580, 46, 4030);
	}

	private void RenderAppearanceCategories(ref DynamicGumpBuilder builder)
	{
		builder.AddPage(8);

		if (_roomAttendant.Body != 0x340 && _roomAttendant.Body != 0x402)
		{
			AddMenuEntry(ref builder, 130, 200, "Appearance", GetButtonID(5, 1), GumpButtonType.Reply, 0, 120, 20, 40);
			AddMenuEntry(ref builder, 130, 280, "Male / Female", GetButtonID(5, 2), GumpButtonType.Reply, 0, 120, 20, 40);

			AddBackButton(ref builder, 1);
		}

		builder.AddItem(580, 44, 4033);
	}

	protected override void BuildLayout(ref DynamicGumpBuilder builder)
	{
		_from.CloseGump<RoomAttendantGump>();

		RenderBackground(ref builder);
		RenderCategories(ref builder);
		RenderMessageManagement(ref builder);
		RenderDismissConfirmation(ref builder);
		RenderRumorList(ref builder, 4, "Add or change a message", 1, 250);
		RenderRumorList(ref builder, 5, "Choose the message you would like to remove", 2, 190);
		RenderTip(ref builder, 6, "Change this tip message", 3);
		RenderTip(ref builder, 7, "Remove this tip message", 4);
		RenderAppearanceCategories(ref builder);
	}

	public override void OnResponse(NetState state, in RelayInfo info)
	{
		if (!_roomAttendant.IsOwner(_from))
			return;

		var index = info.ButtonID - 1;

		if (index < 0)
			return;

		var type = index % 6;
		index /= 6;

		switch (type)
		{
			case 0:
			{
				if (index == 0)
					_roomAttendant.Dismiss();

				break;
			}
			case 1:
			{
				_roomAttendant.BeginChangeRumor(_from, index);
				break;
			}
			case 2:
			{
				_roomAttendant.RemoveRumor(_from, index);
				break;
			}
			case 3:
			{
				_roomAttendant.BeginChangeTip(_from);
				break;
			}
			case 4:
			{
				_roomAttendant.RemoveTip(_from);
				break;
			}
			case 5:
			{
				switch (index)
				{
					case 1: _roomAttendant.BeginChangeAppearance(_from); break;
					case 2: _roomAttendant.ChangeGender(_from); break;
				}

				break;
			}
		}
	}
}

public class RoomAFunctions
{
	public static bool Room(Mobile from, object squi, bool restricted)
	{
		Squire s = (Squire)squi;

		var carrierPigeon = new CarrierPigeon(s);

		if (from != null)
		{
			from.SendMessage("Your squire marches over to their inn room.");

			if (!from.AddToBackpack(carrierPigeon))
			{
				carrierPigeon.MoveToWorld(new Point3D(from.X, from.Y, from.Z), from.Map);
				from.SendMessage("The carrier pigeon falls to the ground, as your backpack is too full.");
			}
		}
		else
		{
			carrierPigeon.MoveToWorld(new Point3D(s.X, s.Y, s.Z), s.Map);
		}

		s.Controlled = true;

		GoToRoom(s);

		return true;
	}

	public static bool Room(Mobile from, object squi) => Room(from, squi, true);

	public static bool Room(object squi) => Room(null, squi, false);

	private static void GoToRoom(Squire squire)
	{
		squire.SetControlMaster(null);
		squire.SummonMaster = null;
		squire.Internalize();
		squire.Controlled = true;
	}
}
