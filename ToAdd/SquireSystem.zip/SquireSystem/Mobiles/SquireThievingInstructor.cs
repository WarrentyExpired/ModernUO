using System.Collections.Generic;
using ModernUO.Serialization;
using Server;
namespace Server.Mobiles;

[SerializationGenerator(0, false)]
public partial class SquireThievingInstructor : BaseVendor
{
	private readonly List<SBInfo> _sBInfos = [];
	protected override List<SBInfo> SBInfos => _sBInfos;

	[Constructible]
	public SquireThievingInstructor() : base("the squire thieving instructor")
	{
		SetSkill(SkillName.Camping, 55.0, 78.0);
		SetSkill(SkillName.DetectHidden, 65.0, 88.0);
		SetSkill(SkillName.Hiding, 45.0, 68.0);
		SetSkill(SkillName.Archery, 65.0, 88.0);
		SetSkill(SkillName.Tracking, 65.0, 88.0);
		SetSkill(SkillName.Veterinary, 60.0, 83.0);
	}

	public override void InitSBInfo()
	{
		_sBInfos.Add(new SBSquireThievingInstructor());
	}
	
	public override void InitOutfit()
	{
		base.InitOutfit();
		AddItem(new Server.Items.Shirt(Utility.RandomNeutralHue()));
		AddItem(new Server.Items.LongPants(Utility.RandomNeutralHue()));
		AddItem(new Server.Items.Dagger());
		AddItem(new Server.Items.ThighBoots(Utility.RandomNeutralHue()));
	}
}
