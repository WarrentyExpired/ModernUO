using System.Collections.Generic;
using ModernUO.Serialization;
using Server;
namespace Server.Mobiles;

[SerializationGenerator(0, false)]
public partial class SquireBardingInstructor : BaseVendor
{
	private readonly List<SBInfo> _sBInfos = [];
	protected override List<SBInfo> SBInfos => _sBInfos;

	public override NpcGuild NpcGuild => NpcGuild.BardsGuild;

	[Constructible]
	public SquireBardingInstructor() : base("the squire barding instructor")
	{
		SetSkill(SkillName.Discordance, 64.0, 100.0);
		SetSkill(SkillName.Musicianship, 64.0, 100.0);
		SetSkill(SkillName.Peacemaking, 65.0, 88.0);
		SetSkill(SkillName.Provocation, 60.0, 83.0);
		SetSkill(SkillName.Archery, 36.0, 68.0);
		SetSkill(SkillName.Swords, 36.0, 68.0);
	}

	public override void InitSBInfo()
	{
		_sBInfos.Add(new SBSquireBardingInstructor());
	}
	
}
