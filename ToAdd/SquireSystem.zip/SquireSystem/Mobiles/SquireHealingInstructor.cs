using System.Collections.Generic;
using ModernUO.Serialization;
using Server;
namespace Server.Mobiles;

[SerializationGenerator(0, false)]
public partial class SquireHealingInstructor : BaseVendor
{
	private readonly List<SBInfo> _sBInfos = [];
	protected override List<SBInfo> SBInfos => _sBInfos;

	public override NpcGuild NpcGuild => NpcGuild.MagesGuild;

	[Constructible]
	public SquireHealingInstructor() : base("the squire healing instructor")
	{
		SetSkill(SkillName.EvalInt, 65.0, 88.0);
		SetSkill(SkillName.Inscribe, 60.0, 83.0);
		SetSkill(SkillName.Healing, 60.0, 83.0);
		SetSkill(SkillName.Veterinary, 60.0, 83.0);
		SetSkill(SkillName.Magery, 64.0, 100.0);
		SetSkill(SkillName.Meditation, 60.0, 83.0);
		SetSkill(SkillName.MagicResist, 65.0, 88.0);
		SetSkill(SkillName.Wrestling, 36.0, 68.0);
	}

	public override void InitSBInfo()
	{
		_sBInfos.Add(new SBSquireHealingInstructor());
	}
	
	public override VendorShoeType ShoeType => Utility.RandomBool() ? VendorShoeType.Shoes : VendorShoeType.Sandals;

	public override void InitOutfit()
	{
		base.InitOutfit();
		AddItem(new Server.Items.Robe(Utility.RandomBlueHue()));
	}
}
