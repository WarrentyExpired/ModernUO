using System.Collections.Generic;
using ModernUO.Serialization;
using Server;
using Server.Items;
namespace Server.Mobiles;

[SerializationGenerator(0, false)]
public partial class SquireRepresentative : BaseVendor
{
	private readonly List<SBInfo> _sBInfos = [];
	protected override List<SBInfo> SBInfos => _sBInfos;

	[Constructible]
	public SquireRepresentative() : base("the squire representative")
	{
		SetSkill(SkillName.Swords, 65.0, 88.0);
		SetSkill(SkillName.Healing, 65.0, 88.0);
	}

	public override void InitSBInfo()
	{
		_sBInfos.Add(new SBSquireRepresentative());
	}
	
	public override VendorShoeType ShoeType => Female ? VendorShoeType.ThighBoots : VendorShoeType.Boots;

	public override int GetShoeHue() => 0;

	public override void InitOutfit()
	{
		base.InitOutfit();
		AddItem(Utility.RandomBool() ? (Item)new Longsword() : new VikingSword());
	}
}
