using System;
using Server.Collections;
using ModernUO.Serialization;
using Server;
using Server.Items;
using Server.Mobiles;
using Server.Network;
using Server.Gumps;
using Server.Misc;
using System.Collections.Generic;
using Server.Targeting;
using Server.Prompts;
using Server.ContextMenus;

namespace Server.Mobiles;

[SerializationGenerator(0, false)]
public partial class SS_InnKeeper : BaseVendor
{
	private readonly List<SBInfo> _sBInfos = [];
	protected override List<SBInfo> SBInfos => _sBInfos;

	private static readonly Dictionary<string, int> _keywords = new(StringComparer.OrdinalIgnoreCase)
	{
		[" "] = 0,
		["room"] = 1,
		["help"] = 2
	};

	[Constructible]
	public SS_InnKeeper() : base("the innkeeper")
	{
	}

	public override void InitSBInfo()
	{
		_sBInfos.Add(new SBSS_InnKeeper());
	}

	public override VendorShoeType ShoeType => Utility.RandomBool() ? VendorShoeType.Sandals : VendorShoeType.Shoes;

	public override bool HandlesOnSpeech(Mobile from) => InRange(from, 7) || base.HandlesOnSpeech(from);

	public override void OnSpeech(SpeechEventArgs e)
	{
		var from = e.Mobile;
		var bank = from.FindBankNoCreate();

		var command = -1;

		if (MatchPrefix(e.Speech, "vendor"))
			_keywords.TryGetValue(e.Speech[7..], out command);
		else if (Name != null && MatchPrefix(e.Speech, Name))
			_keywords.TryGetValue(e.Speech[(Name.Length + 1)..], out command);
		else if (MatchPrefix(e.Speech, "keeper"))
			_keywords.TryGetValue(e.Speech[7..], out command);
		else if (MatchPrefix(e.Speech, "innkeeper"))
			_keywords.TryGetValue(e.Speech[10..], out command);

		switch (command)
		{
			case 1:
			{
				if ((from.Backpack == null || from.Backpack.GetAmount(typeof(Gold)) < 300) && (bank == null || Banker.GetBalance(from) < 300))
				{
					SayTo(from, "Thou dost not have enough gold, not even in thy bank account.");
				}
				else
				{
					SayTo(from, "I will board your squire for now, this three hundred will cover their initial room fees.");
					SayTo(from, "Should they stay here an extended period of time, they will work to pay for themselves.");

					from.Target = new RoomTarget(this);
				}

				break;
			}
			case 2:
			{
				SayTo(from, "For a fee I can rent a room to your squire, they will work if additional fees occur, and I will hand you a Carrier Pigeon to call them back.");
				break;
			}
			default:
			{
				base.OnSpeech(e);
				break;
			}
		}
	}

	private static bool MatchPrefix(string speech, string prefix) =>
		speech.Length > prefix.Length && speech.StartsWith(prefix + ' ', StringComparison.OrdinalIgnoreCase);

	private class RoomTarget : Target
	{
		private readonly SS_InnKeeper _innKeeper;

		public RoomTarget(SS_InnKeeper innKeeper) : base(12, false, TargetFlags.None)
		{
			_innKeeper = innKeeper;
		}

		protected override void OnTarget(Mobile from, object s)
		{
			if (s == from)
			{
				_innKeeper.Say("Haha! Sorry! I thought we were rooming someone else... You may sleep here for free.");
			}
			else if (s is PlayerMobile)
			{
				_innKeeper.Say("Haha! Sorry! I think the sir or madam may speak for themselves.");
			}
			else if (s is not Squire)
			{
				_innKeeper.Say("That... Doesn't look like a squire to me.");
			}
			else
			{
				var squi = (BaseCreature)s;

				if (squi.Combatant != null && squi.InRange(squi.Combatant, 12) && squi.Map == squi.Combatant.Map)
				{
					_innKeeper.Say("Your squire seems to be distracted...");
				}
				else if (!(squi.Controlled && squi.ControlMaster == from))
				{
					_innKeeper.Say("That is not your squire to room.");
				}
				else if (squi.Mounted)
				{
					_innKeeper.Say("This is not a stable, please have your squire dismount before I rent them a room.");
				}
				else if (squi.Summoned)
				{
					_innKeeper.Say("How did you summon a squire with magic?");
				}
				else if (!squi.Alive)
				{
					_innKeeper.Say("I do not provide rooms for ghosts.");
				}
				else if (squi is Squire && squi.Controlled && from == squi.ControlMaster && from.Backpack != null && from.Backpack.ConsumeTotal(typeof(Gold), 300) || Banker.Withdraw(from, 300))
				{
					RoomFunctions.Room(from, squi, true);
				}
				else
				{
					_innKeeper.Say("I will not room... That.");
				}
			}
		}
	}

	private class RoomEntry : ContextMenuEntry
	{
		private readonly SS_InnKeeper _keeper;
		private readonly Mobile _from;

		public RoomEntry(SS_InnKeeper keeper, Mobile from) : base(560, 12)
		{
			_keeper = keeper;
			_from = from;
		}

		public override void OnClick(Mobile from, IEntity target)
		{
			_from.Target = new RoomTarget(_keeper);
		}
	}

	public override void AddCustomContextEntries(Mobile from, ref PooledRefList<ContextMenuEntry> list)
	{
		if (from.Alive)
		{
			list.Add(new RoomEntry(this, from));
		}

		base.AddCustomContextEntries(from, ref list);
	}
}

public class RoomFunctions
{
	public static bool Room(Mobile from, object squi, bool restricted)
	{
		Squire s = (Squire)squi;

		var carrierPigeon = new CarrierPigeon(s);

		if (from != null)
		{
			from.SendMessage("Your squire marches over to their inn room.");

			if (!from.AddToBackpack(carrierPigeon))
			{
				carrierPigeon.MoveToWorld(new Point3D(from.X, from.Y, from.Z), from.Map);
				from.SendMessage("The carrier pigeon falls to the ground, as your backpack is too full.");
			}
		}
		else
		{
			carrierPigeon.MoveToWorld(new Point3D(s.X, s.Y, s.Z), s.Map);
		}

		s.Controlled = true;

		GoToRoom(s);

		return true;
	}

	public static bool Room(Mobile from, object squi) => Room(from, squi, true);

	public static bool Room(object squi) => Room(null, squi, false);

	private static void GoToRoom(Squire squire)
	{
		squire.SetControlMaster(null);
		squire.SummonMaster = null;
		squire.Internalize();
		squire.Controlled = true;
	}
}
