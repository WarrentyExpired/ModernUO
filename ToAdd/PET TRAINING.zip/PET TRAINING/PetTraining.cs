// UO Wildlands Custom Script — ModernUO
// Consolidated pet training: data, profiles, helper, stubs, and gates.
// Licensed under GPL-3.0.

using ModernUO.Serialization;
using Server;
using Server.Commands;
using Server.Gumps;
using Server.Items;
using Server.Mobiles;
using Server.SkillHandlers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Server.Mobiles
{
    // ==========================================================================================
    // ENUMS
    // ==========================================================================================

    [Flags]
    public enum PetStat
    {
        Str, Dex, Int, Hits, Stam, Mana, RegenHits, RegenStam, RegenMana, BaseDamage
    }

    [Flags]
    public enum Class
    {
        None = 0x00000000,
        Untrainable = 0x00000001,
        Magical = 0x00000002,
        Necromantic = 0x00000004,
        Tokuno = 0x00000008,
        StickySkin = 0x00000010,
        Clawed = 0x00000020,
        Tailed = 0x00000040,
        Insectoid = 0x00000080,
        Restricted = 0x00000100,
        MagicalAndNecromantic = Magical | Necromantic,
        MagicalAndClawed = Magical | Clawed,
        MagicalAndTailed = Magical | Tailed,
        ClawedAndTailed = Clawed | Tailed,
        MagicalAndInsectoid = Magical | Insectoid,
        StickySkinAndTailed = StickySkin | Tailed,
        TailedAndNecromantic = Tailed | Necromantic,
        ClawedNecromanticAndTokuno = Clawed | Necromantic | Tokuno,
        MagicalClawedAndTailed = MagicalAndClawed | Tailed,
        MagicalNecromanticAndTokuno = MagicalAndNecromantic | Tokuno,
        ClawedTailedAndTokuno = ClawedAndTailed | Tokuno,
        ClawedTailedAndNecromantic = ClawedAndTailed | Necromantic,
        MagicalClawedTailedAndNecromantic = MagicalClawedAndTailed | Necromantic,
        ClawedTailedNecromanticAndTokuno = ClawedNecromanticAndTokuno | Tailed,
        ClawedTailedMagicalAndTokuno = MagicalClawedAndTailed | Tokuno,
        MagicalClawedTailedNecromanticAndTokuno = MagicalClawedTailedAndNecromantic | Tokuno,
    }

    [Flags]
    public enum MagicalAbility
    {
        None = 0x00000000,
        Piercing = 0x00000001, Bashing = 0x00000002, Slashing = 0x00000004,
        BattleDefense = 0x00000008, WrestlingMastery = 0x00000010,
        Poisoning = 0x00000020, Bushido = 0x00000040, Ninjitsu = 0x00000080,
        Discordance = 0x00000100, MageryMastery = 0x00000200, Mysticism = 0x00000400,
        Spellweaving = 0x00000800, Chivalry = 0x00001000, Necromage = 0x00002000,
        Necromancy = 0x00004000, Magery = 0x00008000,
        Tokuno = Bushido | Ninjitsu,
    }

    public enum TrainingMode { Regular, Planning }

    // ==========================================================================================
    // BASECREATURE PARTIAL
    // ==========================================================================================

    public abstract partial class BaseCreature
    {
        public const double MaxTameRequirement = 120.0;

        [CommandProperty(AccessLevel.GameMaster)] public int ControlSlotsMin { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public int ControlSlotsMax { get; set; } = 5;
        [CommandProperty(AccessLevel.GameMaster)] public double CurrentTameSkill { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public SkillName Mastery { get; set; }

        public double BardingDifficulty => Server.Items.BaseInstrument.GetBaseDifficulty(this);

        public TrainingProfile TrainingProfile { get; set; }
        public AbilityProfile AbilityProfile { get; set; }
        public TrainingDefinition TrainingDefinition { get; set; }

        public virtual void OnAfterTame(Mobile tamer)
        {
            CurrentTameSkill = MinTameSkill;
        }
    }

    // ==========================================================================================
    // TRAINING POINT / DEFINITION
    // ==========================================================================================

    public class TrainingPoint
    {
        public object TrainPoint { get; set; }
        public double Weight { get; set; }
        public int Start { get; set; }
        public int Max { get; set; }
        public TextDefinition Name { get; set; }
        public TextDefinition Description { get; set; }
        public TrainingPointRequirement[] Requirements { get; set; }

        public TrainingPoint(object trainpoint, double weight, int start, int max,
            TextDefinition name, TextDefinition description, params TrainingPointRequirement[] requirements)
        {
            TrainPoint = trainpoint;
            Weight = weight;
            Start = start;
            Max = max;
            Name = name;
            Description = description;
            Requirements = requirements;
        }

        public int GetMax(BaseCreature bc) =>
            TrainPoint is PetStat s && s == PetStat.BaseDamage
                ? PetTrainingHelper.GetMaxDamagePerSecond(bc)
                : Max;
    }

    public class TrainingPointRequirement
    {
        public object Requirement { get; set; }
        public int Cost { get; set; }
        public TextDefinition Name { get; set; }

        public TrainingPointRequirement(object requirement, int cost, TextDefinition name)
        {
            Requirement = requirement;
            Cost = cost;
            Name = name;
        }
    }

    public class TrainingDefinition
    {
        public Type CreatureType { get; private set; }
        public Class Class { get; private set; }
        public int ControlSlotsMin { get; private set; }
        public int ControlSlotsMax { get; private set; }

        // Kept for the gump's ability-page plumbing. Always empty in this build.
        public MagicalAbility MagicalAbilities { get; private set; }
        public SpecialAbility[] SpecialAbilities { get; private set; } = Array.Empty<SpecialAbility>();
        public WeaponAbility[] WeaponAbilities { get; private set; } = Array.Empty<WeaponAbility>();
        public AreaEffect[] AreaEffects { get; private set; } = Array.Empty<AreaEffect>();

        public TrainingDefinition(Type type, Class classification, int controlmin, int controlmax)
        {
            CreatureType = type;
            Class = classification;
            ControlSlotsMin = controlmin;
            ControlSlotsMax = controlmax;
        }

        public bool HasSpecialAbility(SpecialAbility ability) =>
            SpecialAbilities != null && Array.IndexOf(SpecialAbilities, ability) >= 0;

        public bool HasAreaEffect(AreaEffect ability) =>
            AreaEffects != null && Array.IndexOf(AreaEffects, ability) >= 0;
    }

    // ==========================================================================================
    // PROFILES
    // ==========================================================================================

    public class TrainingProfile
    {
        [CommandProperty(AccessLevel.GameMaster)] public TrainingMode TrainingMode { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public bool HasBegunTraining { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public bool HasIncreasedControlSlot { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public int TrainedThisLevel { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public bool HasRecievedControlSlotWarning { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public double TrainingProgress { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public double TrainingProgressMax { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public BaseCreature Creature { get; private set; }

        [CommandProperty(AccessLevel.GameMaster)]
        public double TrainingProgressPercentile => TrainingProgressMax <= 0 ? 0 : TrainingProgress / TrainingProgressMax;

        [CommandProperty(AccessLevel.GameMaster)] public int ControlSlots => Creature.ControlSlots;
        [CommandProperty(AccessLevel.GameMaster)] public int ControlSlotsMin => Creature.ControlSlotsMin;
        [CommandProperty(AccessLevel.GameMaster)] public int ControlSlotsMax => Creature.ControlSlotsMax;

        [CommandProperty(AccessLevel.GameMaster)]
        public bool CanApplyOptions => HasBegunTraining && TrainingProgressPercentile >= 1.0;

        private int _trainingPoints;
        private int _startingTrainingPoints;
        private PlanningProfile _plan;

        [CommandProperty(AccessLevel.GameMaster)]
        public int TrainingPoints
        {
            get => _trainingPoints;
            set { if (value <= 0) EndTraining(); else _trainingPoints = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public int StartingTrainingPoints
        {
            get => _startingTrainingPoints;
            set => _startingTrainingPoints = value;
        }

        public PlanningProfile PlanningProfile => _plan ??= new PlanningProfile(Creature);

        public static TimeSpan PowerHourDuration = TimeSpan.FromHours(1);
        public static TimeSpan PowerHourDelay = TimeSpan.FromHours(24);

        [CommandProperty(AccessLevel.GameMaster)] public DateTime PowerHourBegin { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public bool InPowerHour { get; set; }
        public int PowerHourMultiplier => InPowerHour ? 2 : 1;

        private const int MaxTrainingProgress = 100;
        private readonly Dictionary<BaseCreature, int> _progressTable = new();

        public TrainingProfile(BaseCreature bc) => Creature = bc;

        private int AssignStartingTrainingPoints()
        {
            if (ControlSlots != ControlSlotsMin) return 1501;
            if (ControlSlotsMin == 1 && ControlSlotsMax == 2) return 2556;
            if (ControlSlotsMin == 1 && ControlSlotsMax == 3) return 2381;
            return 1501;
        }

        public void BeginTraining()
        {
            if (ControlSlots >= ControlSlotsMax) return;
            TrainingPoints = AssignStartingTrainingPoints();
            HasBegunTraining = true;
            TrainingProgress = 0;
            TrainingProgressMax = MaxTrainingProgress;
        }

        public void OnTrain(PlayerMobile pm, int points)
        {
            int reqInc;
            if (!HasIncreasedControlSlot)
            {
                reqInc = GetRequirementIncrease(true);
                Creature.RemoveFollowers();
                Creature.ControlSlots++;
                Creature.AddFollowers();
                TrainedThisLevel = 0;
                pm.SendLocalizedMessage(1157537);
                HasIncreasedControlSlot = true;
            }
            else
            {
                TrainedThisLevel++;
                reqInc = GetRequirementIncrease(false);
            }
            Creature.CurrentTameSkill = Math.Min(BaseCreature.MaxTameRequirement, Creature.CurrentTameSkill + reqInc);
            TrainingPoints -= points;
        }

        public int GetRequirementIncrease(bool slotIncreased)
        {
            if (slotIncreased) return ControlSlotsMin + 1 == ControlSlots ? 21 : 22;
            return TrainedThisLevel == 1 ? 3 : 2;
        }

        public void EndTraining()
        {
            HasBegunTraining = false;
            _trainingPoints = 0;
            HasRecievedControlSlotWarning = false;
            HasIncreasedControlSlot = false;
        }

        private bool CheckCanProgress(BaseCreature bc, double toGain)
        {
            if (_progressTable.TryGetValue(bc, out var val))
            {
                var gains = GetGainsPerCreature(toGain);
                if (val >= gains) return false;
                _progressTable[bc] = val + 1;
                return true;
            }
            _progressTable[bc] = 1;
            return true;
        }

        private int GetGainsPerCreature(double toGain)
        {
            int gains = ControlSlots switch
            {
                1 or 2 => int.MaxValue,
                3 => (int)(MaxTrainingProgress / toGain / 2.0),
                _ => (int)(MaxTrainingProgress / toGain / 4.0),
            };
            if (gains < int.MaxValue) gains *= PowerHourMultiplier;
            return gains;
        }

        public void CheckProgress(BaseCreature bc)
        {
            if (ControlSlots >= ControlSlotsMax || !HasBegunTraining ||
                TrainingProgress >= TrainingProgressMax || Creature.ControlMaster == null) return;

            var ourDif = Creature.BardingDifficulty;
            var theirDif = bc.BardingDifficulty;
            var master = Creature.ControlMaster;

            if (Utility.Random(100) < 8 - (1 + (ControlSlots - ControlSlotsMin)))
            {
                var toGain = GetAdvance(theirDif);
                if (ourDif - theirDif <= 50 && CheckCanProgress(bc, toGain))
                {
                    if (PowerHourBegin + PowerHourDelay < DateTime.UtcNow)
                    {
                        _progressTable.Clear();
                        PowerHourBegin = DateTime.UtcNow;
                        InPowerHour = true;
                        master.SendLocalizedMessage(1157569);
                    }
                    else if (InPowerHour && PowerHourBegin + PowerHourDuration < DateTime.UtcNow)
                    {
                        InPowerHour = false;
                        master.SendLocalizedMessage(1157570);
                    }

                    TrainingProgress = Math.Min(TrainingProgressMax, TrainingProgress + toGain);

                    if (!bc.Controlled && !bc.Summoned && master is PlayerMobile)
                    {
                        var cliloc = 1157574;
                        if (toGain < 1.3) cliloc = 1157565;
                        else if (toGain < 2.5) cliloc = 1157573;

                        if (TrainingProgress >= TrainingProgressMax)
                            Creature.PrivateOverheadMessage(MessageType.Regular, 0x59, 1157543, master.NetState);

                        Creature.PrivateOverheadMessage(MessageType.Regular, 0x59, cliloc, master.NetState);
                    }
                    else
                    {
                        Creature.PrivateOverheadMessage(MessageType.Regular, 0x21, 1157564, master.NetState);
                    }
                }
                else
                {
                    Creature.PrivateOverheadMessage(MessageType.Regular, 0x21, 1157564, master.NetState);
                }
            }
        }

        private static double GetAdvance(double difficulty)
        {
            var advance = difficulty / 64;
            return advance >= 2.5 ? 2.5 : advance;
        }

        public void ResendProgressGump(Mobile m) { }
        public override string ToString() => "...";

        public TrainingProfile(BaseCreature bc, IGenericReader reader)
        {
            var version = reader.ReadInt();
            switch (version)
            {
                case 2:
                    TrainedThisLevel = reader.ReadInt();
                    goto case 1;
                case 1:
                    PowerHourBegin = reader.ReadDateTime();
                    InPowerHour = reader.ReadBool();
                    break;
            }

            Creature = bc;
            if (reader.ReadInt() == 1) _plan = new PlanningProfile(bc, reader);

            TrainingMode = (TrainingMode)reader.ReadInt();
            HasBegunTraining = reader.ReadBool();
            HasIncreasedControlSlot = reader.ReadBool();
            HasRecievedControlSlotWarning = reader.ReadBool();
            TrainingProgress = reader.ReadDouble();
            TrainingProgressMax = reader.ReadDouble();
            _startingTrainingPoints = reader.ReadInt();
            _trainingPoints = reader.ReadInt();
        }

        public void Serialize(IGenericWriter writer)
        {
            writer.Write(2);
            writer.Write(TrainedThisLevel);
            writer.Write(PowerHourBegin);
            writer.Write(InPowerHour);
            if (_plan != null) { writer.Write(1); _plan.Serialize(writer); }
            else writer.Write(0);
            writer.Write((int)TrainingMode);
            writer.Write(HasBegunTraining);
            writer.Write(HasIncreasedControlSlot);
            writer.Write(HasRecievedControlSlotWarning);
            writer.Write(TrainingProgress);
            writer.Write(TrainingProgressMax);
            writer.Write(_startingTrainingPoints);
            writer.Write(_trainingPoints);
        }
    }

    public class PlanningProfile
    {
        public BaseCreature Creature { get; private set; }
        public List<PlanningEntry> Entries { get; private set; }

        public PlanningProfile(BaseCreature bc) { Creature = bc; Entries = new List<PlanningEntry>(); }
        public void Clear() => Entries.Clear();

        public void AddToPlan(object tp, int value, int cost)
        {
            var entry = Entries.FirstOrDefault(e => e.TrainPoint == tp);
            if (entry != null) Entries.Remove(entry);
            Entries.Add(new PlanningEntry(tp, value, cost));
        }

        public class PlanningEntry
        {
            public object TrainPoint { get; private set; }
            public int Value { get; set; }
            public int Cost { get; set; }
            public PlanningEntry(object tp, int value, int cost)
            {
                TrainPoint = tp; Value = value; Cost = cost;
            }
        }

        public PlanningProfile(BaseCreature bc, IGenericReader reader)
        {
            reader.ReadInt();
            Entries = new List<PlanningEntry>();
            var count = reader.ReadInt();
            for (var i = 0; i < count; i++)
            {
                switch (reader.ReadInt())
                {
                    case 0: break;
                    case 1: Entries.Add(new PlanningEntry((MagicalAbility)reader.ReadInt(), reader.ReadInt(), reader.ReadInt())); break;
                    case 5: Entries.Add(new PlanningEntry((PetStat)reader.ReadInt(), reader.ReadInt(), reader.ReadInt())); break;
                    case 6: Entries.Add(new PlanningEntry((ResistanceType)reader.ReadInt(), reader.ReadInt(), reader.ReadInt())); break;
                    case 7: Entries.Add(new PlanningEntry((SkillName)reader.ReadInt(), reader.ReadInt(), reader.ReadInt())); break;
                    // Ability types (2,3,4) drained silently
                    case 2: case 3: case 4: reader.ReadInt(); reader.ReadInt(); reader.ReadInt(); break;
                }
            }
        }

        public void Serialize(IGenericWriter writer)
        {
            writer.Write(0);
            writer.Write(Entries.Count);
            for (var i = 0; i < Entries.Count; i++)
            {
                var entry = Entries[i];
                var o = entry.TrainPoint;
                if (o is MagicalAbility ma) { writer.Write(1); writer.Write((int)ma); }
                else if (o is PetStat ps) { writer.Write(5); writer.Write((int)ps); }
                else if (o is ResistanceType rt) { writer.Write(6); writer.Write((int)rt); }
                else if (o is SkillName sn) { writer.Write(7); writer.Write((int)sn); }
                else { writer.Write(0); continue; }
                writer.Write(entry.Value);
                writer.Write(entry.Cost);
            }
        }
    }

    public class AbilityProfile
    {
        [CommandProperty(AccessLevel.GameMaster)] public bool TokunoTame { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public int RegenHits { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public int RegenStam { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public int RegenMana { get; set; }
        [CommandProperty(AccessLevel.GameMaster)] public int DamageIndex { get; set; } = -1;
        [CommandProperty(AccessLevel.GameMaster)] public BaseCreature Creature { get; private set; }

        public MagicalAbility MagicalAbility { get; set; }
        public SpecialAbility[] SpecialAbilities { get; set; } = Array.Empty<SpecialAbility>();
        public WeaponAbility[] WeaponAbilities { get; set; } = Array.Empty<WeaponAbility>();
        public AreaEffect[] AreaEffects { get; set; } = Array.Empty<AreaEffect>();

        public AbilityProfile(BaseCreature bc) => Creature = bc;

        public void OnTame() { if (Creature.Map == Map.Tokuno) TokunoTame = true; }

        public override string ToString() => "...";

        public AbilityProfile(BaseCreature bc, IGenericReader reader)
        {
            var version = reader.ReadInt();
            Creature = bc;
            DamageIndex = version >= 1 ? reader.ReadInt() : -1;

            reader.ReadInt();     // legacy MagicalAbility
            TokunoTame = reader.ReadBool();
            RegenHits = reader.ReadInt();
            RegenStam = reader.ReadInt();
            RegenMana = reader.ReadInt();

            // Drain legacy ability arrays
            var count = reader.ReadInt();
            for (var i = 0; i < count; i++) reader.ReadInt();
            count = reader.ReadInt();
            for (var i = 0; i < count; i++) reader.ReadInt();
            count = reader.ReadInt();
            for (var i = 0; i < count; i++) reader.ReadInt();

            count = reader.ReadInt();
            for (var i = 0; i < count; i++)
            {
                switch (reader.ReadInt())
                {
                    case 1: case 2: case 3: case 4: case 5: reader.ReadInt(); break;
                }
            }
        }

        public void Serialize(IGenericWriter writer)
        {
            writer.Write(1);
            writer.Write(DamageIndex);
            writer.Write(0); // legacy MagicalAbility
            writer.Write(TokunoTame);
            writer.Write(RegenHits);
            writer.Write(RegenStam);
            writer.Write(RegenMana);
            writer.Write(0);
            writer.Write(0);
            writer.Write(0);
            writer.Write(0);
        }

        // Gump plumbing — ability queries always return false in this build.
        public bool HasAbility(object o) => false;
        public bool CanChooseMagicalAbility(MagicalAbility ability) => false;
        public bool CanChooseSpecialAbility(SpecialAbility[] list) => false;
        public bool CanChooseWeaponAbility() => false;
        public bool CanChooseAreaEffect() => false;
        public bool HasSpecialMagicalAbility() => false;
        public bool IsRuleBreaker(SpecialAbility ability) => false;
    }


    // ==========================================================================================
    // ABILITY STUBS (kept so the gump's ability-page plumbing still resolves)
    // ==========================================================================================

    public abstract class SpecialAbility
    {
        public static SpecialAbility[] Abilities => Array.Empty<SpecialAbility>();
        public static SpecialAbility VenomousBite => null;
    }

    public abstract class AreaEffect
    {
        public static AreaEffect[] Effects => Array.Empty<AreaEffect>();
        public static AreaEffect PoisonBreath => null;
    }

    // Concrete subclasses referenced by PetTrainingGumps.cs's ability filters.
    // Never instantiated in this build (the arrays above are empty), but the
    // `is` checks need the types to exist.
    public class VenomousBite : SpecialAbility { }
    public class PoisonBreath : AreaEffect { }

    // ==========================================================================================
    // PET TRAINING HELPER
    // ==========================================================================================

    public static class PetTrainingHelper
    {
        public static bool Enabled => Core.TOL;

        public static List<TrainingPoint> TrainingPoints => _TrainingPoints;
        public static List<TrainingPoint> _TrainingPoints;

        public static TrainingDefinition[] Definitions { get; private set; } = Array.Empty<TrainingDefinition>();
        public static MagicalAbility[] MagicalAbilities { get; } = Array.Empty<MagicalAbility>();
        public static SpecialAbility[] SpecialAbilityNone { get; } = Array.Empty<SpecialAbility>();
        public static AreaEffect[] AreaEffectNone { get; } = Array.Empty<AreaEffect>();

        public static SkillName[] MagicSkills =
        {
            SkillName.Magery, SkillName.EvalInt, SkillName.Necromancy, SkillName.SpiritSpeak,
            SkillName.Chivalry, SkillName.Focus, SkillName.Bushido, SkillName.Ninjitsu,
            SkillName.Spellweaving, SkillName.Mysticism, SkillName.Meditation,
            SkillName.MagicResist, SkillName.Discordance
        };

        public static SkillName[] CombatSkills =
        {
            SkillName.Wrestling, SkillName.Tactics, SkillName.Anatomy,
            SkillName.Parry, SkillName.Healing
        };

        #region Accessors

        public static TrainingDefinition GetTrainingDefinition(BaseCreature bc)
        {
            if (bc == null) return null;

            var def = bc.TrainingDefinition;
            if (def != null) return def;

            if (bc.Tamable)
            {
                var min = bc.ControlSlotsMin == 0 ? bc.ControlSlots : bc.ControlSlotsMin;
                var max = bc.ControlSlotsMax == 0 ? bc.ControlSlots : bc.ControlSlotsMax;
                def = new TrainingDefinition(bc.GetType(), Class.None, min, max);
            }
            return def;
        }

        public static TrainingPoint GetTrainingPoint(object o)
        {
            if (_TrainingPoints == null) return null;
            foreach (var tp in _TrainingPoints)
            {
                if (tp.TrainPoint is PetStat && o is PetStat ps && ps == (PetStat)tp.TrainPoint) return tp;
                if (tp.TrainPoint is ResistanceType && o is ResistanceType rt && rt == (ResistanceType)tp.TrainPoint) return tp;
                if (tp.TrainPoint is SkillName && o is SkillName sn && sn == (SkillName)tp.TrainPoint) return tp;
            }
            return null;
        }

        public static AbilityProfile GetAbilityProfile(BaseCreature bc, bool create = false)
        {
            var profile = bc.AbilityProfile;
            if (profile == null && create) bc.AbilityProfile = profile = new AbilityProfile(bc);
            return profile;
        }

        public static TrainingProfile GetTrainingProfile(BaseCreature bc, bool create = false)
        {
            var profile = bc.TrainingProfile;
            if (profile == null && create) bc.TrainingProfile = profile = new TrainingProfile(bc);
            return profile;
        }

        public static PlanningProfile GetPlanningProfile(BaseCreature bc, bool create = false)
            => GetTrainingProfile(bc, create)?.PlanningProfile;

        #endregion

        #region Configure

        public static void Configure()
        {
            if (_TrainingPoints != null) return;
            _TrainingPoints = new List<TrainingPoint>();

            // Stats
            _TrainingPoints.Add(new TrainingPoint(PetStat.Str, 3.0, 1, 700, 1061146, 1157507));
            _TrainingPoints.Add(new TrainingPoint(PetStat.Dex, 0.1, 1, 150, 1061147, 1157508));
            _TrainingPoints.Add(new TrainingPoint(PetStat.Int, 0.5, 1, 700, 1061148, 1157509));
            _TrainingPoints.Add(new TrainingPoint(PetStat.Hits, 3.0, 1, 1100, 1061149, 1157510));
            _TrainingPoints.Add(new TrainingPoint(PetStat.Stam, 0.5, 1, 150, 1061150, 1157511));
            _TrainingPoints.Add(new TrainingPoint(PetStat.Mana, 0.5, 1, 1500, 1061151, 1157512));
            _TrainingPoints.Add(new TrainingPoint(PetStat.RegenHits, 18.0, 1, 20, 1075627, 1157513));
            _TrainingPoints.Add(new TrainingPoint(PetStat.RegenStam, 12.0, 1, 30, 1079411, 1157514));
            _TrainingPoints.Add(new TrainingPoint(PetStat.RegenMana, 12.0, 1, 30, 1079410, 1157515));
            _TrainingPoints.Add(new TrainingPoint(PetStat.BaseDamage, 5.0, 1, 22, 1157506, 1157516));

            // Resistances
            _TrainingPoints.Add(new TrainingPoint(ResistanceType.Physical, 3.0, 1, 80, 1061158, 1157517));
            _TrainingPoints.Add(new TrainingPoint(ResistanceType.Fire, 3.0, 1, 80, 1061159, 1157518));
            _TrainingPoints.Add(new TrainingPoint(ResistanceType.Cold, 3.0, 1, 80, 1061160, 1157519));
            _TrainingPoints.Add(new TrainingPoint(ResistanceType.Poison, 3.0, 1, 80, 1061161, 1157520));
            _TrainingPoints.Add(new TrainingPoint(ResistanceType.Energy, 3.0, 1, 80, 1061162, 1157521));

            // Magic skill caps
            _TrainingPoints.Add(new TrainingPoint(SkillName.Magery, 0.5, 50, 200, 1002106, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.EvalInt, 1.0, 50, 200, 1044076, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.Necromancy, 0.5, 50, 200, 1044109, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.SpiritSpeak, 1.0, 50, 200, 1044092, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.Chivalry, 0.5, 50, 200, 1044111, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.Focus, 0.1, 50, 200, 1044110, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.Bushido, 0.5, 50, 200, 1044112, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.Ninjitsu, 0.5, 50, 200, 1044113, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.Spellweaving, 0.5, 50, 200, 1044114, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.Mysticism, 0.5, 50, 200, 1044115, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.Meditation, 0.1, 50, 200, 1044106, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.MagicResist, 0.1, 50, 200, 1044086, 1157522));

            // Combat skill caps
            _TrainingPoints.Add(new TrainingPoint(SkillName.Wrestling, 1.0, 50, 200, 1044103, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.Tactics, 1.0, 50, 200, 1044087, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.Anatomy, 0.1, 50, 200, 1044061, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.Parry, 0.1, 50, 200, 1002118, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.Healing, 0.1, 50, 200, 1002082, 1157522));
            _TrainingPoints.Add(new TrainingPoint(SkillName.Discordance, 0.1, 50, 200, 1044075, 1157522));
        }

        #endregion

        #region Helpers

        public static bool CanControl(Mobile m, BaseCreature bc, TrainingProfile trainProfile)
        {
            var projected = Math.Min(BaseCreature.MaxTameRequirement,
                bc.CurrentTameSkill + trainProfile.GetRequirementIncrease(!trainProfile.HasIncreasedControlSlot));
            return m.Skills[SkillName.AnimalTaming].Value >= projected;
        }

        public static int GetTrainingCapTotal(PetStat stat) => stat switch
        {
            PetStat.Str or PetStat.Int or PetStat.Dex => 2300,
            PetStat.Hits or PetStat.Stam or PetStat.Mana => 3300,
            _ => 0,
        };

        public static int GetTrainingCapTotal(ResistanceType resist) => 1095;

        public static int GetTotalStatWeight(BaseCreature bc)
        {
            var str = GetTrainingPoint(PetStat.Str);
            var dex = GetTrainingPoint(PetStat.Dex);
            var intel = GetTrainingPoint(PetStat.Int);
            return (int)(Math.Min(bc.RawStr * str.Weight, str.GetMax(bc) * str.Weight) +
                         Math.Min(bc.RawDex * dex.Weight, dex.GetMax(bc) * dex.Weight) +
                         Math.Min(bc.RawInt * intel.Weight, intel.GetMax(bc) * intel.Weight));
        }

        public static int GetTotalAttributeWeight(BaseCreature bc)
        {
            var hits = GetTrainingPoint(PetStat.Hits);
            var stam = GetTrainingPoint(PetStat.Stam);
            var mana = GetTrainingPoint(PetStat.Mana);
            return (int)(Math.Min(bc.HitsMax * hits.Weight, hits.GetMax(bc) * hits.Weight) +
                         Math.Min(bc.StamMax * stam.Weight, stam.GetMax(bc) * stam.Weight) +
                         Math.Min(bc.ManaMax * mana.Weight, mana.GetMax(bc) * mana.Weight));
        }

        public static int GetTotalResistWeight(BaseCreature bc)
        {
            var phys = GetTrainingPoint(ResistanceType.Physical);
            var fire = GetTrainingPoint(ResistanceType.Fire);
            var cold = GetTrainingPoint(ResistanceType.Cold);
            var pois = GetTrainingPoint(ResistanceType.Poison);
            var nrgy = GetTrainingPoint(ResistanceType.Energy);
            return (int)(bc.PhysicalResistanceSeed * phys.Weight +
                         bc.FireResistSeed * fire.Weight +
                         bc.ColdResistSeed * cold.Weight +
                         bc.PoisonResistSeed * pois.Weight +
                         bc.EnergyResistSeed * nrgy.Weight);
        }

        public static int GetMaxDamagePerSecond(BaseCreature bc)
        {
            var slots = bc.ControlSlots;
            var profile = GetTrainingProfile(bc);
            if (profile != null && !profile.HasIncreasedControlSlot) slots++;
            return slots switch { 2 => 8, 3 => 13, 4 => 17, _ => 22 };
        }

        private static readonly int[][] _DamageTable =
        {
            new[] { 0, 1 }, new[] { 2, 3 }, new[] { 3, 4 }, new[] { 4, 6 }, new[] { 5, 7 },
            new[] { 6, 9 }, new[] { 7, 10 }, new[] { 9, 12 }, new[] { 9, 13 }, new[] { 11, 15 },
            new[] { 12, 16 }, new[] { 13, 18 }, new[] { 14, 19 }, new[] { 15, 21 }, new[] { 16, 22 },
            new[] { 18, 24 }, new[] { 18, 25 }, new[] { 19, 26 }, new[] { 20, 28 }, new[] { 21, 29 },
            new[] { 23, 31 }, new[] { 24, 33 },
        };

        public static bool SetDamage(BaseCreature bc, int value)
        {
            if (value < 0 || value >= _DamageTable.Length) return false;
            bc.SetDamage(_DamageTable[value][0], _DamageTable[value][1]);
            GetAbilityProfile(bc, true).DamageIndex = value;
            return true;
        }

        public static void GetStartValue(TrainingPoint tp, BaseCreature bc, ref int value)
        {
            if (tp.Start == tp.Max) return;

            if (tp.TrainPoint is PetStat stat)
            {
                var profile = GetAbilityProfile(bc, true);
                switch (stat)
                {
                    case PetStat.Str: value = Math.Max(bc.RawStr, value); break;
                    case PetStat.Dex: value = Math.Max(bc.RawDex, value); break;
                    case PetStat.Int: value = Math.Max(bc.RawInt, value); break;
                    case PetStat.Hits: value = Math.Max(bc.HitsMax, value); break;
                    case PetStat.Stam: value = Math.Max(bc.StamMax, value); break;
                    case PetStat.Mana: value = Math.Max(bc.ManaMax, value); break;
                    case PetStat.RegenHits: value = Math.Max(profile.RegenHits, value); break;
                    case PetStat.RegenStam: value = Math.Max(profile.RegenStam, value); break;
                    case PetStat.RegenMana: value = Math.Max(profile.RegenMana, value); break;
                    case PetStat.BaseDamage:
                        if (profile.DamageIndex > -1) { value = profile.DamageIndex + 1; break; }
                        if (bc.DamageMin <= 1) { value = 1; break; }
                        for (var i = 0; i < _DamageTable.Length; i++)
                            if (_DamageTable[i][0] >= bc.DamageMin && bc.DamageMin <= _DamageTable[i][1])
                            { value = i + 1; return; }
                        value = _DamageTable.Length - 1;
                        break;
                }
            }
            else if (tp.TrainPoint is ResistanceType resist)
            {
                value = resist switch
                {
                    ResistanceType.Physical => Math.Max(bc.PhysicalResistanceSeed, value),
                    ResistanceType.Fire => Math.Max(bc.FireResistSeed, value),
                    ResistanceType.Cold => Math.Max(bc.ColdResistSeed, value),
                    ResistanceType.Poison => Math.Max(bc.PoisonResistSeed, value),
                    ResistanceType.Energy => Math.Max(bc.EnergyResistSeed, value),
                    _ => value,
                };
            }
            else if (tp.TrainPoint is SkillName)
            {
                var skill = bc.Skills[(SkillName)tp.TrainPoint];
                value = (int)skill.Cap switch
                {
                    < 105 => 0,
                    < 110 => 50,
                    < 115 => 100,
                    < 120 => 150,
                    _ => value,
                };
            }
        }

        public static int GetTotalCost(TrainingPoint tp, BaseCreature bc, int value, int startValue)
        {
            var cost = (int)(value * tp.Weight);
            if (startValue > 0) cost -= (int)(startValue * tp.Weight);
            return cost;
        }

        public static bool ApplyTrainingPoint(BaseCreature bc, TrainingPoint tp, int value)
        {
            var profile = GetAbilityProfile(bc, true);

            if (tp.TrainPoint is PetStat stat)
            {
                switch (stat)
                {
                    case PetStat.Str:
                        if (bc.HitsMaxSeed == -1) bc.HitsMaxSeed = bc.HitsMax;
                        bc.SetStr(value); break;
                    case PetStat.Dex:
                        if (bc.StamMaxSeed == -1) bc.StamMaxSeed = bc.StamMax;
                        bc.SetDex(value); break;
                    case PetStat.Int:
                        if (bc.ManaMaxSeed == -1) bc.ManaMaxSeed = bc.ManaMax;
                        bc.SetInt(value); break;
                    case PetStat.Hits: bc.SetHits(value); break;
                    case PetStat.Stam: bc.SetStam(value); break;
                    case PetStat.Mana: bc.SetMana(value); break;
                    case PetStat.RegenHits: profile.RegenHits = value; break;
                    case PetStat.RegenStam: profile.RegenStam = value; break;
                    case PetStat.RegenMana: profile.RegenMana = value; break;
                    case PetStat.BaseDamage: return SetDamage(bc, value - 1);
                }
                return true;
            }

            if (tp.TrainPoint is SkillName skill)
            {
                bc.Skills[skill].Cap = 100 + value / 10;
                return true;
            }

            if (tp.TrainPoint is ResistanceType resist)
            {
                switch (resist)
                {
                    case ResistanceType.Physical: bc.PhysicalResistanceSeed = value; break;
                    case ResistanceType.Fire: bc.FireResistSeed = value; break;
                    case ResistanceType.Cold: bc.ColdResistSeed = value; break;
                    case ResistanceType.Poison: bc.PoisonResistSeed = value; break;
                    case ResistanceType.Energy: bc.EnergyResistSeed = value; break;
                }
                return true;
            }

            return false;
        }

        public static bool ValidateTrainingPoint(BaseCreature bc, SkillName skill)
            => bc.Skills[skill].Base > 0;

        public static bool CheckSecondarySkill(BaseCreature bc, SkillName skill) => true;
        public static void OnWeaponAbilityUsed(BaseCreature bc, SkillName skill) { }

        public static bool CommonSkill(BaseCreature bc, SkillName skill)
        {
            if (bc.Skills[SkillName.Wrestling].Base >= 100 && skill == SkillName.Parry) return true;
            var ai = bc.AI;
            if (skill == SkillName.Meditation &&
                (ai == AIType.AI_Mage || ai == AIType.AI_NecroMage ||
                 ai == AIType.AI_Spellweaving || ai == AIType.AI_Mystic))
                return true;
            return skill == SkillName.Focus || skill == SkillName.Tactics ||
                   skill == SkillName.Anatomy || skill == SkillName.MagicResist ||
                   skill == SkillName.Wrestling;
        }

        #endregion

        #region Localization

        public static TextDefinition[] GetLocalization(object o) => Array.Empty<TextDefinition>();
        public static TextDefinition[] GetLocalization(MagicalAbility a) => Array.Empty<TextDefinition>();
        public static TextDefinition[] GetLocalization(SpecialAbility a) => Array.Empty<TextDefinition>();
        public static TextDefinition[] GetLocalization(AreaEffect a) => Array.Empty<TextDefinition>();

        public static TextDefinition[] GetLocalization(SkillName skill)
        {
            var tp = _TrainingPoints?.FirstOrDefault(t => t.TrainPoint is SkillName sn && sn == skill);
            return tp != null ? new[] { tp.Name, tp.Description } : Array.Empty<TextDefinition>();
        }

        public static int GetCategoryLocalization(object o) => o switch
        {
            PetStat => 1114262,
            ResistanceType => 1154539,
            SkillName => 1157495,
            _ => 0,
        };

        #endregion

        public static void Initialize()
        {
            CommandSystem.Register("PetTrainTest", AccessLevel.GameMaster, e =>
            {
                var m = e.Mobile;
                var arg = e.GetString(0);
                if (string.IsNullOrEmpty(arg)) { m.SendMessage("PetTrainTest <type>"); return; }

                var t = AssemblyHandler.FindTypeByName(arg);
                if (t == null || !t.IsSubclassOf(typeof(BaseCreature))) return;
                if (Activator.CreateInstance(t) is not BaseCreature bc) return;

                if (!bc.Tamable) { m.SendMessage("That cannot be tamed!"); bc.Delete(); return; }
                if (m.Followers + bc.ControlSlots > m.FollowersMax)
                { m.SendLocalizedMessage(1049611); bc.Delete(); return; }

                bc.MoveToWorld(m.Location, m.Map);

                if (bc is GreaterDragon)
                {
                    AnimalTaming.ScaleSkills(bc, 0.72, 0.72);
                    bc.Skills[SkillName.Magery].Base = bc.Skills[SkillName.Magery].Cap;
                }
                else AnimalTaming.ScaleSkills(bc, 0.90, 0.90);

                Timer.DelayCall(TimeSpan.FromSeconds(.25), () =>
                {
                    bc.PrivateOverheadMessage(MessageType.Regular, 0x3B2, 502799, m.NetState);
                    bc.Owners.Add(m);
                    bc.SetControlMaster(m);
                    bc.IsBonded = true;
                    bc.OnAfterTame(m);
                    GetAbilityProfile(bc, true).OnTame();
                });
            });
        }
    }
}
namespace Server.Items
{
    [SerializationGenerator(0, false)]
    public partial class PetTrainingGate : Item
    {
        public override bool ForceShowProperties => true;

        public override string DefaultName =>
            "Pet Training Gate - You Must Start Pet Training Before Bringing Your Pet Through The Gate!";

        [Constructible]
        public PetTrainingGate() : base(3948) { Hue = 1918; Movable = false; }

        public override bool OnMoveOver(Mobile m)
        {
            if (m is BaseCreature bc)
            {
                var profile = PetTrainingHelper.GetTrainingProfile(bc);
                if (bc.Controlled && bc.ControlMaster?.InRange(bc.Location, 25) == true
                    && profile != null && profile.HasBegunTraining
                    && profile.TrainingProgress < profile.TrainingProgressMax)
                {
                    profile.TrainingProgress = profile.TrainingProgressMax;
                    bc.FixedEffect(0x375A, 10, 30);

                    if (bc.ControlMaster is PlayerMobile pm)
                    {
                        bc.PublicOverheadMessage(MessageType.Regular, 0x59, false,
                            $"*{bc.Name} surges with battle experience and is ready to train!*");
                        pm.FindGump<Server.Mobiles.DashboardAnimalLoreGump>()?.Refresh();
                    }
                }
            }
            return true;
        }
    }

    [SerializationGenerator(0, false)]
    public partial class PetBondRemoveGate : Item
    {
        public override bool ForceShowProperties => true;
        public override string DefaultName => "Pet Bond Timer Remover";

        [Constructible]
        public PetBondRemoveGate() : base(3948) { Hue = 1911; Movable = false; }

        public override bool OnMoveOver(Mobile m)
        {
            if (m is BaseCreature bc && bc.Controlled
                && bc.ControlMaster?.InRange(bc.Location, 25) == true && !bc.IsBonded)
            {
                bc.IsBonded = true;
                bc.FixedEffect(0x375A, 10, 30);
            }
            return true;
        }
    }

    [SerializationGenerator(0, false)]
    public partial class PowerScrollGiver : Item
    {
        public override bool ForceShowProperties => true;
        public override string DefaultName => "+20 Power Scrolls";

        [Constructible]
        public PowerScrollGiver() : base(0x1183) { Hue = 2214; Movable = false; }

        public override void OnDoubleClick(Mobile m)
        {
            if (!m.InRange(Location, 3)) return;
            var bag = new Bag();
            foreach (var sk in PetTrainingHelper.MagicSkills) bag.DropItem(new PowerScroll(sk, 120));
            foreach (var sk in PetTrainingHelper.CombatSkills) bag.DropItem(new PowerScroll(sk, 120));
            m.AddToBackpack(bag);
        }
    }
}
