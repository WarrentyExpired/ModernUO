using System;
using System.Collections.Generic;
using ModernUO.Serialization;
using Server.Collections;
using Server.ContextMenus;
using Server.Engines.WisdomWisps;
using Server.Items;
using Server.Mobiles;
using Server.Network;

namespace Server.Mobiles;

[SerializationGenerator(0)]
public partial class WisdomWisp : BaseCreature
{
    [SerializableField(0)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private PlayerMobile _owner;

    [SerializableField(1)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    [InvalidateProperties]
    private int _wispLevel;

    [SerializableField(2)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    [InvalidateProperties]
    private int _wispExperience;

    private TimerExecutionToken _healToken;
    private TimerExecutionToken _adviceToken;
    private TimerExecutionToken _followToken;
    private TimerExecutionToken _reformToken;

    private readonly List<(Serial Serial, DateTime Time)> _countedCorpses = new();
    private PathFollower _follower;
    private long _nextMove;

    [Constructible]
    public WisdomWisp() : base(AIType.AI_Animal, FightMode.None)
    {
        Body = 165;
        Name = "a wisdom wisp";
        Tamable = false;
        Blessed = true;
        InitTimers();
    }

    public override string DefaultName => "a wisdom wisp";

    [CommandProperty(AccessLevel.GameMaster)]
    public int Prestige => Hue switch
    {
        0x8A5 => 1,
        0x8AD => 2,
        0x89B => 3,
        0x8B0 => 4,
        0x455 => 5,
        _     => 0
    };

    [CommandProperty(AccessLevel.GameMaster)]
    public bool CanRebirth => _wispLevel >= WisdomWispSystem.MaxLevel && Prestige < WisdomWispSystem.MaxPrestige;

    public override void GetProperties(IPropertyList list)
    {
        base.GetProperties(list);
        list.Add(1060658, $"{"Wisp Level"}\t{_wispLevel}");
        list.Add(1060658, $"{"Wisp Experience"}\t{_wispExperience}");
        if (Prestige > 0) list.Add(1060658, $"{"Prestige"}\t{Prestige}");
        if (_owner is { Deleted: false }) list.Add(1060658, $"{"Bound to"}\t{_owner.Name}");
    }

    public override void GetContextMenuEntries(Mobile from, ref PooledRefList<ContextMenuEntry> list)
    {
        base.GetContextMenuEntries(from, ref list);
        if (from is PlayerMobile pm && _owner == pm && !Deleted) list.Add(new DismissEntry(this));
    }

    private class DismissEntry : ContextMenuEntry
    {
        private readonly WisdomWisp _wisp;
        public DismissEntry(WisdomWisp wisp) : base(6112) => _wisp = wisp;
        public override void OnClick(Mobile from, IEntity target)
        {
            if (_wisp == null || _wisp.Deleted || _wisp.Owner != from) return;
            _wisp.Delete();
            from.SendMessage("Your wisp has been dismissed.");
        }
    }

    public override void OnDelete()
    {
        CancelTimers();
        WisdomWispSystem.Unregister(this);
        base.OnDelete();
    }

    public override void OnAfterDelete()
    {
        _owner = null;
        base.OnAfterDelete();
    }

    [AfterDeserialization]
    private void AfterDeserialization()
    {
        if (_owner is { Deleted: false }) Owner = _owner;
        WisdomWispSystem.Register(this);
        InitTimers();
        if (Map == Map.Internal && _owner is { Deleted: false } owner && owner.Map != Map.Internal) WakeUp(owner);
    }

    public void Sleep()
    {
        if (Deleted || Map == Map.Internal) return;
        MoveToWorld(Location, Map.Internal);
    }

    public void WakeUp(PlayerMobile owner)
    {
        if (Deleted || owner is not { Deleted: false } || owner.Map == Map.Internal || Map != Map.Internal) return;
        Owner = owner;
        _owner = owner;
        MoveToWorld(owner.Location, owner.Map);
    }

    public void Disperse(TimeSpan downtime)
    {
        if (Deleted || Map == Map.Internal) return;
        _reformToken.Cancel();
        Timer.StartTimer(downtime, TimeSpan.FromSeconds(5), Reform, out _reformToken);
        Sleep();
        if (_owner is { Deleted: false }) _owner.SendMessage($"Your wisp was dispersed by your death. It will reform in {(int)Math.Ceiling(downtime.TotalMinutes)} minutes.");
    }

    public bool AwaitingReform => _reformToken.Running;

    private void Reform()
    {
        if (Deleted || Map != Map.Internal || _owner == null || _owner.Deleted) { _reformToken.Cancel(); return; }
        if (!_owner.Alive || _owner.Map == Map.Internal) return;
        _reformToken.Cancel();
        WakeUp(_owner);
        _owner.SendMessage("Your wisp has reformed beside you.");
    }

    public void Rebirth()
    {
        if (Deleted || !CanRebirth) return;
        Hue = (Prestige + 1) switch
        {
            1    => 0x8A5,
            2    => 0x8AD,
            3    => 0x89B,
            4    => 0x8B0,
            >= 5 => 0x455,
            _    => 0
        };
        _wispLevel = 0;
        _wispExperience = 0;
        InvalidateProperties();
        this.MarkDirty();
        if (_owner is { Deleted: false }) _owner.SendMessage($"Your wisp has been reborn! Prestige {Prestige} - its healing power grows.");
    }

    public void AddExperience(int amount)
    {
        if (amount <= 0 || Deleted || _wispLevel >= WisdomWispSystem.MaxLevel) return;
        _wispExperience += amount;
        var threshold = ExperienceForNextLevel();
        while (_wispExperience >= threshold && _wispLevel < WisdomWispSystem.MaxLevel)
        {
            _wispExperience -= threshold;
            _wispLevel++;
            threshold = ExperienceForNextLevel();
            if (_owner is { Deleted: false })
            {
                if (_wispLevel >= WisdomWispSystem.MaxLevel) _owner.SendMessage("Your wisp reached max level! Rebirth it to grow even stronger.");
                else _owner.SendMessage($"Your wisp leveled up to level {_wispLevel}!");
            }
        }
        if (_wispLevel >= WisdomWispSystem.MaxLevel) _wispExperience = 0;
        InvalidateProperties();
        this.MarkDirty();
    }

    public static WisdomWisp CreateFor(PlayerMobile owner)
    {
        var wisp = new WisdomWisp { Owner = owner };
        wisp._owner = owner;
        WisdomWispSystem.Register(wisp);
        if (owner is { Deleted: false } && owner.Map != Map.Internal) wisp.MoveToWorld(owner.Location, owner.Map);
        return wisp;
    }

    private int ExperienceForNextLevel() => 100 + _wispLevel * 50;

    private void InitTimers()
    {
        CancelTimers();
        var healInterval = TimeSpan.FromSeconds(Math.Max(1, WisdomWispSystem.HealIntervalSeconds));
        Timer.StartTimer(healInterval, healInterval, HealTick, out _healToken);
        Timer.StartTimer(TimeSpan.FromSeconds(45), TimeSpan.FromSeconds(45), GiveAdvice, out _adviceToken);
        Timer.StartTimer(TimeSpan.FromMilliseconds(100), TimeSpan.FromMilliseconds(100), FollowTick, out _followToken);
    }

    private void CancelTimers()
    {
        _healToken.Cancel();
        _adviceToken.Cancel();
        _followToken.Cancel();
        _reformToken.Cancel();
    }

    private void HealTick()
    {
        if (Deleted || Map == Map.Internal || _owner is not { Deleted: false, Alive: true } owner || owner.Map != Map) return;
        ScanKills(owner);
        if (!owner.InRange(this, WisdomWispSystem.HealRange) || !owner.Map.LineOfSight(Location, owner.Location) || owner.Hits >= owner.HitsMax) return;
        var prestigeMultiplier = 1.0 + WisdomWispSystem.PrestigeHealBonus * Prestige;
        var healAmount = Math.Max(1, (int)Math.Ceiling(owner.HitsMax * WisdomWispSystem.HealPercent * (_wispLevel + 1) * prestigeMultiplier));
        if (owner.Combatant != null) healAmount = Math.Max(1, (int)(healAmount * WisdomWispSystem.CombatHealMultiplier));
        owner.Heal(healAmount);
        owner.PublicOverheadMessage(MessageType.Regular, 0x3B2, false, $"A wisp heals you for {healAmount} HP");
    }

    private void ScanKills(PlayerMobile owner)
    {
        var now = Core.Now;
        CleanupCountedCorpses(now);
        foreach (var item in Map.GetItemsInRange<Corpse>(owner.Location, 12))
        {
            if (item is not { Killer: { } killer, Owner: BaseCreature victim } || killer != owner || victim.Fame <= 0) continue;
            if (IsCorpseCounted(item.Serial)) continue;
            _countedCorpses.Add((item.Serial, now));
            WisdomWispSystem.AwardKillExperience(owner, victim);
        }
    }

    private bool IsCorpseCounted(Serial serial)
    {
        for (var i = 0; i < _countedCorpses.Count; i++)
            if (_countedCorpses[i].Serial == serial) return true;
        return false;
    }

    private void CleanupCountedCorpses(DateTime now)
    {
        for (var i = _countedCorpses.Count - 1; i >= 0; i--)
            if (now - _countedCorpses[i].Time > TimeSpan.FromMinutes(5)) _countedCorpses.RemoveAt(i);
    }

    private void GiveAdvice()
    {
        if (Deleted || Map == Map.Internal || _owner is { Deleted: true }) return;
        _owner.SendMessage($"Wisp advice: keep exploring to gain experience (Level {_wispLevel}).");
    }

    private void FollowTick()
    {
        if (Deleted || Map == Map.Internal || _owner is not { Deleted: false } owner || owner.Map == null || owner.Map == Map.Internal) return;
        if (!owner.Alive && WisdomWispSystem.DeathDowntime > TimeSpan.Zero) { Disperse(WisdomWispSystem.DeathDowntime); return; }
        if (owner.Map != Map || owner.GetDistanceToSqrt(this) > WisdomWispSystem.FollowTeleportDistance)
        {
            MoveToWorld(owner.Location, owner.Map);
            _follower?.ForceRepath();
            return;
        }
        if (owner.InRange(this, 2)) return;
        if (Core.TickCount - _nextMove < 0) return;
        var stepDelay = owner.GetDistanceToSqrt(this) > 3 ? 150 : 400;
        _nextMove = Core.TickCount + stepDelay;
        _follower ??= new PathFollower(this, owner);
        _follower.Follow(2);
    }
}