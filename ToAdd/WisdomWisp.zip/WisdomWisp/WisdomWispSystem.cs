using System;
using System.Collections.Generic;
using Server.Commands;
using Server.Mobiles;

namespace Server.Engines.WisdomWisps;

public static class WisdomWispSystem
{
    private static bool _enabled;
    private static int _maxLevel;
    private static int _maxPrestige;
    private static double _healPercent;
    private static double _prestigeHealBonus;
    private static int _healIntervalSeconds;
    private static int _healRange;
    private static double _combatHealMultiplier;
    private static int _followTeleportDistance;
    private static TimeSpan _summonCooldown;
    private static TimeSpan _deathDowntime;
    private static int _dailyExpCap;
    private static int _killExpDivisor;

    private static readonly Dictionary<PlayerMobile, WisdomWisp> _wisps = new();
    private static readonly Dictionary<PlayerMobile, DateTime> _cooldowns = new();
    private static readonly Dictionary<PlayerMobile, DailyExp> _dailyExp = new();

    public static bool Enabled => _enabled;
    public static int MaxLevel => _maxLevel;
    public static int MaxPrestige => _maxPrestige;
    public static double HealPercent => _healPercent;
    public static double PrestigeHealBonus => _prestigeHealBonus;
    public static int HealIntervalSeconds => _healIntervalSeconds;
    public static int HealRange => _healRange;
    public static double CombatHealMultiplier => _combatHealMultiplier;
    public static int FollowTeleportDistance => _followTeleportDistance;
    public static TimeSpan DeathDowntime => _deathDowntime;

    public static void Configure()
    {
        _enabled = ServerConfiguration.GetOrUpdateSetting("wisps.enabled", true);
        _maxLevel = ServerConfiguration.GetOrUpdateSetting("wisps.maxLevel", 10);
        _maxPrestige = ServerConfiguration.GetOrUpdateSetting("wisps.maxPrestige", 5);
        _healPercent = ServerConfiguration.GetOrUpdateSetting("wisps.healPercent", 0.02);
        _prestigeHealBonus = ServerConfiguration.GetOrUpdateSetting("wisps.prestigeHealBonus", 0.25);
        _healIntervalSeconds = ServerConfiguration.GetOrUpdateSetting("wisps.healIntervalSeconds", 5);
        _healRange = ServerConfiguration.GetOrUpdateSetting("wisps.healRange", 10);
        _combatHealMultiplier = ServerConfiguration.GetOrUpdateSetting("wisps.combatHealMultiplier", 0.3);
        _followTeleportDistance = ServerConfiguration.GetOrUpdateSetting("wisps.followTeleportDistance", 15);
        _summonCooldown = ServerConfiguration.GetOrUpdateSetting("wisps.summonCooldown", TimeSpan.FromMinutes(15));
        _deathDowntime = ServerConfiguration.GetOrUpdateSetting("wisps.deathDowntime", TimeSpan.FromMinutes(5));
        _dailyExpCap = ServerConfiguration.GetOrUpdateSetting("wisps.dailyExpCap", 500);
        _killExpDivisor = ServerConfiguration.GetOrUpdateSetting("wisps.killExpDivisor", 100);

        if (!_enabled)
        {
            return;
        }

        CommandSystem.Register("SummonWisp", AccessLevel.Player, SummonWisp_OnCommand);
        CommandSystem.Register("WispRebirth", AccessLevel.Player, WispRebirth_OnCommand);
        EventSink.Connected += OnConnected;
        EventSink.Logout += OnLogout;
    }

    public static void Register(WisdomWisp wisp)
    {
        if (wisp?.Owner is { } owner)
        {
            _wisps[owner] = wisp;
        }
    }

    public static void Unregister(WisdomWisp wisp)
    {
        if (wisp?.Owner is not { } owner)
        {
            return;
        }

        _cooldowns[owner] = Core.Now + _summonCooldown;

        if (_wisps.TryGetValue(owner, out var existing) && existing == wisp)
        {
            _wisps.Remove(owner);
        }
    }

    public static void AwardKillExperience(PlayerMobile owner, BaseCreature creature)
    {
        if (owner == null || owner.Deleted || creature == null)
        {
            return;
        }

        if (!_wisps.TryGetValue(owner, out var wisp) || wisp == null || wisp.Deleted ||
            wisp.WispLevel >= _maxLevel)
        {
            return;
        }

        var today = Core.Now.Date;
        _dailyExp.TryGetValue(owner, out var daily);
        if (daily.Day != today)
        {
            daily = default;
        }

        var remaining = _dailyExpCap - daily.Amount;
        if (remaining <= 0)
        {
            if (!daily.CapNotified)
            {
                daily.CapNotified = true;
                _dailyExp[owner] = daily;
                owner.SendMessage("Your wisp has gained all the experience it can today.");
            }

            return;
        }

        var gained = Math.Min(Math.Max(1, creature.Fame / _killExpDivisor), remaining);
        daily.Day = today;
        daily.Amount += gained;
        _dailyExp[owner] = daily;
        wisp.AddExperience(gained);
    }

    [Usage("SummonWisp")]
    [Description("Summons a wisdom wisp that binds to you.")]
    private static void SummonWisp_OnCommand(CommandEventArgs e)
    {
        var from = e.Mobile as PlayerMobile;
        if (from == null || from.Map == Map.Internal)
        {
            return;
        }

        if (_wisps.TryGetValue(from, out var existing) && !existing.Deleted)
        {
            from.SendMessage("You already have a wisp.");
            return;
        }

        if (_cooldowns.TryGetValue(from, out var readyAt) && Core.Now < readyAt)
        {
            var minutes = (int)Math.Ceiling((readyAt - Core.Now).TotalMinutes);
            from.SendMessage($"You must wait {minutes} minutes to summon a new wisp.");
            return;
        }

        _cooldowns.Remove(from);
        WisdomWisp.CreateFor(from);
        from.SendMessage("A small wisdom wisp appears and binds to you.");
    }

    [Usage("WispRebirth")]
    [Description("Rebirths your wisp at max level, gaining a prestige tier.")]
    private static void WispRebirth_OnCommand(CommandEventArgs e)
    {
        var from = e.Mobile as PlayerMobile;
        if (from == null)
        {
            return;
        }

        if (!_wisps.TryGetValue(from, out var wisp) || wisp == null || wisp.Deleted)
        {
            from.SendMessage("You do not have a wisp.");
            return;
        }

        if (!wisp.CanRebirth)
        {
            from.SendMessage("Your wisp must be at max level to be reborn.");
            return;
        }

        wisp.Rebirth();
    }

    private static void OnConnected(Mobile m)
    {
        if (m is not PlayerMobile pm)
        {
            return;
        }

        _cooldowns.Remove(pm);

        if (_wisps.TryGetValue(pm, out var wisp) && !wisp.Deleted && !wisp.AwaitingReform)
        {
            wisp.WakeUp(pm);
        }
    }

    private static void OnLogout(Mobile m)
    {
        if (m is not PlayerMobile pm)
        {
            return;
        }

        _dailyExp.Remove(pm);

        if (_wisps.TryGetValue(pm, out var wisp) && !wisp.Deleted)
        {
            wisp.Sleep();
        }
    }

    private struct DailyExp
    {
        public DateTime Day;
        public int Amount;
        public bool CapNotified;
    }
}
