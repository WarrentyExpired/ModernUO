# Wisdom Wisp System — Administrator Guide

**Original author:** Expa (ModernUO)

A bound healing companion for players, with leveling, daily-capped kill experience,
prestige rebirth, and death downtime. Built for ModernUO (.NET 10 / C# 14).

---

## 1. Overview

Each player may summon **one** Wisdom Wisp. The wisp is an immortal, non-combat
follower that heals its owner on a tick, gains experience from the owner's kills
(daily-capped), and can be **reborn** at max level for permanent prestige bonuses.
It sleeps while the owner is offline and disperses when the owner dies, reforming
automatically after a short downtime.

### Key anti-abuse properties (built in)

| Exploit | Protection |
|---|---|
| Multiple wisps per player | Global in-memory registry — one wisp per owner, no range limit |
| Parking the wisp at home for remote healing | Healing requires owner in range AND line of sight |
| Passive healing in combat | Heal amount reduced to 30% while owner has a combatant |
| Summon/dismiss spam | 15-minute summon cooldown after dismiss |
| Death dispel griefing | Wisp is Blessed (unkillable); death only causes a 5-minute reform delay |
| Relog to skip death downtime | Login wake-up is blocked while the reform timer is running |
| Infinite XP farming | Daily XP cap with one-time notification |

---

## 2. Installation

1. Copy the contents of the archive to your ModernUO tree:
   ```
   Projects/UOContent/Engines/WisdomWisp/
   ├── WisdomWisp.cs
   └── WisdomWispSystem.cs
   ```
2. If migrating from an older (prestige/migration) build, delete stale artifacts:
   ```
   Projects/UOContent/Migrations/Server.Mobiles.WisdomWisp.v*.json   (delete if present)
   rmdir /s /q Projects/UOContent/obj
   ```
3. Build and start the server:
   ```
   dotnet build ModernUO.slnx
   ```
4. On first start all `wisps.*` settings are appended to
   `Distribution/Configuration/modernuo.json` automatically.

No serialization migration is required: the system uses serialization version 0
with three stable fields (`Owner`, `WispLevel`, `WispExperience`). Prestige is
encoded in the wisp's Hue (a base Mobile property) and survives saves without a
version bump.

---

## 3. Configuration Reference

All settings live under `settings` in `modernuo.json` (dot-separated keys).

| Key | Type | Default | Description |
|---|---|---|---|
| `wisps.enabled` | bool | `true` | Master switch. When `false`, commands are not registered and no events fire. |
| `wisps.maxLevel` | int | `10` | Maximum wisp level. XP stops accumulating beyond it. |
| `wisps.maxPrestige` | int | `5` | Maximum prestige tier (rebirth count). |
| `wisps.healPercent` | double | `0.02` | Base heal per tick as a fraction of owner's max HP (2%). |
| `wisps.prestigeHealBonus` | double | `0.25` | Additional heal multiplier per prestige tier (+25% each). |
| `wisps.healIntervalSeconds` | int | `5` | Seconds between heal ticks (minimum 1). |
| `wisps.healRange` | int | `10` | Max tiles owner-to-wisp distance for healing. |
| `wisps.combatHealMultiplier` | double | `0.3` | Heal multiplier while the owner is in combat (0.3 = 30%). |
| `wisps.followTeleportDistance` | int | `15` | Distance beyond which the wisp teleports to the owner instead of walking. |
| `wisps.summonCooldown` | TimeSpan | `00:15:00` | Cooldown after dismiss before a new wisp can be summoned. |
| `wisps.deathDowntime` | TimeSpan | `00:05:00` | How long a dispersed wisp takes to reform after owner death. Set to `00:00:00` to disable dispersal entirely. |
| `wisps.dailyExpCap` | int | `500` | Maximum kill XP per player per real-world day. |
| `wisps.killExpDivisor` | int | `100` | XP per kill = creature Fame / this value (minimum 1). |

### Heal formula

```
heal = ceil(MaxHP * healPercent * (level + 1) * (1 + prestigeHealBonus * prestige))
if owner in combat: heal = floor(heal * combatHealMultiplier)
minimum 1 per tick
```

Example (100 max HP, level 3, prestige 2, out of combat):
`100 * 0.02 * 4 * 1.5 = 12 HP every 5 seconds`.

### XP curve

XP to next level = `100 + 50 * currentLevel`. Full level track 0→10 = **3250 XP**.
At the default daily cap of 500, one prestige cycle takes ~7 active days; all five
prestiges ~32 days. Tune via `dailyExpCap` / `killExpDivisor` for your shard pace.

---

## 4. Player-Facing Features

| Feature | How it works |
|---|---|
| Summon | `[summonwisp` (players). Fails if a wisp already exists or cooldown is active. |
| Tooltip | Hovering the wisp shows level, XP, prestige, and owner. |
| Rebirth | `[wisprebirth` command (players), requires max level. Resets level/XP to 0, +1 prestige, hue changes. |
| Dismiss | Context menu (Release) on your own wisp. Permanent; starts the summon cooldown. |
| Logout | Wisp sleeps (internal map); wakes beside owner on login. |
| Death | Wisp disperses; reforms next to the owner after `deathDowntime` (message on both events). |

Prestige hue table:

| Prestige | Hue | Prestige | Hue |
|---|---|---|---|
| 1 | 0x8A5 | 4 | 0x8B0 |
| 2 | 0x8AD | 5 | 0x455 |
| 3 | 0x89B | | |

---

## 5. GM / Admin Tools

| Action | How |
|---|---|
| Spawn a wisp for testing | `[add wisdomwisp` then `[set owner <player>` via props |
| Inspect/modify | `[props` on the wisp — `Owner`, `WispLevel`, `WispExperience`, `Prestige`, `CanRebirth` are command properties |
| Force rebirth | Set `WispLevel` to max via `[props`, then `[wisprebirth` |
| Grant XP from another system | `WisdomWispSystem.AwardKillExperience(player, creature)` or `wisp.AddExperience(amount)` from any custom code |
| Remove a wisp | `[delete` on it (normal delete; registry and timers clean up automatically) |

---

## 6. Architecture Notes (for maintainers)

- **Registry**: `WisdomWispSystem` keeps `Dictionary<PlayerMobile, WisdomWisp>`.
  Registered on creation and deserialization; unregistered on delete. The summon
  command, login/logout handlers and XP awards all go through it.
- **Wander suppression**: `DisallowAllMoves = true` in the constructor. The
  built-in `BaseAI.WalkRandom` bails on this flag, so the AI cannot move the
  wisp. Our own movement (PathFollower, MoveToWorld) does not consult the flag.
- **Timers** (per wisp, all `TimerExecutionToken`, cancelled in `OnDelete`):
  heal tick (configurable interval), advice tick (45 s), follow tick (100 ms),
  reform retry (only while dispersed; retries every 5 s until the owner is alive
  in world).
- **Follow logic**: `PathFollower` (A* obstacle avoidance via the server
  pathfinding service) driven by a move clock, mimicking BaseAI pacing: steps
  every 150 ms when catching up (faster than a running player) or 400 ms when
  strolling, idle within 2 tiles — the catch-up/settle rhythm mimics a real pet.
  Teleport (with repath) only when the owner is on another map, beyond
  `followTeleportDistance`, or out of line of sight.
- **Kill detection**: fresh corpses within 12 tiles of the owner where
  `Corpse.Killer == owner`. Each corpse counts once. Only the owner's own kills
  grant XP (pets/summons do not).
- **Persistence**: serialization v0, fields `Owner`/`WispLevel`/`WispExperience`
  (`Owner` is the generated accessor for the `_owner` field — one storage, two
  names; never "sync" them). Prestige is derived from `Hue`. Daily XP and summon
  cooldowns are in-memory only (a server restart resets the daily XP budget and
  skips any active death downtime — accepted trade-off to avoid schema
  migrations).

---

## 7. Troubleshooting

| Symptom | Cause / Fix |
|---|---|
| `You already have a wisp.` but no wisp visible | The wisp is dispersed (owner died) or sleeping (owner logged out elsewhere). Wait for reform, or relog — wake-up is blocked only while the reform timer is running. |
| Wisp wanders off / jitters around the owner | `DisallowAllMoves = true` missing in the constructor — restore it; `BaseAI.WalkRandom` must stay blocked. |
| Wisp never heals | Check distance (< `healRange`), walls between (LOS), owner at full HP, or `wisps.enabled`. |
| No XP from kills | Only the killing blow by the owner counts (not pets). Creature must have Fame > 0. Daily cap may be reached. |
| Player relogged during dispersal and the wisp is gone | By design the wisp returns immediately after a server restart (downtime is not persisted). |
| `CS0246 VXContent` / migration errors after editing fields | Do not bump `[SerializationGenerator]` version without generating migration schemas first. This build needs none — keep version 0. |
| Wisps walk straight into walls | `pathfinding.enable` is `false` in config; PathFollower degrades to direct steps. Enable pathfinding. |

---

## 8. Balance Quick Reference

| Goal | Change |
|---|---|
| Softer on newbies | Lower `healPercent` to 0.01, keep everything else |
| Faster progression | Raise `dailyExpCap` to 750–1000 |
| Harder death penalty | Raise `deathDowntime` to 10–15 min |
| PvP-heavy shard | Lower `combatHealMultiplier` to 0.15–0.2 |
| Casual shard | Raise `healPercent` instead of shortening `healIntervalSeconds` |
| Tighter/looser follow | Step paces are the 150/400 ms constants in `FollowTick`; the idle radius is the `InRange(this, 2)` check |
