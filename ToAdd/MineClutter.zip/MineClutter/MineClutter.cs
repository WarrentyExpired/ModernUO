using System;
using ModernUO.Serialization;
using Server.Engines.Harvest;

namespace Server.Items;

public enum MineClutterStage
{
    Debris = 0,
    Rocks = 1,
    Boulder = 2,
    LargeBoulder = 3
}

[SerializationGenerator(0, false)]
public partial class MineClutter : Item
{
    private static readonly int[] LargeBoulderIds = [0x1363, 0x1364];
    private static readonly int[] BoulderIds = [0x1365, 0x1366];
    private static readonly int[] RockIds = [0x1362, 0x1367, 0x1368];
    private static readonly int[] DebrisIds = [0x136A, 0x136B, 0x136C];
    private static readonly int[] Hues = [0, 0x451, 0x452, 0x453, 0x454];

    [SerializableField(0)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private int _stageValue;

    [SerializableField(1)]
    [InvalidateProperties]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private int _hitsLeft;

    [SerializableField(2)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private long _decayTicks;

    [SerializableField(3)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private Mobile _owner;

    [SerializableField(4)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private double _oreReqSkill;

    [SerializableField(5)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private long _sinkStartTicks;

    [SerializableField(6)]
    [SerializedCommandProperty(AccessLevel.GameMaster)]
    private int _sinkFromZ;

    private TimerExecutionToken _lifecycleToken;

    [Constructible]
    public MineClutter() : this(MineClutterStage.Boulder, null, 0.0, -1)
    {
    }

    [Constructible]
    public MineClutter(MineClutterStage stage) : this(stage, null, 0.0, -1)
    {
    }

    public MineClutter(MineClutterStage stage, Mobile owner, double oreReqSkill = 0.0, int oreHue = -1)
        : base(GetItemId(stage))
    {
        StageValue = (int)stage;
        OreReqSkill = oreReqSkill;
        HitsLeft = GetHits(stage, oreReqSkill);
        Owner = owner;
        Hue = oreHue >= 0 ? oreHue : RandomId(Hues);
        Movable = true;
        Weight = GetWeight(stage, oreReqSkill);

        MineClutterSystem.Register(this);
        ApplyStage(false);
    }

    [CommandProperty(AccessLevel.GameMaster)]
    public MineClutterStage Stage
    {
        get => (MineClutterStage)StageValue;
        set
        {
            StageValue = (int)value;
            ApplyStage(true);
            InvalidateProperties();
        }
    }

    public bool BlocksMovement => Stage >= MineClutterStage.Boulder;

    public override bool Decays => false;

    public override string DefaultName => Stage switch
    {
        MineClutterStage.LargeBoulder => "a huge fallen boulder",
        MineClutterStage.Boulder      => "a fallen boulder",
        MineClutterStage.Rocks        => "a pile of mining rocks",
        _                             => "mining debris"
    };

    public override void GetProperties(IPropertyList list)
    {
        base.GetProperties(list);
        list.Add($"Rock Durability: {HitsLeft}");
    }

    public override bool VerifyMove(Mobile from)
    {
        if (!base.VerifyMove(from))
        {
            return false;
        }

        if (from == null)
        {
            return true;
        }

        var maxWeight = from.MaxWeight == int.MaxValue ? (int)(40.0 + from.Str * 3.5) : from.MaxWeight;

        if (from.TotalWeight + PileWeight > maxWeight)
        {
            from.SendMessage("That rock is too heavy for you to lift. A stronger miner could carry it.");
            return false;
        }

        return true;
    }

    public override bool OnMoveOver(Mobile m)
    {
        if (m == null || !m.Alive || m.AccessLevel > AccessLevel.Player ||
            !MineClutterSystem.Blocking || !BlocksMovement)
        {
            return true;
        }

        if (!MineClutterSystem.BlockInGuarded &&
            Region.Find(GetWorldLocation(), Map) is Server.Regions.GuardedRegion)
        {
            return true;
        }

        if (Utility.RandomDouble() < 0.20)
        {
            m.SendMessage("A fallen rock blocks your path.");
        }

        return false;
    }

    public override void OnDoubleClick(Mobile from)
    {
        MineClutterSystem.TryStartClearing(from, this);
    }

    public override void OnMapChange()
    {
        StartLifecycle();
    }

    public override bool OnDroppedToWorld(Mobile from, Point3D p)
    {
        var placed = base.OnDroppedToWorld(from, p);

        if (placed)
        {
            StartLifecycle();
        }

        return placed;
    }

    public void BreakDown(Mobile from)
    {
        var next = Stage - 1;

        if (next >= MineClutterStage.Debris)
        {
            HitsLeft = Math.Max(GetHits(next, OreReqSkill), HitsLeft);
            Stage = next;
            from?.SendMessage("The rock breaks into smaller pieces.");
            return;
        }

        if (Map != null && Map != Map.Internal)
        {
            Effects.PlaySound(Location, Map, 0x3B3);
        }

        var lootId = MineClutterSystem.DebrisLootItemId;

        if (lootId > 0 && from != null)
        {
            var loot = new Item(lootId) { Movable = true };

            if (!from.AddToBackpack(loot) && Map != null && Map != Map.Internal)
            {
                loot.MoveToWorld(Location, Map);
            }
        }

        from?.SendMessage("You clear away the mining debris.");
        Delete();
    }

    [AfterDeserialization]
    private void AfterDeserialization()
    {
        ApplyStage(false);

        if (HitsLeft <= 0)
        {
            HitsLeft = GetHits(Stage, OreReqSkill);
        }

        InvalidateProperties();
        MineClutterSystem.Register(this);
        StartLifecycle();
    }

    public override void OnAfterDelete()
    {
        _lifecycleToken.Cancel();
        MineClutterSystem.Unregister(this);
        base.OnAfterDelete();
    }

    private void ApplyStage(bool sendDelta)
    {
        ItemID = GetItemId(Stage);
        Weight = GetWeight(Stage, OreReqSkill);

        if (sendDelta && Map != null && Map != Map.Internal)
        {
            Delta(ItemDelta.Update);
        }
    }

    private static bool CanSinkAt(Map map, Point3D p)
    {
        if (map == null || map == Map.Internal || map.Tiles.GetLandTile(p.X, p.Y).Ignored)
        {
            return false;
        }

        foreach (var _ in map.Tiles.GetStaticAndMultiTiles(p.X, p.Y))
        {
            return false;
        }

        return true;
    }

    private void StartLifecycle()
    {
        _lifecycleToken.Cancel();

        var map = Map;

        if (map == null || map == Map.Internal)
        {
            return;
        }

        if (MineClutterSystem.SinkAfter > TimeSpan.Zero && CanSinkAt(map, Location))
        {
            SinkStartTicks = Core.Now.Ticks;
            SinkFromZ = Z;

            var interval = TimeSpan.FromTicks(MineClutterSystem.SinkAfter.Ticks / MineClutterSystem.SinkSteps);

            if (interval < TimeSpan.FromSeconds(1))
            {
                interval = TimeSpan.FromSeconds(1);
            }

            Timer.StartTimer(interval, interval, SinkTick, out _lifecycleToken);
            return;
        }

        DecayTicks = (Core.Now + MineClutterSystem.DecayTime).Ticks;

        if (MineClutterSystem.DecayTime <= TimeSpan.Zero)
        {
            return;
        }

        var delayTicks = DecayTicks - Core.Now.Ticks;

        if (delayTicks <= 0)
        {
            Timer.DelayCall(Delete);
            return;
        }

        Timer.StartTimer(TimeSpan.FromTicks(delayTicks), Decay, out _lifecycleToken);
    }

    private void SinkTick()
    {
        if (Deleted)
        {
            return;
        }

        var map = Map;

        if (map == null || map == Map.Internal)
        {
            return;
        }

        if (!CanSinkAt(map, Location))
        {
            StartLifecycle();
            return;
        }

        var progress = (double)(Core.Now.Ticks - SinkStartTicks) / MineClutterSystem.SinkAfter.Ticks;

        if (progress >= 1.0)
        {
            Delete();
            return;
        }

        var z = SinkFromZ - (int)(MineClutterSystem.SinkDepth * progress);

        if (z != Z)
        {
            Z = z;
        }
    }

    private void Decay() => Delete();

    private static int GetHits(MineClutterStage stage, double oreReqSkill) =>
        GetDefaultHits(stage) + (int)(oreReqSkill / MineClutterSystem.HitsSkillStep);

    private static int GetDefaultHits(MineClutterStage stage) => stage switch
    {
        MineClutterStage.LargeBoulder => MineClutterSystem.HitsLarge,
        MineClutterStage.Boulder      => MineClutterSystem.HitsBoulder,
        MineClutterStage.Rocks        => MineClutterSystem.HitsRocks,
        _                             => MineClutterSystem.HitsDebris
    };

    private static double GetWeight(MineClutterStage stage, double oreReqSkill)
    {
        var baseWeight = stage switch
        {
            MineClutterStage.LargeBoulder => MineClutterSystem.WeightLarge,
            MineClutterStage.Boulder      => MineClutterSystem.WeightBoulder,
            MineClutterStage.Rocks        => MineClutterSystem.WeightRocks,
            _                             => MineClutterSystem.WeightDebris
        };

        return baseWeight * (1.0 + oreReqSkill * MineClutterSystem.WeightBonusPerSkill / 100.0);
    }

    private static int GetItemId(MineClutterStage stage) => stage switch
    {
        MineClutterStage.LargeBoulder => RandomId(LargeBoulderIds),
        MineClutterStage.Boulder      => RandomId(BoulderIds),
        MineClutterStage.Rocks        => RandomId(RockIds),
        _                             => RandomId(DebrisIds)
    };

    private static int RandomId(int[] ids) => ids[Utility.Random(ids.Length)];
}
