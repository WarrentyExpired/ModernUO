# Cave-Ins & Rockfall — Administrator's Guide
# Author: Expa


MINE CLUTTER - ModernUO mod
===========================

Every mining attempt (success or failure) has a chance to knock a rock loose
next to the miner. Rocks block passage, take time to clear, and slowly sink
into the ground. Rare digs unearth a long-dead miner skeleton with loot.

Mod files:
  MineClutter/MineClutter.cs        - the rock item
  MineClutter/MineClutterSystem.cs  - spawning, clearing, config, commands

Core patch (required):
  Projects/UOContent/Engines/Harvest/Mining.cs
  Projects/UOContent/Engines/Harvest/Core/HarvestSystem.cs
  (pre-patched copies in FullFiles/, or apply manually, see PATCH below)


------------------------------------------------------------
INSTALL
------------------------------------------------------------
1. Back up:
     Projects/UOContent/Engines/Harvest/Mining.cs
     Projects/UOContent/Engines/Harvest/Core/HarvestSystem.cs

2. Option A (file replacement):
     FullFiles/Mining.cs         -> Projects/UOContent/Engines/Harvest/Mining.cs
     FullFiles/HarvestSystem.cs  -> Projects/UOContent/Engines/Harvest/Core/HarvestSystem.cs

   Option B (manual patch) - see PATCH below.

3. New files:
     MineClutter/MineClutter.cs       -> Projects/UOContent/Engines/Harvest/MineClutter/
     MineClutter/MineClutterSystem.cs -> Projects/UOContent/Engines/Harvest/MineClutter/

4. Build and run. All "mineClutter.*" keys appear in modernuo.json automatically.

UNINSTALL: revert the patch (or restore backups), delete the MineClutter folder.
Run [ClearAllMineClutter first if spawned rocks should be removed from saves.


------------------------------------------------------------
PATCH (manual, 3 edits)
------------------------------------------------------------
Goal: pass the dig success flag from the harvest core into the mod.
Nothing else changes.

1) Core/HarvestSystem.cs, edit A - last line of FinishHarvesting(...):

   from:
       OnHarvestFinished(from, tool, def, vein, bank, resource, toHarvest);
   to:
       OnHarvestFinished(from, tool, def, vein, bank, resource, toHarvest, type != null);

   The local variable "type" is null on a failed quality check and non-null
   on success; it is in scope at the end of the method.

2) Core/HarvestSystem.cs, edit B - right AFTER the existing empty method

       public virtual void OnHarvestFinished(
           Mobile from, Item tool, HarvestDefinition def, HarvestVein vein,
           HarvestBank bank, HarvestResource resource, object harvested
       )
       {
       }

   add:

       public virtual void OnHarvestFinished(
           Mobile from, Item tool, HarvestDefinition def, HarvestVein vein,
           HarvestBank bank, HarvestResource resource, object harvested, bool success
       ) =>
           OnHarvestFinished(from, tool, def, vein, bank, resource, harvested);

   Old 7-argument call sites keep working - the overload delegates to the
   original virtual method, other HarvestSystem subclasses are unaffected.

3) Mining.cs - replace the override signature:

       public override void OnHarvestFinished(
           Mobile from, Item tool, HarvestDefinition def, HarvestVein vein,
           HarvestBank bank, HarvestResource resource, object harvested
       )
       {

   with:

       public override void OnHarvestFinished(
           Mobile from, Item tool, HarvestDefinition def, HarvestVein vein,
           HarvestBank bank, HarvestResource resource, object harvested, bool success
       )
       {
           MineClutterSystem.OnHarvestFinished(this, from, def, vein, success);

   Leave the rest of the method body (gargoyle pickaxe elementals) untouched.


------------------------------------------------------------
HOW THE SYSTEM WORKS
------------------------------------------------------------
SPAWNING
  On every finished OreAndStone dig (success or failed quality check):
    success -> chance mineClutter.successChance (default 0.18)
    failure -> chance mineClutter.failChance  (default 0.38)
  The rock appears on one of the 8 neighbouring tiles (never under the miner),
  only on walkable ground. Density is capped: at most maxPerArea rocks within
  areaRange tiles.

STAGES AND HEALTH
  Debris(0) -> Rocks(1) -> Boulder(2) -> LargeBoulder(3); spawning goes
  strictly downwards from Large.
  Hits = stage base + floor(vein ReqSkill / hitsSkillStep)
    base: Large 4 / Boulder 3 / Rocks 2 / Debris 1
  Defaults (+50% preset, step=15): iron 6/5/3/2, copper 11/10/8/7,
  valorite 12/11/9/8.
  Cracking goes DOWN only: at 0 hits the stage drops, remaining hits carry
  over (max(new stage hits, remainder)); at Debris the rock simply vanishes.
  A stage can never grow.
  Durability is shown as "Rock Durability: N" in the OPL.

CLEARING (double-click the rock, pickaxe/shovel in hand or backpack)
  Each swing: Mining skill check (clearMinSkill..clearMaxSkill); a success
  deals damage = 1 (+1 if STR >= strBonusThreshold, +1 if Mining >=
  miningBonusThreshold).
  Anti-macro: swingDelayMs pause between swings, stamina cost stamCost + stage
  per swing, tool wear on failure (wearOnFail).
  Final blow: drops debrisLootItemId (0 = none), rock disappears.

CARRYING
  All rocks are movable. Lifting checks carrying capacity: current weight +
  rock must not exceed MaxWeight (fallback formula 40 + STR*3.5 if PlayerMobile
  does not override it). Base weights: Large 255 / Boulder 120 / Rocks 60 /
  Debris 20, scaled by vein difficulty (+weightBonusPerSkill% per ReqSkill).
  Approximate bare-carry STR gates: Debris any, Rocks 6, Boulder 23, Large 62
  (iron). A valorite Large is ~318 stones, needing STR ~80.

MOVEMENT BLOCKING
  Boulder and above block mobiles (Item.OnMoveOver, no tiledata dependency).
  Toggle with mineClutter.blocking=false.

COLOR
  tintByOre=true: the rock is tinted with the vein ore color via CraftResources
  (iron grey 0x000, copper 0x96D, valorite 0x8AB, etc.) - the color shows
  which ore caused the cave-in. false = random grey palette from Hues.

MINER SKELETON
  Independent skeletonChance on every pickaxe swing (success or failure).
  A Corpse named "a long-dead miner" is unearthed nearby with loot; it can be
  looted and decays like a normal corpse. Rating = Mining + STR/2 + Luck/4:
  1-3 items (one per 60 rating), gold 10..10+rating*goldFactor,
  loot table: 55% gold / 35% random gem / 10% old pickaxe.

LIFETIME
  Two modes, chosen by tile (checked on placement and once per tick):
  - bare ground (no statics or multis): SINKING - the rock slowly sinks
    sinkDepth z-levels over sinkAfter (default 10z / 7 days / 10 steps), then
    is deleted. Progress is a pure function of real time; ticks are rare
    (~1 per 16.8h per rock); after a restart the rock catches up instantly by
    formula. sinkAfter=0 disables sinking.
  - floor/house/structure (statics or multi in the tile): plain decay
    (default 45 minutes). Hauling a rock home does not preserve it - it
    disappears faster indoors than in a mine.

PERFORMANCE
  One timer per rock with rare ticks; a HashSet registry for the global
  command; hot paths (movement) only hit OnMoveOver with no allocations.


------------------------------------------------------------
CONFIG (modernuo.json)
------------------------------------------------------------
  "mineClutter.enabled": true          - master switch
  "mineClutter.blocking": true         - large rocks block movement
  "mineClutter.blockInGuarded": false  - rocks block in towns (false = no block)
  "mineClutter.successChance": 0.18    - cave-in chance on success
  "mineClutter.failChance": 0.38       - cave-in chance on failed quality
  "mineClutter.maxPerArea": 10         - rock cap within areaRange
  "mineClutter.areaRange": 3
  "mineClutter.decay": "00:45:00"      - indoor decay (0 = never)
  "mineClutter.sinkAfter": "7.00:00:00"- sink into ground duration (0 = off)
  "mineClutter.sinkSteps": 10          - sink steps
  "mineClutter.sinkDepth": 10          - sink depth (z)
  "mineClutter.debrisLootItemId": 0    - final-blow loot (0 = none)
  "mineClutter.tintByOre": true        - rock color = vein ore color
  "mineClutter.hitsLarge": 6           - base hits per stage (+50% preset)
  "mineClutter.hitsBoulder": 5
  "mineClutter.hitsRocks": 3
  "mineClutter.hitsDebris": 2
  "mineClutter.hitsSkillStep": 15.0    - +1 hit per N vein ReqSkill (step 15:
                                        DC/Shadow +4, Copper..Verite +5, Valorite +6)
  "mineClutter.weightLarge": 255.0     - base weight per stage (stones)
  "mineClutter.weightBoulder": 120.0
  "mineClutter.weightRocks": 60.0
  "mineClutter.weightDebris": 20.0
  "mineClutter.weightBonusPerSkill": 0.25 - +N% weight per vein ReqSkill point
                                        (valorite 99 -> +24.75% at 0.25)
  "mineClutter.clearMinSkill": 0.0     - clearing skill check (Mining)
  "mineClutter.clearMaxSkill": 80.0
  "mineClutter.strBonusThreshold": 100     - STR >= N: +1 damage per swing
  "mineClutter.miningBonusThreshold": 100  - Mining >= N: +1 damage per swing
  "mineClutter.swingDelayMs": 1500     - pause between swings (anti-macro)
  "mineClutter.stamCost": 3            - stamina per swing (+ rock stage)
  "mineClutter.wearOnFail": true       - tool wear on missed swings
  "mineClutter.skeletonChance": 0.02   - skeleton loot chance (0 = off)
  "mineClutter.skeletonGoldFactor": 2.0- skeleton gold multiplier

Rock graphic IDs - arrays LargeBoulderIds/BoulderIds/RockIds/DebrisIds and the
Hues palette in MineClutter.cs, adjust for your client.


------------------------------------------------------------
GM COMMANDS
------------------------------------------------------------
  [ClearMineClutter [radius]   - remove rocks around you (alias [clrrocks)
  [ClearAllMineClutter         - remove ALL rocks on all maps (Administrator)
  [add MineClutter             - spawn a rock (props: Stage, HitsLeft, Hue)


------------------------------------------------------------
POST-INSTALL CHECKLIST
------------------------------------------------------------
  1. [add MineClutter - double-click with a pickaxe: the rock loses
     "Rock Durability" and cracks into a smaller stage at 0.
  2. Mine iron: cave-ins on ~18% of successes / ~38% of failures.
  3. Rock has the vein color; valorite rocks have more hits.
  4. Drop a rock on the ground, check [props: DecayTicks refreshed.
  5. [ClearAllMineClutter prints the number of removed rocks.

ANTI-ABUSE NOTES
  - Clearing trains Mining up to clearMaxSkill; lower it (e.g. 40) if AFK
    rock-breaking as a training loop is a concern.
  - skeletonChance is per dig: at 0.02 an around-the-clock bot earns roughly
    two dozen skeletons per hour. Use 0.005 or lower on live shards.
  - Rocks dropped in doorways outdoors sink within sinkAfter (default 7 days);
    with blockInGuarded=false town blocking is disabled entirely, and indoor
    rocks decay in "mineClutter.decay" minutes. GMs: [ClearMineClutter.
