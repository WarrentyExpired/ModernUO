using System;
using System.Collections.Generic;
using Server.Items;

namespace Server.Engines.Harvest;

public static class MineClutterSystem
{
    private static readonly (int X, int Y)[] Offsets =
    [
        (-1, -1), (-1, 0), (-1, 1),
        ( 0, -1),          ( 0, 1),
        ( 1, -1), ( 1, 0), ( 1, 1)
    ];

    private static readonly Type[] GemTypes =
    [
        typeof(Amber), typeof(Amethyst), typeof(Citrine), typeof(Diamond),
        typeof(Emerald), typeof(Ruby), typeof(Sapphire), typeof(StarSapphire),
        typeof(Tourmaline)
    ];

    private static bool _enabled;
    private static bool _blocking;
    private static double _successChance;
    private static double _failChance;
    private static int _maxPerArea;
    private static int _areaRange;
    private static TimeSpan _decayTime;
    private static int _debrisLootItemId;
    private static bool _tintByOre;
    private static double _clearMinSkill;
    private static double _clearMaxSkill;
    private static double _hitsSkillStep;
    private static int _strBonusThreshold;
    private static int _miningBonusThreshold;
    private static int _swingDelayMs;
    private static int _stamCost;
    private static bool _wearOnFail;
    private static bool _blockInGuarded;
    private static int _hitsLarge;
    private static int _hitsBoulder;
    private static int _hitsRocks;
    private static int _hitsDebris;
    private static double _weightLarge;
    private static double _weightBoulder;
    private static double _weightRocks;
    private static double _weightDebris;
    private static double _weightBonusPerSkill;
    private static double _skeletonChance;
    private static double _skeletonGoldFactor;
    private static TimeSpan _sinkAfter;
    private static int _sinkSteps;
    private static int _sinkDepth;

    private static readonly HashSet<MineClutter> _active = [];

    public static bool Blocking => _blocking;
    public static bool BlockInGuarded => _blockInGuarded;

    public static int HitsLarge => _hitsLarge;

    public static int HitsBoulder => _hitsBoulder;

    public static int HitsRocks => _hitsRocks;

    public static int HitsDebris => _hitsDebris;

    public static double WeightLarge => _weightLarge;

    public static double WeightBoulder => _weightBoulder;

    public static double WeightRocks => _weightRocks;

    public static double WeightDebris => _weightDebris;

    public static double WeightBonusPerSkill => _weightBonusPerSkill;
    public static TimeSpan DecayTime => _decayTime;
    public static int DebrisLootItemId => _debrisLootItemId;

    public static void Configure()
    {
        _enabled = ServerConfiguration.GetOrUpdateSetting("mineClutter.enabled", true);
        _blocking = ServerConfiguration.GetOrUpdateSetting("mineClutter.blocking", true);
        _successChance = ServerConfiguration.GetOrUpdateSetting("mineClutter.successChance", 0.18);
        _failChance = ServerConfiguration.GetOrUpdateSetting("mineClutter.failChance", 0.38);
        _maxPerArea = ServerConfiguration.GetOrUpdateSetting("mineClutter.maxPerArea", 10);
        _areaRange = ServerConfiguration.GetOrUpdateSetting("mineClutter.areaRange", 3);
        _decayTime = ServerConfiguration.GetOrUpdateSetting("mineClutter.decay", TimeSpan.FromMinutes(45));
        _debrisLootItemId = ServerConfiguration.GetOrUpdateSetting("mineClutter.debrisLootItemId", 0);
        _tintByOre = ServerConfiguration.GetOrUpdateSetting("mineClutter.tintByOre", true);
        _clearMinSkill = ServerConfiguration.GetOrUpdateSetting("mineClutter.clearMinSkill", 0.0);
        _clearMaxSkill = ServerConfiguration.GetOrUpdateSetting("mineClutter.clearMaxSkill", 80.0);
        _hitsSkillStep = ServerConfiguration.GetOrUpdateSetting("mineClutter.hitsSkillStep", 15.0);
        _strBonusThreshold = ServerConfiguration.GetOrUpdateSetting("mineClutter.strBonusThreshold", 100);
        _miningBonusThreshold = ServerConfiguration.GetOrUpdateSetting("mineClutter.miningBonusThreshold", 100);
        _swingDelayMs = ServerConfiguration.GetOrUpdateSetting("mineClutter.swingDelayMs", 1500);
        _stamCost = ServerConfiguration.GetOrUpdateSetting("mineClutter.stamCost", 3);
        _wearOnFail = ServerConfiguration.GetOrUpdateSetting("mineClutter.wearOnFail", true);

        // false = rocks never block movement inside guarded (town) regions
        _blockInGuarded = ServerConfiguration.GetOrUpdateSetting("mineClutter.blockInGuarded", false);

        _hitsLarge = ServerConfiguration.GetOrUpdateSetting("mineClutter.hitsLarge", 6);
        _hitsBoulder = ServerConfiguration.GetOrUpdateSetting("mineClutter.hitsBoulder", 5);
        _hitsRocks = ServerConfiguration.GetOrUpdateSetting("mineClutter.hitsRocks", 3);
        _hitsDebris = ServerConfiguration.GetOrUpdateSetting("mineClutter.hitsDebris", 2);

        _weightLarge = ServerConfiguration.GetOrUpdateSetting("mineClutter.weightLarge", 255.0);
        _weightBoulder = ServerConfiguration.GetOrUpdateSetting("mineClutter.weightBoulder", 120.0);
        _weightRocks = ServerConfiguration.GetOrUpdateSetting("mineClutter.weightRocks", 60.0);
        _weightDebris = ServerConfiguration.GetOrUpdateSetting("mineClutter.weightDebris", 20.0);

        // +N% веса за каждый пункт ReqSkill жилы (valorite 99 -> +24.75% при 0.25)
        _weightBonusPerSkill = ServerConfiguration.GetOrUpdateSetting("mineClutter.weightBonusPerSkill", 0.25);
        _skeletonChance = ServerConfiguration.GetOrUpdateSetting("mineClutter.skeletonChance", 0.02);
        _skeletonGoldFactor = ServerConfiguration.GetOrUpdateSetting("mineClutter.skeletonGoldFactor", 2.0);
        _sinkAfter = ServerConfiguration.GetOrUpdateSetting("mineClutter.sinkAfter", TimeSpan.FromDays(7));
        _sinkSteps = ServerConfiguration.GetOrUpdateSetting("mineClutter.sinkSteps", 10);
        _sinkDepth = ServerConfiguration.GetOrUpdateSetting("mineClutter.sinkDepth", 10);
    }

    public static void Initialize()
    {
        CommandSystem.Register("ClearMineClutter", AccessLevel.GameMaster, ClearMineClutter);
        CommandSystem.Register("ClearAllMineClutter", AccessLevel.Administrator, ClearAllMineClutter);
    }

    public static double HitsSkillStep => _hitsSkillStep;

    public static TimeSpan SinkAfter => _sinkAfter;

    public static int SinkSteps => _sinkSteps;

    public static int SinkDepth => _sinkDepth;

    public static int ActiveCount => _active.Count;

    public static void Register(MineClutter clutter)
    {
        _active.Add(clutter);
    }

    public static void Unregister(MineClutter clutter)
    {
        _active.Remove(clutter);
    }

    public static void OnHarvestFinished(
        Mining mining, Mobile from, HarvestDefinition def, HarvestVein vein, bool success
    )
    {
        if (!_enabled || def != mining.OreAndStone || from?.Map == null || from.Map == Map.Internal)
        {
            return;
        }

        var chance = success ? _successChance : _failChance;

        if (Utility.RandomDouble() < chance && !TooManyNearby(from.Map, from.Location))
        {
            SpawnNear(from, success, vein);
        }

        TrySpawnSkeleton(from);
    }

    public static void TryStartClearing(Mobile from, MineClutter clutter)
    {
        if (from == null || clutter?.Deleted != false || clutter.Map == null ||
            clutter.Map == Map.Internal || !from.CheckAlive())
        {
            return;
        }

        if (from.Mounted)
        {
            from.SendLocalizedMessage(501864); // You can't mine while riding.
            return;
        }

        if (Core.TickCount - from.NextActionTime < 0)
        {
            from.SendActionMessage();
            return;
        }

        if (from.Stam < _stamCost + (int)clutter.Stage)
        {
            from.SendLocalizedMessage(500110);
            return;
        }

        if (clutter.Map != from.Map || !from.InRange(clutter.GetWorldLocation(), 2))
        {
            from.SendLocalizedMessage(500446);
            return;
        }

        var tool = FindMiningTool(from);

        if (tool == null)
        {
            from.SendMessage("You need a pickaxe or shovel to break this apart.");
            return;
        }

        if (!from.BeginAction<MineClutter>())
        {
            from.SendActionMessage();
            return;
        }

        from.NextActionTime = Core.TickCount + _swingDelayMs;
        from.RevealingAction();
        Timer.DelayCall(TimeSpan.FromMilliseconds(250), Strike, from, clutter);
    }

    private static void Strike(Mobile from, MineClutter clutter)
    {
        from.EndAction<MineClutter>();

        if (from == null || clutter?.Deleted != false || from.Map == null || from.Map == Map.Internal)
        {
            return;
        }

        if (clutter.Map != from.Map || !from.InRange(clutter.GetWorldLocation(), 2))
        {
            from.SendLocalizedMessage(500446);
            return;
        }

        var tool = FindMiningTool(from);

        if (tool == null)
        {
            from.SendMessage("You need a pickaxe or shovel to break this apart.");
            return;
        }

        var stamCost = _stamCost + (int)clutter.Stage;

        if (from.Stam < stamCost)
        {
            from.SendLocalizedMessage(500110);
            return;
        }

        from.Stam -= stamCost;
        from.Animate(11, 5, 1, true, false, 0);
        Effects.PlaySound(clutter.Location, clutter.Map, Utility.Random(2) == 0 ? 0x125 : 0x126);

        if (!from.CheckSkill(SkillName.Mining, _clearMinSkill, _clearMaxSkill))
        {
            from.SendLocalizedMessage(503043);

            if (_wearOnFail)
            {
                WearTool(from, tool);
            }

            return;
        }

        WearTool(from, tool);

        if (tool.Deleted)
        {
            return;
        }

        var damage = 1;

        if (from.Str >= _strBonusThreshold)
        {
            damage++;
        }

        if (from.Skills.Mining.Base >= _miningBonusThreshold)
        {
            damage++;
        }

        clutter.HitsLeft -= damage;
        clutter.InvalidateProperties();

        if (clutter.HitsLeft > 0)
        {
            from.SendMessage($"You break off a chunk of rock. ({clutter.HitsLeft} left)");
            return;
        }

        clutter.BreakDown(from);
    }

    private static void WearTool(Mobile from, Item tool)
    {
        var broken = false;

        if (tool is BaseWeapon weapon && weapon.MaxHitPoints > 0)
        {
            if (weapon.HitPoints > 0)
            {
                --weapon.HitPoints;
            }
            else
            {
                --weapon.MaxHitPoints;
            }

            broken = weapon.MaxHitPoints <= 0;
        }
        else if (tool is IUsesRemaining uses)
        {
            if (uses.UsesRemaining > 0)
            {
                --uses.UsesRemaining;
            }

            broken = uses.UsesRemaining < 1;
        }

        if (broken)
        {
            tool.Delete();
            from.SendLocalizedMessage(1044038);
        }
    }

    private static Item FindMiningTool(Mobile from)
    {
        var held = from.FindItemOnLayer(Layer.OneHanded) ?? from.FindItemOnLayer(Layer.TwoHanded);

        if (held is BaseAxe or BaseTool or BaseHarvestTool)
        {
            return held;
        }

        var pack = from.Backpack;

        if (pack == null)
        {
            return null;
        }

        for (var i = 0; i < pack.Items.Count; i++)
        {
            var item = pack.Items[i];

            if (item is BaseAxe or BaseTool or BaseHarvestTool)
            {
                return item;
            }
        }

        return null;
    }

    private static void SpawnNear(Mobile from, bool success, HarvestVein vein)
    {
        var map = from.Map;

        foreach (var p in GetCandidateTiles(from, map))
        {
            if (HasClutter(map, p))
            {
                continue;
            }

            var oreReqSkill = vein?.PrimaryResource?.ReqSkill ?? 0.0;
            var clutter = new MineClutter(RollStage(success), from, oreReqSkill, ResolveOreHue(vein));
            clutter.MoveToWorld(p, map);

            Effects.PlaySound(p, map, Utility.Random(2) == 0 ? 0x125 : 0x126);
            from.SendMessage("You knock loose a pile of rock that crashes down nearby.");
            return;
        }
    }

    private static IEnumerable<Point3D> GetCandidateTiles(Mobile from, Map map)
    {
        var start = Utility.Random(Offsets.Length);

        for (var i = 0; i < Offsets.Length; i++)
        {
            var offset = Offsets[(start + i) % Offsets.Length];
            var x = from.X + offset.X;
            var y = from.Y + offset.Y;
            var z = map.GetAverageZ(x, y);

            if ((z - from.Z).Abs() <= 6 && map.CanSpawnMobile(x, y, z))
            {
                yield return new Point3D(x, y, z);
            }
        }
    }

    private static void TrySpawnSkeleton(Mobile from)
    {
        if (_skeletonChance <= 0.0 || Utility.RandomDouble() >= _skeletonChance)
        {
            return;
        }

        var map = from.Map;

        if (map == null || map == Map.Internal)
        {
            return;
        }

        var p = FindFreeTileNear(from, map);

        if (p == null)
        {
            return;
        }

        var rating = from.Skills.Mining.Base + from.Str * 0.5 + from.Luck * 0.25;
        var loot = new List<Item>();
        var rolls = 1 + Math.Min(2, (int)(rating / 60.0));

        for (var i = 0; i < rolls; i++)
        {
            var roll = Utility.RandomDouble();

            if (roll < 0.55)
            {
                var amount = Math.Max(1, 10 + (int)(Utility.RandomDouble() * rating * _skeletonGoldFactor));
                loot.Add(new Gold(amount));
            }
            else if (roll < 0.90)
            {
                var gemType = GemTypes[Utility.Random(GemTypes.Length)];
                Item gem = null;

                try
                {
                    gem = Activator.CreateInstance(gemType, 1) as Item;
                }
                catch
                {
                    // gem ctor without (int amount) is not supported by this shard - skip
                }

                if (gem != null)
                {
                    loot.Add(gem);
                }
            }
            else
            {
                loot.Add(new Pickaxe());
            }
        }

        var corpse = new Corpse(from, from.Hair, from.FacialHair, new List<Item>())
        {
            Name = "a long-dead miner"
        };

        for (var i = 0; i < loot.Count; i++)
        {
            corpse.DropItem(loot[i]);
        }

        corpse.MoveToWorld(p.Value, map);

        Effects.PlaySound(p.Value, map, 0x126);
        from.SendMessage("Your pick strikes something buried in the rock...");
    }

    private static Point3D? FindFreeTileNear(Mobile from, Map map)
    {
        foreach (var p in GetCandidateTiles(from, map))
        {
            return p;
        }

        return null;
    }

    private static MineClutterStage RollStage(bool success)
    {
        if (!success)
        {
            return Utility.RandomDouble() < 0.65 ? MineClutterStage.Rocks : MineClutterStage.Debris;
        }

        var roll = Utility.RandomDouble();

        if (roll < 0.18)
        {
            return MineClutterStage.LargeBoulder;
        }

        return roll < 0.65 ? MineClutterStage.Boulder : MineClutterStage.Rocks;
    }

    private static int ResolveOreHue(HarvestVein vein)
    {
        if (!_tintByOre)
        {
            return -1;
        }

        var types = vein?.PrimaryResource?.Types;

        if (types == null || types.Length == 0)
        {
            return -1;
        }

        return CraftResources.GetHue(CraftResources.GetFromType(types[0]));
    }

    private static bool HasClutter(Map map, Point3D p)
    {
        foreach (var item in map.GetItemsInRange(p, 0))
        {
            if (item is MineClutter)
            {
                return true;
            }
        }

        return false;
    }

    private static bool TooManyNearby(Map map, Point3D p)
    {
        var count = 0;

        foreach (var item in map.GetItemsInRange(p, _areaRange))
        {
            if (item is MineClutter && ++count >= _maxPerArea)
            {
                return true;
            }
        }

        return false;
    }

    [Usage("ClearAllMineClutter")]
    [Description("Deletes all mine clutter on all maps.")]
    [Aliases("clearallclutter")]
    private static void ClearAllMineClutter(CommandEventArgs e)
    {
        var snapshot = new List<MineClutter>(_active);

        for (var i = 0; i < snapshot.Count; i++)
        {
            snapshot[i].Delete();
        }

        e.Mobile.SendMessage($"Removed {snapshot.Count} mine clutter item(s) on all maps.");
    }

    [Usage("ClearMineClutter [radius]")]
    [Description("Deletes mine clutter around you.")]
    [Aliases("clrrocks")]
    private static void ClearMineClutter(CommandEventArgs e)
    {
        var from = e.Mobile;

        if (from.Map == null || from.Map == Map.Internal)
        {
            from.SendMessage("You must be in the world to clear mine clutter.");
            return;
        }

        var radius = e.Length > 0 ? Math.Clamp(e.GetInt32(0), 1, 50) : 8;
        var toDelete = new List<MineClutter>();

        foreach (var item in from.Map.GetItemsInRange(from.Location, radius))
        {
            if (item is MineClutter clutter)
            {
                toDelete.Add(clutter);
            }
        }

        for (var i = 0; i < toDelete.Count; i++)
        {
            toDelete[i].Delete();
        }

        from.SendMessage($"Removed {toDelete.Count} mine clutter item(s) within {radius} tiles.");
    }
}
