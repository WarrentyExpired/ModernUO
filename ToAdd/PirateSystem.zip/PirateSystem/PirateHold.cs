using System;
using ModernUO.Serialization;
using Server.Multis;

namespace Server.Items;

[SerializationGenerator(2, false)]
public partial class PirateHold : Hold
{
    [SerializableField(0)]
    [DeltaDateTime]
    private DateTime _publicUntilUtc;

    public PirateHold(BaseBoat boat) : base(boat)
    {
        Name = "Pirate Hold";
    }

    [CommandProperty(AccessLevel.GameMaster)]
    public bool IsPublic => DateTime.UtcNow <= _publicUntilUtc;

    public void SetPublicFor(TimeSpan duration)
    {
        _publicUntilUtc = DateTime.UtcNow + duration;
        InvalidateProperties();

        var minutes = Math.Max(1, (int)Math.Ceiling(duration.TotalMinutes));
        var map = Map;
        if (map == null || map == Map.Internal)
        {
            return;
        }

        foreach (var m in map.GetMobilesInRange(Location, 16))
        {
            m.SendMessage($"The pirate hold is open for {minutes} minute{(minutes == 1 ? "" : "s")}. Loot quickly!");
        }
    }

    private bool CanAccess(Mobile from) =>
        from.AccessLevel >= AccessLevel.GameMaster ||
        IsPublic ||
        from is Server.Mobiles.NPirateCrew or Server.Mobiles.NPirateCaptain;

    public override void OnDoubleClick(Mobile from)
    {
        if (!CanAccess(from))
        {
            from.SendMessage("The pirate hold is secured and cannot be opened.");
            return;
        }

        base.OnDoubleClick(from);
    }

    public override bool TryDropItem(Mobile from, Item dropped, bool sendFullMessage)
    {
        if (CanAccess(from))
        {
            return base.TryDropItem(from, dropped, sendFullMessage);
        }

        if (sendFullMessage)
        {
            from.SendMessage("You cannot place items into the pirate hold.");
        }

        return false;
    }

    private void Deserialize(IGenericReader reader, int version)
    {
        if (version >= 1)
        {
            _publicUntilUtc = reader.ReadDeltaTime();
        }
    }

    public override void OnAfterDelete()
    {
    }
}
