using System;
using System.Collections.Generic;
using System.IO;
using Server.Collections;
using Server.Items;
using Server.Json;
using Server.Logging;
using Server.Multis;

namespace Server.Mobiles;

public static class PirateCaptureRegistry
{
    private static readonly ILogger logger = LogFactory.GetLogger(typeof(PirateCaptureRegistry));

    private sealed class CaptureEntry
    {
        public uint BoatSerial { get; set; }
        public DateTime UntilUtc { get; set; }
    }

    private static readonly Dictionary<uint, DateTime> _captures = [];
    private static readonly Dictionary<uint, DateTime> _cooldowns = [];
    private static readonly Dictionary<uint, Timer> _warningTimers = [];
    private static readonly Dictionary<uint, Timer> _sinkTimers = [];
    private static readonly List<uint> _pendingRemoval = [];
    private static readonly List<uint> _pendingCooldownRemoval = [];

    private static readonly string CapturesPath = Path.Combine(Core.BaseDirectory, "Configuration", "PirateSystem", "captures.json");

    public static void Configure()
    {
        EventSink.WorldSave += SaveCaptures;
        EventSink.WorldLoad += LoadCaptures;

        var interval = TimeSpan.FromSeconds(Math.Max(1, PirateConfig.Current.CaptureEnforceIntervalSeconds));
        Timer.StartTimer(interval, interval, Enforce);
    }

    public static bool IsCaptured(Serial serial) =>
        _captures.TryGetValue(serial.Value, out var until) && until > DateTime.UtcNow;

    public static bool IsOnCooldown(Serial serial) =>
        _cooldowns.TryGetValue(serial.Value, out var until) && until > DateTime.UtcNow;

    public static void GrantImmunity(Serial serial, TimeSpan duration) => SetCooldown(serial, duration);

    public static void SetCooldown(Serial serial, TimeSpan duration)
    {
        var until = DateTime.UtcNow + duration;
        if (!_cooldowns.TryGetValue(serial.Value, out var existing) || until > existing)
        {
            _cooldowns[serial.Value] = until;
        }
    }

    public static bool RegisterCapture(BaseBoat boat, DateTime untilUtc)
    {
        if (boat?.Deleted != false)
        {
            return false;
        }

        var serial = boat.Serial.Value;
        var now = DateTime.UtcNow;
        if (untilUtc <= now)
        {
            untilUtc = now + TimeSpan.FromSeconds(1);
        }

        if (!_captures.ContainsKey(serial) && _captures.Count >= PirateConfig.Current.MaxConcurrentCaptures)
        {
            logger.Warning($"Pirate capture cap reached — sinking boat {serial} immediately");
            ScheduleSink(boat, now);
            return false;
        }

        _captures[serial] = untilUtc;
        StopBoat(boat);
        ScheduleWarnings(boat, untilUtc);
        ScheduleSink(boat, untilUtc);
        logger.Debug($"Registered captured boat {serial} until {untilUtc:O}");
        return true;
    }

    public static void Unregister(Serial serial) => Unregister(serial.Value);

    public static void Unregister(uint serial)
    {
        _captures.Remove(serial);
        StopWarning(serial);

        if (_sinkTimers.Remove(serial, out var sink))
        {
            sink.Stop();
        }

        SetCooldown((Serial)serial, TimeSpan.FromMinutes(PirateConfig.Current.Ransom.CooldownMinutes));
    }

    private static void StopBoat(BaseBoat boat)
    {
        boat.StopMove(false);
        boat.LowerAnchor(false);

        if (boat.Owner != null)
        {
            boat.RemoveKeys(boat.Owner);
        }
    }

    private static void Enforce()
    {
        var now = DateTime.UtcNow;
        _pendingRemoval.Clear();
        _pendingCooldownRemoval.Clear();

        foreach (var kv in _captures)
        {
            if (kv.Value <= now)
            {
                _pendingRemoval.Add(kv.Key);
                continue;
            }

            if (World.FindItem((Serial)kv.Key) is BaseBoat { Deleted: false } boat)
            {
                StopBoat(boat);
            }
        }

        foreach (var kv in _cooldowns)
        {
            if (kv.Value <= now)
            {
                _pendingCooldownRemoval.Add(kv.Key);
            }
        }

        foreach (var serial in _pendingRemoval)
        {
            _captures.Remove(serial);
            StopWarning(serial);
        }

        foreach (var serial in _pendingCooldownRemoval)
        {
            _cooldowns.Remove(serial);
        }
    }

    private static void ScheduleWarnings(BaseBoat boat, DateTime untilUtc)
    {
        var serial = boat.Serial.Value;
        StopWarning(serial);

        var interval = TimeSpan.FromSeconds(Math.Max(5, PirateConfig.Current.SinkWarningIntervalSeconds));
        var timer = new WarningTimer(boat, untilUtc, interval);
        timer.Start();
        _warningTimers[serial] = timer;
    }

    private static void StopWarning(uint serial)
    {
        if (_warningTimers.Remove(serial, out var timer))
        {
            timer.Stop();
        }
    }

    private static void ScheduleSink(BaseBoat boat, DateTime untilUtc)
    {
        var serial = boat.Serial.Value;

        if (_sinkTimers.Remove(serial, out var old))
        {
            old.Stop();
        }

        var delay = untilUtc - DateTime.UtcNow;
        if (delay < TimeSpan.Zero)
        {
            delay = TimeSpan.Zero;
        }

        var timer = new SinkTimer(boat, delay);
        timer.Start();
        _sinkTimers[serial] = timer;
    }

    private static void SaveCaptures()
    {
        try
        {
            var now = DateTime.UtcNow;
            var entries = new List<CaptureEntry>();

            foreach (var kv in _captures)
            {
                if (kv.Value > now)
                {
                    entries.Add(new CaptureEntry { BoatSerial = kv.Key, UntilUtc = kv.Value });
                }
            }

            var dir = Path.GetDirectoryName(CapturesPath);
            if (!string.IsNullOrEmpty(dir))
            {
                Directory.CreateDirectory(dir);
            }

            JsonConfig.Serialize(CapturesPath, entries);
        }
        catch (Exception ex)
        {
            logger.Error($"Saving pirate captures failed: {ex}");
        }
    }

    private static void LoadCaptures()
    {
        try
        {
            if (!File.Exists(CapturesPath))
            {
                return;
            }

            var entries = JsonConfig.Deserialize<List<CaptureEntry>>(CapturesPath);
            if (entries == null)
            {
                return;
            }

            foreach (var entry in entries)
            {
                if (World.FindItem((Serial)entry.BoatSerial) is not BaseBoat { Deleted: false } boat)
                {
                    continue;
                }

                if (entry.UntilUtc - DateTime.UtcNow <= TimeSpan.Zero)
                {
                    ScheduleSink(boat, DateTime.UtcNow);
                }
                else
                {
                    _captures[entry.BoatSerial] = entry.UntilUtc;
                    ScheduleWarnings(boat, entry.UntilUtc);
                    ScheduleSink(boat, entry.UntilUtc);
                }
            }
        }
        catch (Exception ex)
        {
            logger.Error($"Loading pirate captures failed: {ex}");
        }
    }

    private class WarningTimer : Timer
    {
        private readonly BaseBoat _boat;
        private readonly DateTime _endUtc;

        public WarningTimer(BaseBoat boat, DateTime endUtc, TimeSpan interval) : base(TimeSpan.Zero, interval)
        {
            _boat = boat;
            _endUtc = endUtc;
        }

        protected override void OnTick()
        {
            if (_boat.Deleted || DateTime.UtcNow >= _endUtc)
            {
                Stop();
                return;
            }

            var cfg = PirateConfig.Current;
            var remaining = _endUtc - DateTime.UtcNow;
            string msg;

            if (remaining.TotalSeconds < 60)
            {
                var sec = Math.Max(1, (int)Math.Ceiling(remaining.TotalSeconds));
                msg = $"This ship will sink in {sec} second{(sec == 1 ? "" : "s")}.";
            }
            else
            {
                var min = (int)Math.Ceiling(remaining.TotalMinutes);
                msg = string.Format(cfg.SinkWarningTemplate, min, min == 1 ? "" : "s");
            }

            foreach (var m in _boat.GetMobilesInRange(16))
            {
                m.SendMessage(cfg.SinkWarningHue, msg);
            }
        }
    }

    private class SinkTimer : Timer
    {
        private readonly BaseBoat _boat;
        private int _step;

        public SinkTimer(BaseBoat boat, TimeSpan delay) : base(delay, TimeSpan.FromSeconds(2.0))
        {
            _boat = boat;
        }

        protected override void OnTick()
        {
            var boat = _boat;
            if (boat.Deleted || boat.Map == null || boat.Map == Map.Internal)
            {
                Unregister(boat.Serial.Value);
                Stop();
                return;
            }

            if (_step < 5)
            {
                boat.Location = new Point3D(boat.X, boat.Y, boat.Z - 1);
                boat.TillerMan?.Say(1007168 + _step);
                _step++;
                return;
            }

            Finish(boat);
            Unregister(boat.Serial.Value);
            Stop();
        }

        private static void Finish(BaseBoat boat)
        {
            var cfg = PirateConfig.Current;
            var hold = PirateBoatHelpers.GetBoatHold(boat);

            using var players = PooledRefList<PlayerMobile>.Create();
            foreach (var m in boat.GetMobilesInRange(16))
            {
                if (m is PlayerMobile pm && boat.Contains(pm.X, pm.Y))
                {
                    players.Add(pm);
                }
            }

            foreach (var pm in players)
            {
                if (hold?.Deleted == false)
                {
                    PirateBoatHelpers.MovePlayerItems(pm, hold);
                }

                if (cfg.TeleportOnSink)
                {
                    PirateBoatHelpers.TeleportToNearestShore(pm);
                }
            }

            if (cfg.RemoveCorpsesOnSink)
            {
                var delay = TimeSpan.FromMinutes(cfg.CorpseSinkDelayMinutes);
                var interval = TimeSpan.FromSeconds(Math.Max(1, cfg.CorpseSinkAnimateIntervalSeconds));

                foreach (var item in boat.GetItemsInRange(16))
                {
                    if (item is Corpse corpse && !corpse.Deleted)
                    {
                        new CorpseSinkTimer(corpse, delay, Math.Max(1, cfg.CorpseSinkAnimateSteps), interval).Start();
                    }
                }
            }

            PirateBoatHelpers.ExtractHoldItems(boat);
            boat.Delete();
            PirateSystem.Log("SINK", boat, null);
            logger.Debug($"Sunk captured boat {boat.Serial.Value}");
        }
    }

    private class CorpseSinkTimer : Timer
    {
        private readonly Corpse _corpse;
        private readonly int _steps;
        private int _step;

        public CorpseSinkTimer(Corpse corpse, TimeSpan delay, int steps, TimeSpan interval) : base(delay, interval)
        {
            _corpse = corpse;
            _steps = steps;
        }

        protected override void OnTick()
        {
            if (_corpse.Deleted)
            {
                Stop();
                return;
            }

            if (_step < _steps)
            {
                _corpse.Z -= 1;
                _step++;
                return;
            }

            var map = _corpse.Map;
            var loc = _corpse.Location;

            using var items = PooledRefList<Item>.Create();
            foreach (var it in _corpse.Items)
            {
                if (!it.Deleted)
                {
                    items.Add(it);
                }
            }

            if (map != null && map != Map.Internal)
            {
                foreach (var it in items)
                {
                    if (it.Parent is Container parent)
                    {
                        parent.RemoveItem(it);
                    }

                    it.MoveToWorld(loc, map);
                }
            }
            else
            {
                foreach (var it in items)
                {
                    it.Delete();
                }
            }

            _corpse.Delete();
            Stop();
        }
    }
}
