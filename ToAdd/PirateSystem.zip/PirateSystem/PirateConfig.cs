using System;
using System.IO;
using Server.Json;

namespace Server.Mobiles;

public class PirateConfig
{
    public static readonly string ConfigPath = Path.Combine(Core.BaseDirectory, "Configuration", "PirateSystem", "config.json");

    public bool Enabled { get; set; } = true;

    public string SpeechFilePath { get; set; } = Path.Combine(Core.BaseDirectory, "Data", "The Pirate Captain", "Speech.txt");
    public string PhrasesPath { get; set; } = Path.Combine(Core.BaseDirectory, "Data", "The Pirate Captain", "phrases.json");

    public int SpeechIntervalMin { get; set; } = 4;
    public int SpeechIntervalMax { get; set; } = 6;
    public double EmoteProbability { get; set; } = 0.05;

    public int SearchIntervalMin { get; set; } = 1;
    public int SearchIntervalMax { get; set; } = 2;
    public int SearchRadius { get; set; } = 100;
    public int AttackStopRange { get; set; } = 10;
    public int BoardingDistance { get; set; } = 3;

    public int ShipZ { get; set; } = -5;
    public int NumCrew { get; set; } = 5;
    public int NumCrewMax { get; set; } = 10;
    public int NumLooters { get; set; } = 3;
    public int MinLooters { get; set; } = 1;
    public int MaxLooters { get; set; } = 8;
    public double LooterWarriorChance { get; set; } = 0.5;
    public double LooterArcherChance { get; set; } = 0.35;
    public double LooterMageChance { get; set; } = 0.15;

    public int SinkDelayMinutes { get; set; } = 5;
    public int MaxConcurrentCaptures { get; set; } = 20;
    public int CaptureEnforceIntervalSeconds { get; set; } = 3;
    public int SinkWarningIntervalSeconds { get; set; } = 30;
    public int SinkWarningHue { get; set; } = 0x22;
    public string SinkWarningTemplate { get; set; } = "This ship will sink in {0} minute{1}.";

    public bool LootPlayerCorpse { get; set; } = true;
    public bool LootPlayerHold { get; set; } = true;
    public bool TeleportOnSink { get; set; } = true;
    public bool MoveEquippedItemsToHold { get; set; }

    public bool RemoveCorpsesOnSink { get; set; } = true;
    public int CorpseSinkDelayMinutes { get; set; } = 2;
    public int CorpseSinkAnimateSteps { get; set; } = 5;
    public int CorpseSinkAnimateIntervalSeconds { get; set; } = 2;

    public string BoardingMessage { get; set; } = "Boarding! Take that ship!";

    public bool CaptainSpawnEnabled { get; set; } = true;
    public int CaptainSpawnIntervalMinMinutes { get; set; } = 30;
    public int CaptainSpawnIntervalMaxMinutes { get; set; } = 60;
    public int CaptainSpawnMaxPerMap { get; set; } = 2;

    public RansomOptions Ransom { get; set; } = new();
    public CombatOptions Combat { get; set; } = new();
    public BountyOptions Bounty { get; set; } = new();
    public JettisonOptions Jettison { get; set; } = new();
    public MoraleOptions Morale { get; set; } = new();
    public BoatWeightsOptions BoatWeights { get; set; } = new();

    public static PirateConfig Current { get; private set; } = new();

    public static TimeSpan SinkDelay => TimeSpan.FromMinutes(Math.Max(1, Current.SinkDelayMinutes));

    public static void Load()
    {
        if (!File.Exists(ConfigPath))
        {
            Save();
        }

        Current = JsonConfig.Deserialize<PirateConfig>(ConfigPath) ?? new PirateConfig();
    }

    public static void Save()
    {
        var dir = Path.GetDirectoryName(ConfigPath);
        if (!string.IsNullOrEmpty(dir))
        {
            Directory.CreateDirectory(dir);
        }

        JsonConfig.Serialize(ConfigPath, new PirateConfig());
    }

    public class RansomOptions
    {
        public bool Enabled { get; set; } = true;
        public int TimeoutSeconds { get; set; } = 45;
        public int SmallBase { get; set; } = 500;
        public int MediumBase { get; set; } = 1500;
        public int LargeBase { get; set; } = 3000;
        public int PirateShipBase { get; set; } = 5000;
        public double HoldValuePercent { get; set; } = 0.10;
        public int PerPlayerBonus { get; set; } = 250;
        public int CooldownMinutes { get; set; } = 30;
        public int ImmunityAfterRansomMinutes { get; set; } = 10;
        public int MinShoreDistance { get; set; } = 15;
        public bool SkipYoungPlayers { get; set; } = true;
        public double SkipBelowTotalSkills { get; set; } = 300.0;
    }

    public class CombatOptions
    {
        public double RetreatHealthPercent { get; set; } = 0.28;
        public double ReinforceHealthPercent { get; set; } = 0.5;
    }

    public class BountyOptions
    {
        public bool Enabled { get; set; } = true;
        public int TokenGoldReward { get; set; } = 1500;
        public int TokenHue { get; set; } = 1157;
    }

    public class JettisonOptions
    {
        public bool Enabled { get; set; } = true;
        public int MaxPercent { get; set; } = 50;
        public int Steps { get; set; } = 2;
        public bool PiratesCollect { get; set; } = true;
        public int SalvageDelaySeconds { get; set; } = 45;
    }

    public class MoraleOptions
    {
        public double DesertionChance { get; set; } = 0.35;
    }

    public class BoatWeightsOptions
    {
        public int NPirateShip { get; set; } = 40;
        public int LargeDragonBoat { get; set; } = 20;
        public int LargeBoat { get; set; } = 15;
        public int MediumDragonBoat { get; set; } = 8;
        public int MediumBoat { get; set; } = 6;
        public int SmallDragonBoat { get; set; } = 6;
        public int SmallBoat { get; set; } = 5;
    }
}
