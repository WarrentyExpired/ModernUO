using System;
using System.Collections.Generic;
using Server.Collections;
using Server.Items;
using Server.Multis;

namespace Server.Mobiles;

public static class PirateBoatHelpers
{
    public static Container GetBoatHold(BaseBoat boat)
    {
        var hold = boat.Hold;
        if (hold?.Deleted == false && hold.Map != null && hold.Map != Map.Internal)
        {
            foreach (var item in hold.Map.GetItemsInRange(hold.Location, 0))
            {
                if (item is PirateHold pirateHold)
                {
                    return pirateHold;
                }
            }
        }

        return hold?.Deleted == false ? hold : null;
    }

    public static int CountPiratesNear(BaseBoat boat)
    {
        var count = 0;
        foreach (var m in boat.GetMobilesInRange(16))
        {
            if (m is NPirateCrew or NPirateCaptain && m.Alive)
            {
                count++;
            }
        }

        return count;
    }

    public static bool IsNearShore(BaseBoat boat, int distance)
    {
        var map = boat.Map;
        if (map == null || map == Map.Internal)
        {
            return false;
        }

        for (var dx = -distance; dx <= distance; dx += 3)
        {
            for (var dy = -distance; dy <= distance; dy += 3)
            {
                var land = map.Tiles.GetLandTile(boat.X + dx, boat.Y + dy);
                if (land.Ignored)
                {
                    continue;
                }

                var flags = TileData.LandTable[land.ID].Flags;
                if ((flags & (TileFlag.Impassable | TileFlag.Wet)) == 0)
                {
                    return true;
                }
            }
        }

        return false;
    }

    public static bool TryMakeLootable(BaseBoat boat)
    {
        if (boat?.Deleted != false || PirateCaptureRegistry.IsCaptured(boat.Serial))
        {
            return false;
        }

        if (CountPiratesNear(boat) > 0)
        {
            return false;
        }

        boat.PPlank?.Open();
        boat.SPlank?.Open();

        if (GetBoatHold(boat) is PirateHold pirateHold)
        {
            pirateHold.SetPublicFor(PirateConfig.SinkDelay);
        }

        PirateCaptureRegistry.RegisterCapture(boat, DateTime.UtcNow + PirateConfig.SinkDelay);
        return true;
    }

    public static void TransferItems(Container src, Container dest)
    {
        if (src?.Deleted != false || dest?.Deleted != false)
        {
            return;
        }

        using var items = PooledRefList<Item>.Create();
        foreach (var it in src.Items)
        {
            if (!it.Deleted)
            {
                items.Add(it);
            }
        }

        foreach (var it in items)
        {
            if (it.Parent is Container parent)
            {
                parent.RemoveItem(it);
            }
            else if (it.Parent is Mobile mobile)
            {
                mobile.RemoveItem(it);
            }

            dest.DropItem(it);
        }
    }

    public static void MovePlayerItems(PlayerMobile pm, Container dest)
    {
        var backpack = pm.Backpack;
        if (backpack != null)
        {
            TransferItems(backpack, dest);
        }

        if (!PirateConfig.Current.MoveEquippedItemsToHold)
        {
            return;
        }

        using var equipped = PooledRefList<Item>.Create();
        foreach (var it in pm.Items)
        {
            if (it != backpack && it is not BankBox && !it.Deleted)
            {
                equipped.Add(it);
            }
        }

        foreach (var it in equipped)
        {
            pm.RemoveItem(it);
            dest.DropItem(it);
        }
    }

    public static void ExtractHoldItems(BaseBoat boat)
    {
        var map = boat.Map;
        if (map == null || map == Map.Internal)
        {
            return;
        }

        var loc = boat.Location;
        var hold = GetBoatHold(boat);
        if (hold?.Deleted == false)
        {
            ExtractContainerItems(hold, loc, map);
        }

        var regular = boat.Hold;
        if (regular?.Deleted == false && !ReferenceEquals(regular, hold))
        {
            ExtractContainerItems(regular, loc, map);
        }
    }

    private static void ExtractContainerItems(Container container, Point3D loc, Map map)
    {
        using var items = PooledRefList<Item>.Create();
        foreach (var it in container.Items)
        {
            if (!it.Deleted)
            {
                items.Add(it);
            }
        }

        foreach (var it in items)
        {
            if (it.Parent is Container parent)
            {
                parent.RemoveItem(it);
            }

            it.MoveToWorld(loc, map);
        }
    }

    public static void TeleportToNearestShore(Mobile m)
    {
        var map = m.Map;
        if (map == null || map == Map.Internal)
        {
            return;
        }

        for (var r = 1; r <= 150; r += 2)
        {
            for (var dx = -r; dx <= r; dx++)
            {
                for (var dy = -r; dy <= r; dy++)
                {
                    if (Math.Abs(dx) != r && Math.Abs(dy) != r)
                    {
                        continue;
                    }

                    var x = m.X + dx;
                    var y = m.Y + dy;
                    var land = map.Tiles.GetLandTile(x, y);
                    if (land.Ignored)
                    {
                        continue;
                    }

                    var flags = TileData.LandTable[land.ID].Flags;
                    if ((flags & (TileFlag.Impassable | TileFlag.Wet)) != 0)
                    {
                        continue;
                    }

                    var z = map.GetAverageZ(x, y);
                    if (map.CanFit(x, y, z, 16, false, false))
                    {
                        m.Location = new Point3D(x, y, z);
                        return;
                    }
                }
            }
        }
    }
}
