using System;
using System.Collections.Generic;
using Server.Collections;
using Server.Commands;
using Server.Gumps;
using Server.Items;
using Server.Multis;
using Server.Network;

namespace Server.Mobiles;

public static class PirateGumpHelpers
{
    public const int HueYellow = 2213;
    public const int HueWhite = 2036;
    public const int HueRed = 1258;
    public const int HueGrey = 2401;
    public const int HueGreen = 1270;

    public static string Center(string color, string text) => $"<CENTER><BASEFONT COLOR={color}>{text}</BASEFONT></CENTER>";

    public static void AddPanel(ref DynamicGumpBuilder builder, int w, int h)
    {
        builder.AddBackground(0, 0, w, h, 2620);
        builder.AddImageTiled(10, 10, w - 20, h - 20, 2624);
        builder.AddAlphaRegion(10, 10, w - 20, h - 20);
    }
}

public static class PirateAdminController
{
    private const int CacheSeconds = 3;

    public sealed class BoatInfo
    {
        public BaseBoat Boat;
        public int Pirates;
        public int HoldItems;
    }

    private static List<BoatInfo> _cache = [];
    private static DateTime _cacheUntil;

    [Usage("PirateAdmin")]
    [Description("Opens the pirate ship administration interface.")]
    public static void OnCommand(CommandEventArgs e)
    {
        var from = e.Mobile;
        if (!from.Alive)
        {
            from.SendMessage("You must be alive to use this interface.");
            return;
        }

        from.SendGump(new PirateAdminGump(CollectBoats()));
    }

    public static List<BoatInfo> CollectBoats()
    {
        var now = DateTime.UtcNow;
        if (now < _cacheUntil)
        {
            return _cache;
        }

        _cacheUntil = now + TimeSpan.FromSeconds(CacheSeconds);

        _cache = [];
        foreach (var boat in BaseBoat.Boats)
        {
            if (boat?.Deleted != false)
            {
                continue;
            }

            var pirates = PirateBoatHelpers.CountPiratesNear(boat);
            if (boat is NPirateShip || pirates > 0)
            {
                _cache.Add(new BoatInfo
                {
                    Boat = boat,
                    Pirates = pirates,
                    HoldItems = PirateBoatHelpers.GetBoatHold(boat)?.Items.Count ?? 0
                });
            }
        }

        _cache.Sort(static (a, b) =>
        {
            var cmp = string.CompareOrdinal(a.Boat.Map?.Name, b.Boat.Map?.Name);
            return cmp != 0 ? cmp : a.Boat.X != b.Boat.X ? a.Boat.X.CompareTo(b.Boat.X) : a.Boat.Y.CompareTo(b.Boat.Y);
        });

        return _cache;
    }

    public static void HandleAction(Mobile from, int index, int action, int page)
    {
        var boats = CollectBoats();
        if ((uint)index >= (uint)boats.Count)
        {
            from.SendMessage("Entry is out of date. Refreshing list.");
            from.SendGump(new PirateAdminGump(boats, 0));
            return;
        }

        var boat = boats[index].Boat;
        switch (action)
        {
            case 0:
                TeleportTo(from, boat);
                break;
            case 1:
                ShowHold(from, boat);
                break;
            case 2:
                from.SendGump(new ConfirmDeleteGump(boat.Serial));
                return;
        }

        from.SendGump(new PirateAdminGump(CollectBoats(), page));
    }

    private static void TeleportTo(Mobile from, BaseBoat boat)
    {
        var dest = boat.GetMarkedLocation();
        var map = boat.Map ?? from.Map;
        var z = dest.Z;

        for (var dz = 0; dz <= 6; dz++)
        {
            if (map.CanFit(dest.X, dest.Y, dest.Z + dz, 16, false, false))
            {
                z = dest.Z + dz;
                break;
            }

            if (map.CanFit(dest.X, dest.Y, dest.Z - dz, 16, false, false))
            {
                z = dest.Z - dz;
                break;
            }
        }

        from.Map = map;
        from.Location = new Point3D(dest.X, dest.Y, z);
        from.SendMessage($"Teleported to boat {boat.Serial}.");
    }

    private static void ShowHold(Mobile from, BaseBoat boat)
    {
        var hold = PirateBoatHelpers.GetBoatHold(boat);
        if (hold == null)
        {
            from.SendMessage("No hold found for this boat.");
            return;
        }

        from.SendGump(new HoldContentsGump(boat, hold));
    }

    public static void DeleteBoat(Mobile from, Serial serial)
    {
        if (World.FindItem(serial) is not BaseBoat { Deleted: false } boat)
        {
            from.SendMessage("Boat not found or already deleted.");
            return;
        }

        PirateCaptureRegistry.Unregister(boat.Serial);
        PirateBoatHelpers.ExtractHoldItems(boat);
        PirateSystem.Log("ADMIN_DELETE", boat, from);

        if (PirateBoatHelpers.GetBoatHold(boat) is PirateHold pirateHold)
        {
            pirateHold.Delete();
        }

        using var pirates = PooledRefList<Mobile>.Create();
        foreach (var m in boat.GetMobilesInRange(16))
        {
            if (m is NPirateCrew or NPirateCaptain && m.Alive)
            {
                pirates.Add(m);
            }
        }

        foreach (var pirate in pirates)
        {
            pirate.Kill();
        }

        using var corpses = PooledRefList<Corpse>.Create();
        foreach (var item in boat.GetItemsInRange(16))
        {
            if (item is Corpse corpse && !corpse.Deleted)
            {
                corpses.Add(corpse);
            }
        }

        boat.Delete();

        foreach (var corpse in corpses)
        {
            corpse.Delete();
        }

        from.SendMessage($"Boat {serial} and all pirate remains deleted.");
    }
}

public class PirateAdminGump : DynamicGump
{
    private const int PageSize = 10;
    private const int RowBase = 100;
    private const int PageBase = 9000;
    private const int BtnRefresh = 9500;

    private const int W = 860;
    private const int H = 400;

    private readonly List<PirateAdminController.BoatInfo> _boats;
    private readonly int _page;

    public override bool Singleton => true;

    public PirateAdminGump(List<PirateAdminController.BoatInfo> boats, int page = 0) : base(0, 0)
    {
        _boats = boats;
        _page = Math.Max(0, page);
    }

    protected override void BuildLayout(ref DynamicGumpBuilder builder)
    {
        builder.AddPage();
        PirateGumpHelpers.AddPanel(ref builder, W, H);

        builder.AddHtml(W / 2 - 200, 18, 400, 24, PirateGumpHelpers.Center("#FFCC00", $"Pirate Admin — {_boats.Count} boat{(_boats.Count == 1 ? "" : "s")}"));

        builder.AddButton(W - 150, 16, 4023, 4024, BtnRefresh);
        builder.AddLabel(W - 112, 18, PirateGumpHelpers.HueWhite, "Refresh");

        builder.AddImageTiled(20, 48, W - 40, 2, 96);

        builder.AddLabel(25, 58, PirateGumpHelpers.HueYellow, "Index");
        builder.AddLabel(75, 58, PirateGumpHelpers.HueYellow, "Serial");
        builder.AddLabel(185, 58, PirateGumpHelpers.HueYellow, "Coords");
        builder.AddLabel(300, 58, PirateGumpHelpers.HueYellow, "Map");
        builder.AddLabel(375, 58, PirateGumpHelpers.HueYellow, "Pirates");
        builder.AddLabel(445, 58, PirateGumpHelpers.HueYellow, "Captured");
        builder.AddLabel(525, 58, PirateGumpHelpers.HueYellow, "Hold items");
        builder.AddLabel(625, 58, PirateGumpHelpers.HueYellow, "Actions");

        var totalPages = Math.Max(1, (_boats.Count + PageSize - 1) / PageSize);
        var pageIndex = Math.Min(_page, totalPages - 1);

        var start = pageIndex * PageSize;
        for (var i = 0; i < PageSize; i++)
        {
            var idx = start + i;
            if (idx >= _boats.Count)
            {
                break;
            }

            var info = _boats[idx];
            var boat = info.Boat;
            var y = 85 + i * 26;
            var captured = PirateCaptureRegistry.IsCaptured(boat.Serial);

            builder.AddLabel(25, y, PirateGumpHelpers.HueWhite, (idx + 1).ToString());
            builder.AddLabel(75, y, PirateGumpHelpers.HueWhite, boat.Serial.ToString());
            builder.AddLabel(185, y, PirateGumpHelpers.HueWhite, $"{boat.X}, {boat.Y}, {boat.Z}");
            builder.AddLabel(300, y, PirateGumpHelpers.HueWhite, boat.Map?.Name ?? "Unknown");
            builder.AddLabel(375, y, PirateGumpHelpers.HueWhite, info.Pirates.ToString());
            builder.AddLabel(445, y, captured ? PirateGumpHelpers.HueRed : PirateGumpHelpers.HueGrey, captured ? "Yes" : "No");
            builder.AddLabel(525, y, PirateGumpHelpers.HueWhite, info.HoldItems.ToString());

            var row = RowBase + i * 3;
            builder.AddButton(625, y - 2, 4005, 4007, row);
            builder.AddLabel(665, y, PirateGumpHelpers.HueWhite, "TP");
            builder.AddButton(707, y - 2, 4005, 4007, row + 1);
            builder.AddLabel(747, y, PirateGumpHelpers.HueWhite, "Hold");
            builder.AddButton(785, y - 2, 4005, 4007, row + 2);
            builder.AddLabel(825, y, PirateGumpHelpers.HueRed, "Del");
        }

        builder.AddImageTiled(20, 352, W - 40, 2, 96);

        builder.AddLabel(25, 365, PirateGumpHelpers.HueWhite, $"Page {pageIndex + 1} / {totalPages}");
        if (pageIndex > 0)
        {
            builder.AddButton(200, 363, 4014, 4016, PageBase + pageIndex - 1);
        }

        if (pageIndex < totalPages - 1)
        {
            builder.AddButton(240, 363, 4015, 4017, PageBase + pageIndex + 1);
        }

        builder.AddButton(W - 150, 363, 4005, 4007, 0);
        builder.AddLabel(W - 112, 365, PirateGumpHelpers.HueWhite, "Close");
    }

    public override void OnResponse(NetState sender, in RelayInfo info)
    {
        var from = sender.Mobile;
        if (from == null || from.AccessLevel < AccessLevel.GameMaster)
        {
            return;
        }

        var btn = info.ButtonID;
        if (btn == 0)
        {
            return;
        }

        if (btn == BtnRefresh)
        {
            from.SendGump(new PirateAdminGump(PirateAdminController.CollectBoats(), _page));
            return;
        }

        if (btn >= PageBase)
        {
            from.SendGump(new PirateAdminGump(PirateAdminController.CollectBoats(), btn - PageBase));
            return;
        }

        if (btn >= RowBase && btn < RowBase + PageSize * 3)
        {
            var offset = btn - RowBase;
            PirateAdminController.HandleAction(from, offset / 3, offset % 3, _page);
        }
    }
}

public class HoldContentsGump : DynamicGump
{
    private const int ItemsPerPage = 12;

    private const int W = 570;
    private const int H = 440;

    private readonly BaseBoat _boat;
    private readonly Container _hold;
    private readonly int _page;

    public override bool Singleton => true;

    public HoldContentsGump(BaseBoat boat, Container hold, int page = 0) : base(0, 0)
    {
        _boat = boat;
        _hold = hold;
        _page = Math.Max(0, page);
    }

    protected override void BuildLayout(ref DynamicGumpBuilder builder)
    {
        builder.AddPage();
        PirateGumpHelpers.AddPanel(ref builder, W, H);

        builder.AddHtml(W / 2 - 200, 18, 400, 24, PirateGumpHelpers.Center("#FFCC00", $"Hold contents — boat {_boat.Serial}"));

        builder.AddLabel(25, 48, PirateGumpHelpers.HueWhite, $"Boat {_boat.Serial} at {_boat.X}, {_boat.Y}, {_boat.Z} ({_boat.Map?.Name ?? "Unknown"})");
        builder.AddLabel(25, 66, PirateGumpHelpers.HueWhite, $"Hold {_hold.Serial} — {_hold.Items.Count} item{(_hold.Items.Count == 1 ? "" : "s")}");

        builder.AddImageTiled(20, 90, W - 40, 2, 96);

        var items = _hold.Items;
        var totalPages = Math.Max(1, (items.Count + ItemsPerPage - 1) / ItemsPerPage);
        var pageIndex = Math.Min(_page, totalPages - 1);

        var y = 105;
        for (var i = pageIndex * ItemsPerPage; i < Math.Min((pageIndex + 1) * ItemsPerPage, items.Count); i++)
        {
            var item = items[i];
            builder.AddLabel(25, y, PirateGumpHelpers.HueWhite, $"{i + 1}. [{item.Serial}] {item.Name ?? item.GetType().Name}");
            y += 22;
        }

        builder.AddImageTiled(20, 378, W - 40, 2, 96);

        builder.AddButton(25, 395, 4005, 4007, 1);
        builder.AddLabel(65, 397, PirateGumpHelpers.HueWhite, "Teleport");

        builder.AddButton(165, 395, 4005, 4007, 2);
        builder.AddLabel(205, 397, PirateGumpHelpers.HueRed, "Dump to ground");

        if (pageIndex > 0)
        {
            builder.AddButton(345, 395, 4014, 4016, 10 + pageIndex - 1);
            builder.AddLabel(377, 397, PirateGumpHelpers.HueWhite, "Prev");
        }

        if (pageIndex < totalPages - 1)
        {
            builder.AddButton(425, 395, 4015, 4017, 10 + pageIndex + 1);
            builder.AddLabel(457, 397, PirateGumpHelpers.HueWhite, "Next");
        }

        builder.AddButton(505, 395, 4005, 4007, 0);
        builder.AddLabel(537, 397, PirateGumpHelpers.HueWhite, "Close");
    }

    public override void OnResponse(NetState sender, in RelayInfo info)
    {
        var from = sender.Mobile;
        if (from == null || from.AccessLevel < AccessLevel.GameMaster)
        {
            return;
        }

        switch (info.ButtonID)
        {
            case 1:
            {
                from.Map = _boat.Map;
                from.Location = _boat.GetMarkedLocation();
                from.SendMessage($"Teleported to boat {_boat.Serial}.");
                break;
            }
            case 2:
            {
                from.SendMessage($"Moved {DumpToGround()} items to the ground.");
                break;
            }
            default:
            {
                if (info.ButtonID >= 10)
                {
                    from.SendGump(new HoldContentsGump(_boat, _hold, info.ButtonID - 10));
                    return;
                }

                break;
            }
        }

        from.SendGump(new PirateAdminGump(PirateAdminController.CollectBoats()));
    }

    private int DumpToGround()
    {
        var map = _boat.Map;
        if (map == null || map == Map.Internal)
        {
            return 0;
        }

        var loc = _boat.Location;
        var moved = 0;

        using var items = PooledRefList<Item>.Create();
        foreach (var it in _hold.Items)
        {
            if (!it.Deleted)
            {
                items.Add(it);
            }
        }

        foreach (var it in items)
        {
            if (it.Parent is Container parent)
            {
                parent.RemoveItem(it);
            }

            it.MoveToWorld(loc, map);
            moved++;
        }

        return moved;
    }
}

public class ConfirmDeleteGump : DynamicGump
{
    private const int W = 430;
    private const int H = 200;

    private readonly Serial _boatSerial;

    public override bool Singleton => true;

    public ConfirmDeleteGump(Serial boatSerial) : base(0, 0)
    {
        _boatSerial = boatSerial;
    }

    protected override void BuildLayout(ref DynamicGumpBuilder builder)
    {
        builder.AddPage();
        PirateGumpHelpers.AddPanel(ref builder, W, H);

        builder.AddHtml(W / 2 - 150, 22, 300, 24, PirateGumpHelpers.Center("#FF6666", "Confirm deletion"));

        builder.AddLabel(30, 62, PirateGumpHelpers.HueWhite, $"Boat {_boatSerial}");
        builder.AddLabel(30, 84, PirateGumpHelpers.HueWhite, "The boat and everything on it will be");
        builder.AddLabel(30, 104, PirateGumpHelpers.HueWhite, "permanently deleted. Are you sure?");

        builder.AddButton(70, 140, 4005, 4007, 1);
        builder.AddLabel(110, 142, PirateGumpHelpers.HueRed, "Yes, delete");

        builder.AddButton(250, 140, 4005, 4007, 0);
        builder.AddLabel(290, 142, PirateGumpHelpers.HueWhite, "Cancel");
    }

    public override void OnResponse(NetState sender, in RelayInfo info)
    {
        var from = sender.Mobile;
        if (from == null || from.AccessLevel < AccessLevel.GameMaster)
        {
            return;
        }

        if (info.ButtonID == 1)
        {
            PirateAdminController.DeleteBoat(from, _boatSerial);
        }

        from.SendGump(new PirateAdminGump(PirateAdminController.CollectBoats()));
    }
}
