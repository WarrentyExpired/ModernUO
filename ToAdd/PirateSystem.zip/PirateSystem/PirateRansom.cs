using System;
using Server.Gumps;
using Server.Network;

namespace Server.Mobiles;

public class PirateRansomGump : DynamicGump
{
    private const int W = 460;

    private readonly Serial _captainSerial;
    private readonly int _amount;
    private readonly int _jettisonLeft;

    public override bool Singleton => true;

    private PirateRansomGump(Serial captainSerial, int amount, int jettisonLeft) : base(0, 0)
    {
        _captainSerial = captainSerial;
        _amount = amount;
        _jettisonLeft = jettisonLeft;
    }

    public static void DisplayTo(Mobile from, Serial captainSerial, int amount, int jettisonLeft)
    {
        if (from?.Alive != true || from.NetState == null)
        {
            return;
        }

        from.SendGump(new PirateRansomGump(captainSerial, amount, jettisonLeft));
    }

    protected override void BuildLayout(ref DynamicGumpBuilder builder)
    {
        builder.AddPage();
        PirateGumpHelpers.AddPanel(ref builder, W, _jettisonLeft > 0 ? 270 : 250);

        builder.AddHtml(W / 2 - 190, 20, 380, 24, PirateGumpHelpers.Center("#FF6666", "PIRATES DEMAND TRIBUTE"));

        builder.AddLabel(30, 60, PirateGumpHelpers.HueWhite, "The pirate captain has run down your ship and");
        builder.AddLabel(30, 80, PirateGumpHelpers.HueWhite, "demands payment. Refuse, and they will board,");
        builder.AddLabel(30, 100, PirateGumpHelpers.HueWhite, "loot everything and sink her.");

        builder.AddHtml(W / 2 - 110, 132, 220, 26, PirateGumpHelpers.Center("#FFCC00", $"{_amount:N0} gold"));

        if (_jettisonLeft > 0)
        {
            builder.AddHtml(W / 2 - 200, 162, 400, 20, PirateGumpHelpers.Center("#8f8878", $"Dump cargo overboard to lower the price ({_jettisonLeft} left)."));
            builder.AddButton(45, 205, 4005, 4007, 1);
            builder.AddLabel(83, 207, PirateGumpHelpers.HueGreen, "Pay");
            builder.AddButton(165, 205, 4005, 4007, 3);
            builder.AddLabel(203, 207, PirateGumpHelpers.HueYellow, "Jettison cargo");
            builder.AddButton(340, 205, 4005, 4007, 2);
            builder.AddLabel(378, 207, PirateGumpHelpers.HueRed, "Refuse");
        }
        else
        {
            builder.AddButton(90, 185, 4005, 4007, 1);
            builder.AddLabel(130, 187, PirateGumpHelpers.HueGreen, "Pay the ransom");
            builder.AddButton(270, 185, 4005, 4007, 2);
            builder.AddLabel(310, 187, PirateGumpHelpers.HueRed, "Refuse");
        }
    }

    public override void OnResponse(NetState sender, in RelayInfo info)
    {
        var from = sender.Mobile;
        if (from == null || World.FindMobile(_captainSerial) is not NPirateCaptain captain)
        {
            return;
        }

        switch (info.ButtonID)
        {
            case 1:
                captain.FinishRansom(from, true);
                break;
            case 2:
                captain.FinishRansom(from, false);
                break;
            case 3:
                captain.JettisonCargo(from as PlayerMobile);
                break;
        }
    }
}
