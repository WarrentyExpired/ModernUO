using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Server.Commands;
using Server.Logging;
using Server.Multis;

namespace Server.Mobiles;

public static class PirateSystem
{
    private static readonly ILogger logger = LogFactory.GetLogger(typeof(PirateSystem));

    internal static readonly string LogPath = Path.Combine(Core.BaseDirectory, "Logs", "PirateSystem.csv");

    internal static readonly HashSet<NPirateCaptain> Captains = [];

    internal static string[] SpeechLines = [];
    internal static readonly Dictionary<string, string[]> Phrases = [];

    private static DateTime _configStamp;

    public static void Configure()
    {
        PirateConfig.Load();
        LoadSpeech();
        _configStamp = File.GetLastWriteTimeUtc(PirateConfig.ConfigPath);

        PirateCaptureRegistry.Configure();
        CommandSystem.Register("PirateAdmin", AccessLevel.GameMaster, PirateAdminController.OnCommand);

        EventSink.Logout += OnLogout;
        EventSink.Speech += OnSpeech;
        Timer.StartTimer(TimeSpan.FromMinutes(1), TimeSpan.FromMinutes(1), CheckConfigReload);
        ScheduleCaptainSpawn(TimeSpan.Zero);

        var cfg = PirateConfig.Current;
        logger.Information(
            $"[PirateSystem] Initialized: ransom={(cfg.Ransom.Enabled ? "on" : "off")}, " +
            $"autoSpawn={(cfg.CaptainSpawnEnabled ? "on" : "off")}, bounty={(cfg.Bounty.Enabled ? "on" : "off")}, " +
            $"sinkDelay={cfg.SinkDelayMinutes}m, maxCaptures={cfg.MaxConcurrentCaptures}"
        );
    }

    public static string? PickPhrase(string phase) =>
        Phrases.TryGetValue(phase, out var lines) && lines.Length > 0 ? lines[Utility.Random(lines.Length)] : null;

    public static void Log(string action, BaseBoat boat, Mobile actor, int amount = 0)
    {
        try
        {
            var dir = Path.GetDirectoryName(LogPath);
            if (!string.IsNullOrEmpty(dir))
            {
                Directory.CreateDirectory(dir);
            }

            var line = $"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss};{action};{boat?.Serial.Value ?? 0};{boat?.X ?? 0};{boat?.Y ?? 0};{boat?.Map?.Name ?? "-"};{actor?.Name ?? "-"};{amount}{Environment.NewLine}";
            if (!File.Exists(LogPath))
            {
                line = "timestamp;action;boatSerial;boatX;boatY;map;actor;amount" + Environment.NewLine + line;
            }

            File.AppendAllText(LogPath, line);
        }
        catch
        {
        }
    }

    private static void OnLogout(Mobile m)
    {
        if (m is not PlayerMobile pm || pm.Map == null || pm.Map == Map.Internal)
        {
            return;
        }

        var boat = BaseBoat.FindBoatAt(pm.Location, pm.Map);
        if (boat != null && PirateCaptureRegistry.IsCaptured(boat.Serial))
        {
            Log("LOGOUT_CAPTURED", boat, pm);
        }
    }

    private static void OnSpeech(SpeechEventArgs e)
    {
        if (e.Mobile is not PlayerMobile pm || !pm.Alive)
        {
            return;
        }

        NPirateCaptain captain = null;
        foreach (var candidate in Captains)
        {
            if (!candidate.Deleted && candidate.Map == pm.Map && candidate.InRange(pm, 18))
            {
                captain = candidate;
                break;
            }
        }

        if (captain == null)
        {
            return;
        }

        var speech = e.Speech.ToLowerInvariant();
        if (MatchesAny(speech, "SurrenderKeywords"))
        {
            captain.TryParley(pm);
        }
        else if (MatchesAny(speech, "InsultKeywords"))
        {
            captain.Enrage();
        }
    }

    private static bool MatchesAny(string speech, string phase)
    {
        if (!Phrases.TryGetValue(phase, out var words) || words.Length == 0)
        {
            return false;
        }

        foreach (var word in words)
        {
            if (word.Length > 0 && speech.Contains(word, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }

    private static void CheckConfigReload()
    {
        try
        {
            var stamp = File.GetLastWriteTimeUtc(PirateConfig.ConfigPath);
            if (stamp == _configStamp)
            {
                return;
            }

            _configStamp = stamp;
            PirateConfig.Load();
            LoadSpeech();
            logger.Debug("Pirate system config reloaded");
        }
        catch (Exception ex)
        {
            logger.Error($"Pirate system config reload failed: {ex}");
        }
    }

    private static void LoadSpeech()
    {
        EnsureDefaultSpeech();
        SpeechLines = LoadTextLines(PirateConfig.Current.SpeechFilePath);
        LoadPhrases();
    }

    private static void LoadPhrases()
    {
        Phrases.Clear();

        try
        {
            EnsureDefaultPhrases();

            if (!File.Exists(PirateConfig.Current.PhrasesPath))
            {
                return;
            }

            using var doc = JsonDocument.Parse(File.ReadAllText(PirateConfig.Current.PhrasesPath));
            if (doc.RootElement.ValueKind != JsonValueKind.Object)
            {
                return;
            }

            foreach (var prop in doc.RootElement.EnumerateObject())
            {
                if (prop.Value.ValueKind != JsonValueKind.Array)
                {
                    continue;
                }

                var list = new List<string>();
                foreach (var el in prop.Value.EnumerateArray())
                {
                    if (el.ValueKind == JsonValueKind.String)
                    {
                        list.Add(el.GetString() ?? string.Empty);
                    }
                }

                Phrases[prop.Name] = list.ToArray();
            }
        }
        catch (Exception ex)
        {
            logger.Error($"Failed to load pirate phrases: {ex}");
        }
    }

    private static void EnsureDefaultSpeech()
    {
        if (File.Exists(PirateConfig.Current.SpeechFilePath))
        {
            return;
        }

        try
        {
            var dir = Path.GetDirectoryName(PirateConfig.Current.SpeechFilePath);
            if (!string.IsNullOrEmpty(dir))
            {
                Directory.CreateDirectory(dir);
            }

            File.WriteAllText(PirateConfig.Current.SpeechFilePath, DefaultSpeechText);
        }
        catch (Exception ex)
        {
            logger.Error($"Failed to write default pirate speech: {ex}");
        }
    }

    private static void EnsureDefaultPhrases()
    {
        try
        {
            Dictionary<string, List<string>> existing = null;

            if (File.Exists(PirateConfig.Current.PhrasesPath))
            {
                try
                {
                    using var doc = JsonDocument.Parse(File.ReadAllText(PirateConfig.Current.PhrasesPath));
                    if (doc.RootElement.ValueKind == JsonValueKind.Object)
                    {
                        existing = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
                        foreach (var prop in doc.RootElement.EnumerateObject())
                        {
                            if (prop.Value.ValueKind != JsonValueKind.Array)
                            {
                                continue;
                            }

                            var list = new List<string>();
                            foreach (var el in prop.Value.EnumerateArray())
                            {
                                if (el.ValueKind == JsonValueKind.String)
                                {
                                    list.Add(el.GetString() ?? string.Empty);
                                }
                            }

                            existing[prop.Name] = list;
                        }
                    }
                }
                catch
                {
                    existing = null;
                }
            }

            using var defaults = JsonDocument.Parse(DefaultPhrasesJson);
            var changed = existing == null;
            existing ??= new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);

            foreach (var prop in defaults.RootElement.EnumerateObject())
            {
                if (existing.TryGetValue(prop.Name, out var current) && current.Count > 0)
                {
                    continue;
                }

                var list = new List<string>();
                foreach (var el in prop.Value.EnumerateArray())
                {
                    if (el.ValueKind == JsonValueKind.String)
                    {
                        list.Add(el.GetString() ?? string.Empty);
                    }
                }

                existing[prop.Name] = list;
                changed = true;
            }

            if (!changed)
            {
                return;
            }

            var dir = Path.GetDirectoryName(PirateConfig.Current.PhrasesPath);
            if (!string.IsNullOrEmpty(dir))
            {
                Directory.CreateDirectory(dir);
            }

            File.WriteAllText(
                PirateConfig.Current.PhrasesPath,
                JsonSerializer.Serialize(existing, new JsonSerializerOptions { WriteIndented = true })
            );
        }
        catch (Exception ex)
        {
            logger.Error($"Failed to write default pirate phrases: {ex}");
        }
    }

    private const string DefaultSpeechText = """
Yo ho, the sea is wide and the cargo is fat.
Another day, another fat merchant.
I smell gold on the wind.
Keep yer eyes peeled, lads.
Rum tonight, lads — someone else's coin!
The sea gives and the sea takes.
No law out here but mine.
Sail fast, shoot faster.
Merchant blood pays best.
Steady as she goes, ye scurvy dogs.
I've plundered kings and beggars alike.
Every horizon hides a prize.
The deep keeps its secrets... and its gold.
Drink up, lads — plunder at dawn!
A calm sea never made a skilled pirate.
Wealth floats — go take it.
Them sails on the horizon? Dinner bells.
Anchor's up when I say it's up.
Gold doesn't swim. Pirates do.
Wind, rum, and plunder — a pirate's holy trinity.
""";

    private const string DefaultPhrasesJson = """
{
  "Spot": [
    "Ahoy! A fat merchant on the horizon!",
    "Look alive, lads. Fresh meat ahead.",
    "Sails ahead! Trim the sheets!",
    "There's our prize, lads — full sails!",
    "Easy money on the waves today!"
  ],
  "Chase": [
    "Run, run! The sea is mine!",
    "Ye can't outrun the tide, friend!",
    "Full sails! She'll be ours by dusk!",
    "The wind favors the wicked, lads!",
    "Chase her down! No rest for the rich!"
  ],
  "Demand": [
    "Strike yer sails! Pay in gold or feed the fish!",
    "This is a toll, mate. Pay up or lose the ship!",
    "Hand over the gold and keep your hull!",
    "Tribute or timber — choose fast!",
    "Your purse or your planks, captain!"
  ],
  "Accept": [
    "Smart fish. Pleasure doing business.",
    "A wise captain lives to sail another day.",
    "Pleasure doing business. Stay fat and foolish.",
    "Gold in hand, blood unspilled — a good trade.",
    "Smart choice. Tell your friends we take checks."
  ],
  "Refuse": [
    "Then ye'll be shark food!",
    "Wrong answer! Board her, lads!",
    "So be it! Bleed them dry!",
    "Have it your way — take everything!",
    "Fool! The sea will sort you out!"
  ],
  "Boarding": [
    "Boarding! Take that ship!",
    "Over the side, lads! Take her!",
    "Grappling hooks! Move, move!",
    "Boarders away! Spare no one!",
    "Claim her! She's ours!"
  ],
  "Jettison": [
    "Ha! Feeding the fish, are we?",
    "Throw it all over, I'll still take the rest!",
    "The sea pays me either way!",
    "Wise... and still cheaper than blood."
  ],
  "ParleyFar": [
    "Yer voice carries, but not yer gold!",
    "Close the distance if ye want to talk!",
    "Shout louder — the sharks are listening!"
  ],
  "Enraged": [
    "Ye dare?! I'll gut ye slow!",
    "That tongue buys ye a painful death!",
    "RAAAAH! No mercy now!",
    "You'll eat those words. Through a straw."
  ],
  "SurrenderKeywords": [
    "take my gold",
    "i surrender",
    "we will pay",
    "we pay",
    "spare us",
    "take the gold",
    "we surrender"
  ],
  "InsultKeywords": [
    "coward",
    "weakling",
    "scum",
    "pathetic",
    "old fool"
  ],
  "Reinforce": [
    "Blow the whistle! All hands on deck!",
    "More blades! Don't let them breathe!",
    "Every hand to the fight! NOW!",
    "Rouse the crew! Double shares for kills!",
    "More bodies, lads! Pile on!"
  ],
  "Attack": [
    "Cut them down to the man!",
    "No quarter! No mercy!",
    "Blood and thunder, lads!",
    "Send them to the deep!",
    "Your gold or your grave!",
    "The tide turns against you, friend!",
    "Ye should have stayed ashore!",
    "I'll wear your teeth as a necklace!",
    "Hold fast! She's almost ours!",
    "Gut the lot of them!",
    "The sea favors the bold!",
    "You'll make fine chum!",
    "Take their ship and their purses!",
    "Fight, ye dogs! Fight!",
    "This is MY ocean!",
    "Pray to your gods — it's too late for gold!",
    "Nothing personal. Just plunder.",
    "First to the deck gets double share!",
    "Make it quick, make it bloody!",
    "Your cargo, your ship, your life — mine now!",
    "Har har! Fresh meat for the blades!",
    "Row, you wretches — closer! Closer!",
    "I'll take that head as a trophy!",
    "Scuttle them where they float!",
    "No one hears you scream out here!",
    "The deep keeps what it catches!",
    "Yield and ye might live... probably not!",
    "Blades out! It's harvest time!",
    "You've got spirit — I'll drink to it from your skull!",
    "Board, bleed, burn!"
  ],
  "CombatMid": [
    "You're tougher than you look!",
    "Is that all you've got, sailor?",
    "Good! Good! A real fight at last!",
    "She's bleeding us — press on!",
    "Steady, lads! Steady!",
    "I'll not die on a Tuesday!",
    "Worth every scar, this one!",
    "Hit harder, ye swabs, hit harder!",
    "My grandmother hits harder!",
    "Bones heal — pride doesn't!",
    "So the fish want a show? Give them one!",
    "Half done, lads — finish it!"
  ],
  "CombatLow": [
    "I'm... not done yet!",
    "You'll choke on my last coin!",
    "Kill me and a hundred more rise!",
    "My blood buys your doom!",
    "Not... like this...",
    "The crew... avenge the crew!",
    "Curse you... curse the sea...",
    "I can still... fight...",
    "Take my ship... over my dead body — oh, wait...",
    "Dark waters... I see dark waters...",
    "You'll join me soon enough!",
    "Bury me deep... or not at all!"
  ],
  "Retreat": [
    "This ain't over, cur! The sea remembers!",
    "Fall back! We'll meet again, mark my words!",
    "She's too fierce — break off! Break off!",
    "Live to plunder another day!",
    "This round's yours — the war is mine!",
    "Back to the ship! Smartly now!",
    "I'll be seeing you in your nightmares!",
    "The tide's against us — pull away!",
    "You haven't seen the last of this flag!",
    "Retreat is just a fancy word for reloading!",
    "Curse you! Curse your ship and crew!",
    "Wounds heal — grudges don't!",
    "We're done here... for now.",
    "Scatter, lads! Regroup at the cove!",
    "You win this sea, not the ocean!",
    "My revenge will arrive by storm!",
    "Keep your loot warm — I'll fetch it later!",
    "Even krakens know when to dive!",
    "This hull's worth more than your hide — falling back!",
    "You fight like a demon — I hate demons!",
    "Full retreat! Man the oars!",
    "Luck favors you today, stranger!",
    "I'll carve your name on my blade — see you soon!",
    "Not like this... not today!",
    "The fog will hide us — next time, nothing will!",
    "Bold captain, dark waters — we shall dance again!",
    "Away! Away before she takes another mast!",
    "This debt gets paid in blood and gold!",
    "Mark my flag, remember my name!",
    "The sea gives, the sea takes — today she took my nerve!"
  ],
  "Victory": [
    "Feed the fishes!",
    "The sea takes her due.",
    "Another prize for the fleet!",
    "Strip her clean, lads!",
    "The deep welcomes another fool!"
  ],
  "Death": [
    "The captain... is down...",
    "Bury me... at sea...",
    "The curse... follows you now...",
    "My ship... avenge her...",
    "Cold... so cold..."
  ]
}
""";


    private static string[] LoadTextLines(string path)
    {
        try
        {
            if (!File.Exists(path))
            {
                return [];
            }

            var lines = File.ReadAllLines(path);
            var list = new List<string>(lines.Length);
            foreach (var raw in lines)
            {
                var line = raw.Trim();
                if (line.Length > 0 && !line.StartsWith('#'))
                {
                    list.Add(line);
                }
            }

            return list.ToArray();
        }
        catch (Exception ex)
        {
            logger.Error($"Failed to load pirate speech file {path}: {ex}");
            return [];
        }
    }

    private static void ScheduleCaptainSpawn(TimeSpan delay) => Timer.DelayCall(delay, SpawnCaptains);

    private static void SpawnCaptains()
    {
        var cfg = PirateConfig.Current;
        var next = TimeSpan.FromMinutes(
            Utility.RandomMinMax(Math.Max(1, cfg.CaptainSpawnIntervalMinMinutes), Math.Max(1, cfg.CaptainSpawnIntervalMaxMinutes))
        );

        try
        {
            if (cfg.Enabled && cfg.CaptainSpawnEnabled)
            {
                TrySpawnOnMap(Map.Felucca, cfg);
                if (Map.Trammel != null)
                {
                    TrySpawnOnMap(Map.Trammel, cfg);
                }
            }
        }
        catch (Exception ex)
        {
            logger.Error($"Pirate captain spawn failed: {ex}");
        }
        finally
        {
            ScheduleCaptainSpawn(next);
        }
    }

    private static void TrySpawnOnMap(Map map, PirateConfig cfg)
    {
        if (map == null || map == Map.Internal)
        {
            return;
        }

        var count = 0;
        foreach (var captain in Captains)
        {
            if (!captain.Deleted && captain.Map == map)
            {
                count++;
            }
        }

        if (count >= cfg.CaptainSpawnMaxPerMap)
        {
            return;
        }

        foreach (var rect in BaseBoat.GetWrapFor(map))
        {
            for (var attempt = 0; attempt < 80; attempt++)
            {
                var x = rect.X + Utility.Random(rect.Width);
                var y = rect.Y + Utility.Random(rect.Height);
                var land = map.Tiles.GetLandTile(x, y);

                if (!TileData.LandTable[land.ID].Flags.HasFlag(TileFlag.Wet))
                {
                    continue;
                }

                if (BaseBoat.FindBoatAt(new Point3D(x, y, land.Z), map) != null)
                {
                    continue;
                }

                var blocked = false;
                foreach (var tile in map.Tiles.GetStaticTiles(x, y))
                {
                    if (tile.Z >= -3)
                    {
                        blocked = true;
                        break;
                    }
                }

                if (blocked)
                {
                    continue;
                }

                var captain = new NPirateCaptain();
                captain.MoveToWorld(new Point3D(x, y, cfg.ShipZ), map);
                logger.Debug($"Spawned pirate captain {captain.Serial.Value} at {x},{y} on {map.Name}");
                return;
            }
        }
    }
}
