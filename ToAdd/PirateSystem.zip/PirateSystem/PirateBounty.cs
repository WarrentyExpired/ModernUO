using System;
using System.Collections.Generic;
using System.IO;
using ModernUO.Serialization;
using Server.Gumps;
using Server.Mobiles;
using Server.Network;

namespace Server.Items;

[SerializationGenerator(0, false)]
public partial class PirateBountyToken : Item
{
    [Constructible]
    public PirateBountyToken() : base(0x14F0)
    {
        Name = "Pirate Bounty Token";
        Hue = PirateConfig.Current.Bounty.TokenHue;
        LootType = LootType.Blessed;
    }

    public override void OnDoubleClick(Mobile from)
    {
        if (!IsChildOf(from.Backpack))
        {
            from.SendLocalizedMessage(1042001);
            return;
        }

        var reward = PirateConfig.Current.Bounty.TokenGoldReward;
        Delete();
        from.AddToBackpack(new Gold(reward));
        from.SendMessage($"You claim the pirate bounty: {reward} gold.");
    }
}

[SerializationGenerator(0, false)]
public partial class PirateWantedBoard : Item
{
    [Constructible]
    public PirateWantedBoard() : base(0x1BD7)
    {
        Name = "Pirate Wanted Board";
        Movable = false;
    }

    public override void OnDoubleClick(Mobile from)
    {
        if (!from.InRange(GetWorldLocation(), 2))
        {
            from.SendLocalizedMessage(500446);
            return;
        }

        from.SendGump(new PirateWantedGump());
    }
}

public class PirateWantedGump : DynamicGump
{
    private const int W = 560;
    private const int H = 380;

    public override bool Singleton => true;

    public PirateWantedGump() : base(0, 0)
    {
    }

    protected override void BuildLayout(ref DynamicGumpBuilder builder)
    {
        builder.AddPage();
        PirateGumpHelpers.AddPanel(ref builder, W, H);

        builder.AddHtml(W / 2 - 180, 18, 360, 24, PirateGumpHelpers.Center("#FFCC00", "WANTED — Pirate Activity"));
        builder.AddLabel(25, 46, PirateGumpHelpers.HueYellow, "Recent victims — captains still at large:");

        var y = 75;
        foreach (var entry in ReadEntries())
        {
            builder.AddLabel(25, y, PirateGumpHelpers.HueWhite, $"{entry[0]} — {entry[6]} lost their ship near {entry[3]}, {entry[4]} ({entry[5]})");
            y += 22;
        }

        if (y == 75)
        {
            builder.AddLabel(25, y, PirateGumpHelpers.HueWhite, "No recent pirate attacks. The seas are calm...");
        }

        builder.AddImageTiled(20, H - 55, W - 40, 2, 96);
        builder.AddButton(W - 130, H - 40, 4005, 4007, 0);
        builder.AddLabel(W - 92, H - 38, PirateGumpHelpers.HueWhite, "Close");
    }

    private static List<string[]> ReadEntries()
    {
        var result = new List<string[]>();

        try
        {
            var path = PirateSystem.LogPath;
            if (!File.Exists(path))
            {
                return result;
            }

            var lines = File.ReadAllLines(path);
            for (var i = lines.Length - 1; i >= 1 && result.Count < 12; i--)
            {
                var parts = lines[i].Split(';');
                if (parts.Length >= 7 && parts[1] == "CAPTURE")
                {
                    result.Add(parts);
                }
            }
        }
        catch
        {
        }

        return result;
    }
}
