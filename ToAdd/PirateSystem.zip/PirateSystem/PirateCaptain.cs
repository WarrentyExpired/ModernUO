using System;
using System.Collections.Generic;
using ModernUO.Serialization;
using Server.Collections;
using Server.Items;
using Server.Logging;
using Server.Multis;

namespace Server.Mobiles;

[SerializationGenerator(0, false)]
[CorpseName("pirate captain corpse")]
public partial class NPirateCaptain : BaseCreature
{
    private static readonly ILogger logger = LogFactory.GetLogger(typeof(NPirateCaptain));

    [SerializableField(0)]
    private BaseBoat _ship;

    [SerializableField(1)]
    private bool _boatSpawned;

    [SerializableField(2)]
    private bool _isActive;

    [SerializableField(3)]
    private int _speechIndex;

    private DateTime _nextSpeech;
    private DateTime _nextSearch;
    private DateTime _nextChaseTaunt;
    private DateTime _nextCombatTaunt;
    private TimerExecutionToken _boardToken;
    private BoardingState _boardState;
    private RansomState _ransom;
    private Mobile _engagedTarget;
    private uint _lastEnemySerial;
    private uint _revengeTargetSerial;
    private bool _retreated;
    private bool _reinforced;
    private bool _enraged;
    private readonly List<NPirateCrew> _boarders = [];

    [Constructible]
    public NPirateCaptain() : base(AIType.AI_Archer, FightMode.Closest, 15, 1)
    {
        _isActive = true;

        SpeechHue = Utility.RandomDyedHue();
        Hue = Race.Human.RandomSkinHue();
        Female = Utility.RandomBool();

        if (Female)
        {
            Body = 0x191;
            Name = NameList.RandomName("female");
        }
        else
        {
            Body = 0x190;
            Name = NameList.RandomName("male");
        }

        Title = "the pirate captain";

        AddItem(new ThighBoots(RandomRedHue()));
        AddItem(new LongPants(RandomRedHue()));
        AddItem(new Shirt(RandomRedHue()));
        AddItem(new TricorneHat(RandomRedHue()));

        SetStr(536, 585);
        SetDex(126, 145);
        SetInt(426, 535);

        SetHits(500, 600);
        SetMana(800, 900);

        SetDamage(30, 35);

        SetDamageType(ResistanceType.Physical, 60);
        SetDamageType(ResistanceType.Fire, 40);

        SetResistance(ResistanceType.Physical, 60, 70);
        SetResistance(ResistanceType.Fire, 60, 70);
        SetResistance(ResistanceType.Cold, 60, 70);
        SetResistance(ResistanceType.Poison, 60, 70);
        SetResistance(ResistanceType.Energy, 60, 70);

        SetSkill(SkillName.EvalInt, 100.0);
        SetSkill(SkillName.Magery, 100.0);
        SetSkill(SkillName.Meditation, 100.0);
        SetSkill(SkillName.Poisoning, 100.0);
        SetSkill(SkillName.Anatomy, 120.0);
        SetSkill(SkillName.MagicResist, 150.0);
        SetSkill(SkillName.Tactics, 120.0);
        SetSkill(SkillName.Wrestling, 120.0);

        Fame = 25000;
        Karma = -25000;

        VirtualArmor = 60;

        CanSwim = true;
        CantWalk = true;

        Item ranged = Utility.Random(3) switch
        {
            0 => new Bow(),
            1 => new Crossbow(),
            _ => new HeavyCrossbow()
        };
        ranged.Movable = false;
        ranged.LootType = LootType.Blessed;
        AddItem(ranged);
        PackItem(new Arrow(100));
        PackItem(new Bolt(100));
        PackItem(new SmokeBomb());
        PackItem(new SmokeBomb());
        PackItem(new SmokeBomb());
        PackItem(new Gold(Utility.RandomMinMax(200, 500)));
        PackItem(new Bottle(Utility.RandomMinMax(5, 10)));

        PirateSystem.Captains.Add(this);
    }

    [AfterDeserialization]
    private void AfterDeserialization()
    {
        PirateSystem.Captains.Add(this);
    }

    private static int RandomRedHue() => Utility.RandomMinMax(0x66C, 0x673);

    public override bool AlwaysMurderer => true;
    public override bool InitialInnocent => false;
    public override bool PlayerRangeSensitive => false;

    public override void GenerateLoot()
    {
        AddLoot(LootPack.FilthyRich);
        AddLoot(LootPack.Gems, Utility.Random(2, 4));

        if (PirateConfig.Current.Bounty.Enabled)
        {
            PackItem(new PirateBountyToken());
        }
    }

    public override bool OnBeforeDeath()
    {
        SayPhase("Death");
        DesertCowards();
        return base.OnBeforeDeath();
    }

    private void DesertCowards()
    {
        var chance = PirateConfig.Current.Morale.DesertionChance;
        if (chance <= 0.0)
        {
            return;
        }

        using var crew = PooledRefList<NPirateCrew>.Create();
        foreach (var m in GetMobilesInRange(16))
        {
            if (m is NPirateCrew pirate && m.Alive)
            {
                crew.Add(pirate);
            }
        }

        foreach (var pirate in crew)
        {
            if (!pirate.Deleted && Utility.RandomDouble() < chance)
            {
                pirate.Say("*throws down their weapon and dives overboard!*");
                pirate.Delete();
            }
        }
    }

    public void Enrage()
    {
        if (Deleted || _enraged)
        {
            return;
        }

        _enraged = true;
        SayPhase("Enraged");
    }

    public void TryParley(PlayerMobile pm)
    {
        var state = _ransom;
        if (state != null)
        {
            if (state.Target == pm)
            {
                PirateRansomGump.DisplayTo(pm, Serial, state.Amount, state.JettisonStepsLeft);
            }

            return;
        }

        if (Map == null || pm.Map != Map || !pm.Alive)
        {
            return;
        }

        var boat = BaseBoat.FindBoatAt(pm.Location, Map);
        if (boat == null || boat is NPirateShip || PirateCaptureRegistry.IsCaptured(boat.Serial))
        {
            return;
        }

        if (!InRange(boat, 14))
        {
            SayPhase("ParleyFar");
            return;
        }

        SayPhase("Demand");
        BeginRansom(boat, pm);
    }

    public override void OnDamagedBySpell(Mobile caster, int damage)
    {
        base.OnDamagedBySpell(caster, damage);

        if (caster?.Map != null && caster.Map != Map.Internal)
        {
            SpawnPirate(caster);
        }
    }

    private bool HasValidShip() => _ship?.Deleted == false && _ship.Map == Map;

    public override void OnThink()
    {
        base.OnThink();

        if (!IsActive || Map == null || Map == Map.Internal)
        {
            return;
        }

        var now = Core.Now;
        var cfg = PirateConfig.Current;

        if (_ransom != null)
        {
            if (DateTime.UtcNow >= _ransom.Expires)
            {
                FinishRansom(_ransom.Target, false);
            }

            return;
        }

        if (Combatant == null)
        {
            if (_engagedTarget != null)
            {
                if (_engagedTarget is PlayerMobile deadPm && !deadPm.Deleted && !deadPm.Alive)
                {
                    SayPhase("Victory");
                }

                _engagedTarget = null;
            }

            if (now >= _nextSpeech)
            {
                _nextSpeech = now + TimeSpan.FromSeconds(Utility.RandomMinMax(cfg.SpeechIntervalMin, cfg.SpeechIntervalMax));
                Talk();
                Emote();
            }
        }
        else
        {
            _engagedTarget = Combatant;
            CheckRetreatAndReinforce(cfg);

            if (now >= _nextCombatTaunt)
            {
                _nextCombatTaunt = now + TimeSpan.FromSeconds(Utility.RandomMinMax(12, 20));
                SayCombatTaunt();
            }
        }

        if (!HasValidShip())
        {
            if (!_boatSpawned)
            {
                SpawnShip();
            }
            return;
        }

        if (now < _nextSearch)
        {
            return;
        }

        _nextSearch = now + TimeSpan.FromSeconds(Utility.RandomMinMax(cfg.SearchIntervalMin, cfg.SearchIntervalMax));
        Hunt(cfg);
    }

    private void Hunt(PirateConfig cfg)
    {
        if (_retreated || _ransom != null)
        {
            return;
        }

        var map = Map;
        var ship = _ship;

        PlayerMobile target = null;
        BaseBoat enemy = null;

        foreach (var m in GetMobilesInRange(cfg.SearchRadius))
        {
            if (m is not PlayerMobile pm || !pm.Alive)
            {
                continue;
            }

            var boat = BaseBoat.FindBoatAt(pm.Location, map);
            if (boat == null || boat == ship || boat is NPirateShip || boat.Deleted)
            {
                continue;
            }

            if (PirateCaptureRegistry.IsCaptured(boat.Serial) || PirateCaptureRegistry.IsOnCooldown(boat.Serial))
            {
                continue;
            }

            if (PirateBoatHelpers.IsNearShore(boat, cfg.Ransom.MinShoreDistance))
            {
                continue;
            }

            if (cfg.Ransom.SkipYoungPlayers && pm.Young)
            {
                continue;
            }

            if (pm.Skills.Total < cfg.Ransom.SkipBelowTotalSkills)
            {
                continue;
            }

            if (pm.Serial.Value == _revengeTargetSerial)
            {
                target = pm;
                enemy = boat;
                break;
            }

            target ??= pm;
            enemy ??= boat;
        }

        if (enemy == null)
        {
            _lastEnemySerial = 0;
            return;
        }

        if (enemy.Serial.Value != _lastEnemySerial)
        {
            _lastEnemySerial = enemy.Serial.Value;
            SayPhase("Spot");
        }

        var facing = ToCardinal(GetDirectionTo(enemy));
        if (ship.Facing != facing)
        {
            ship.Facing = facing;
        }

        ship.StartMove(Direction.North, true);

        if (InRange(enemy, cfg.AttackStopRange) && ship.IsMoving)
        {
            ship.StopMove(false);
        }

        if (Core.Now >= _nextChaseTaunt && !InRange(enemy, cfg.BoardingDistance))
        {
            _nextChaseTaunt = Core.Now + TimeSpan.FromSeconds(15);
            SayPhase("Chase");
        }

        if (target != null && InRange(enemy, Math.Max(1, cfg.BoardingDistance)))
        {
            if (cfg.Ransom.Enabled)
            {
                BeginRansom(enemy, target);
            }
            else
            {
                Board(enemy, target);
            }
        }
    }

    private void CheckRetreatAndReinforce(PirateConfig cfg)
    {
        if (!_retreated && !_enraged && Combatant != null && Hits < HitsMax * cfg.Combat.RetreatHealthPercent)
        {
            _retreated = true;
            if (_engagedTarget is PlayerMobile pm)
            {
                _revengeTargetSerial = pm.Serial.Value;
            }

            SayPhase("Retreat");
            Backpack?.ConsumeTotal(typeof(SmokeBomb), 1);
            PlaySound(0x22F);

            if (HasValidShip())
            {
                var away = (Direction)((((int)ToCardinal(GetDirectionTo(Combatant)) + 4) & 0x7));
                _ship.Facing = away;
                _ship.StartMove(Direction.North, true);
            }

            Combatant = null;
            return;
        }

        if (_retreated && Hits > HitsMax * 0.8)
        {
            _retreated = false;
            _reinforced = false;
            _enraged = false;
        }

        if (!_reinforced && Combatant != null && Hits < HitsMax * cfg.Combat.ReinforceHealthPercent)
        {
            _reinforced = true;
            SayPhase("Reinforce");
            SpawnCrewNear(Combatant);
            SpawnCrewNear(Combatant);
        }
    }

    private void BeginRansom(BaseBoat enemy, PlayerMobile target)
    {
        var ransomCfg = PirateConfig.Current.Ransom;
        var amount = CalcRansom(enemy, ransomCfg);

        if (GetPlayerGold(target) < amount)
        {
            Board(enemy, target);
            return;
        }

        PirateCaptureRegistry.RegisterCapture(enemy, DateTime.UtcNow + TimeSpan.FromSeconds(ransomCfg.TimeoutSeconds + 5));

        _ransom = new RansomState(enemy, target, amount, DateTime.UtcNow + TimeSpan.FromSeconds(ransomCfg.TimeoutSeconds))
        {
            JettisonStepsLeft = PirateConfig.Current.Jettison.Enabled ? PirateConfig.Current.Jettison.Steps : 0
        };

        SayPhase("Demand");
        PirateRansomGump.DisplayTo(target, Serial, amount, _ransom.JettisonStepsLeft);
        PirateSystem.Log("RANSOM_DEMAND", enemy, target, amount);
    }

    public void FinishRansom(Mobile from, bool accepted)
    {
        var state = _ransom;
        if (state == null)
        {
            return;
        }

        var boat = state.Boat;
        _ransom = null;

        if (accepted && TryTakeGold(from as PlayerMobile, state.Amount))
        {
            SayPhase("Accept");
            PirateCaptureRegistry.Unregister(boat.Serial);
            PirateCaptureRegistry.GrantImmunity(boat.Serial, TimeSpan.FromMinutes(PirateConfig.Current.Ransom.ImmunityAfterRansomMinutes));
            PirateSystem.Log("RANSOM_PAID", boat, from, state.Amount);
            _revengeTargetSerial = 0;
            _lastEnemySerial = 0;
            return;
        }

        if (accepted)
        {
            from?.SendMessage("You do not have enough gold.");
        }

        SayPhase("Refuse");
        PirateSystem.Log("RANSOM_REFUSED", boat, from);

        if (boat?.Deleted == false)
        {
            Board(boat, state.Target);
        }
    }

    private static int CalcRansom(BaseBoat boat, PirateConfig.RansomOptions ransomCfg)
    {
        var result = boat switch
        {
            NPirateShip => ransomCfg.PirateShipBase,
            LargeBoat or LargeDragonBoat => ransomCfg.LargeBase,
            MediumBoat or MediumDragonBoat => ransomCfg.MediumBase,
            _ => ransomCfg.SmallBase
        };

        var hold = PirateBoatHelpers.GetBoatHold(boat);
        if (hold?.Deleted == false)
        {
            result += (int)(hold.GetAmount(typeof(Gold)) * ransomCfg.HoldValuePercent);
        }

        var players = 0;
        foreach (var m in boat.GetMobilesInRange(16))
        {
            if (m is PlayerMobile pm && boat.Contains(pm.X, pm.Y))
            {
                players++;
            }
        }

        result += players * ransomCfg.PerPlayerBonus;
        return result;
    }

    private static int GetPlayerGold(PlayerMobile pm)
    {
        var total = 0.0;
        var backpack = pm.Backpack;
        if (backpack != null)
        {
            total += backpack.GetAmount(typeof(Gold));
        }

        total += Banker.GetBalance(pm);
        return (int)total;
    }

    private static bool TryTakeGold(PlayerMobile pm, int amount)
    {
        if (pm == null)
        {
            return false;
        }

        var backpack = pm.Backpack;
        if (backpack == null)
        {
            return false;
        }

        var onHand = backpack.GetAmount(typeof(Gold));
        var fromBackpack = Math.Min(onHand, amount);
        var remainder = amount - fromBackpack;

        if (fromBackpack > 0 && !backpack.ConsumeTotal(typeof(Gold), fromBackpack))
        {
            return false;
        }

        if (remainder <= 0)
        {
            return true;
        }

        if (!Banker.Withdraw(pm, remainder))
        {
            if (fromBackpack > 0)
            {
                backpack.DropItem(new Gold(fromBackpack));
            }

            return false;
        }

        return backpack.ConsumeTotal(typeof(Gold), remainder);
    }

    private void Board(BaseBoat enemy, PlayerMobile target)
    {
        var cfg = PirateConfig.Current;

        PirateCaptureRegistry.RegisterCapture(enemy, DateTime.UtcNow + PirateConfig.SinkDelay);
        PirateSystem.Log("CAPTURE", enemy, target);

        var numLooters = Math.Clamp(cfg.NumLooters, cfg.MinLooters, cfg.MaxLooters);
        var deck = enemy.GetMarkedLocation();

        for (var i = 0; i < numLooters; i++)
        {
            var crew = new NPirateCrew(PickRole(cfg));
            var loc = new Point3D(deck.X + Utility.RandomMinMax(-1, 1), deck.Y + Utility.RandomMinMax(-1, 1), deck.Z);
            crew.MoveToWorld(loc, Map);
            crew.Combatant = target;
            crew.Direction = GetDirectionTo(target);
            crew.Warmode = true;
            _boarders.Add(crew);
        }

        Say(cfg.BoardingMessage ?? "Boarding! Take that ship!");

        _boardState = new BoardingState(this, enemy, target);
        _boardToken.Cancel();
        Timer.StartTimer(TimeSpan.FromSeconds(2), TimeSpan.FromSeconds(5), CheckBoarding, out _boardToken);
    }

    private static PirateRole PickRole(PirateConfig cfg)
    {
        var roll = Utility.RandomDouble();
        if (roll < cfg.LooterWarriorChance)
        {
            return PirateRole.Warrior;
        }

        return roll < cfg.LooterWarriorChance + cfg.LooterArcherChance ? PirateRole.Archer : PirateRole.Mage;
    }

    private void CheckBoarding()
    {
        if (_boardState == null || _boardState.Check())
        {
            _boardState = null;
            _boardToken.Cancel();
        }
    }

    private void LootAndSink(Corpse corpse, BaseBoat enemy)
    {
        var cfg = PirateConfig.Current;
        var pirateBoat = _ship;

        if (pirateBoat?.Deleted == false)
        {
            var dest = PirateBoatHelpers.GetBoatHold(pirateBoat);
            if (dest != null)
            {
                if (cfg.LootPlayerCorpse && corpse?.Deleted == false)
                {
                    PirateBoatHelpers.TransferItems(corpse, dest);
                }

                if (cfg.LootPlayerHold && PirateBoatHelpers.GetBoatHold(enemy) is { } enemyHold && !ReferenceEquals(enemyHold, dest))
                {
                    PirateBoatHelpers.TransferItems(enemyHold, dest);
                }
            }

            RecallBoarders();
        }

        PirateCaptureRegistry.RegisterCapture(enemy, DateTime.UtcNow + PirateConfig.SinkDelay);
    }

    private void SpawnShip()
    {
        var map = Map;
        if (map == null || map == Map.Internal)
        {
            return;
        }

        Z = PirateConfig.Current.ShipZ;

        var boat = CreateBoat();
        _ship = boat;
        _boatSpawned = true;

        boat.MoveToWorld(new Point3D(X, Y - 1, Z), map);
        boat.UpdateComponents();

        if (boat.Hold != null)
        {
            new PirateHold(boat).MoveToWorld(boat.Hold.Location, map);
        }

        var cfg = PirateConfig.Current;
        var maxBySize = boat switch
        {
            SmallBoat or SmallDragonBoat => 3,
            MediumBoat or MediumDragonBoat => 6,
            _ => 10
        };

        var count = Math.Clamp(cfg.NumCrew, 1, Math.Min(maxBySize, cfg.NumCrewMax));
        for (var i = 0; i < count; i++)
        {
            var crew = new NPirateCrew { Ship = boat };
            crew.MoveToWorld(new Point3D(X, Y - 1, Z + 1), map);
        }

        logger.Debug($"Pirate captain {Serial.Value} spawned {boat.GetType().Name} {boat.Serial.Value} with {count} crew");
    }

    private static BaseBoat CreateBoat()
    {
        var w = PirateConfig.Current.BoatWeights;
        var total = w.NPirateShip + w.LargeDragonBoat + w.LargeBoat + w.MediumDragonBoat +
                    w.MediumBoat + w.SmallDragonBoat + w.SmallBoat;

        if (total <= 0)
        {
            return new NPirateShip();
        }

        var roll = Utility.Random(total);
        if ((roll -= w.NPirateShip) < 0)
        {
            return new NPirateShip();
        }

        if ((roll -= w.LargeDragonBoat) < 0)
        {
            return new LargeDragonBoat();
        }

        if ((roll -= w.LargeBoat) < 0)
        {
            return new LargeBoat();
        }

        if ((roll -= w.MediumDragonBoat) < 0)
        {
            return new MediumDragonBoat();
        }

        if ((roll -= w.MediumBoat) < 0)
        {
            return new MediumBoat();
        }

        if ((roll -= w.SmallDragonBoat) < 0)
        {
            return new SmallDragonBoat();
        }

        return new SmallBoat();
    }

    private void SpawnPirate(Mobile target)
    {
        var map = target.Map;
        if (map == null || map == Map.Internal)
        {
            return;
        }

        var pirates = 0;
        foreach (var m in GetMobilesInRange(10))
        {
            if (m is NPirateCrew)
            {
                pirates++;
            }
        }

        var cfg = PirateConfig.Current;
        if (pirates >= cfg.NumCrewMax || Utility.RandomDouble() > 0.25)
        {
            return;
        }

        SpawnCrewNear(target);
    }

    private void SpawnCrewNear(Mobile target)
    {
        var map = Map;
        if (map == null || map == Map.Internal)
        {
            return;
        }

        var loc = Location;
        for (var r = 1; r <= 8; r++)
        {
            for (var dx = -r; dx <= r; dx++)
            {
                for (var dy = -r; dy <= r; dy++)
                {
                    if (Math.Abs(dx) != r && Math.Abs(dy) != r)
                    {
                        continue;
                    }

                    var x = loc.X + dx;
                    var y = loc.Y + dy;
                    var z = map.GetAverageZ(x, y);
                    if (!map.CanFit(x, y, z, 16, false, false))
                    {
                        continue;
                    }

                    var crew = new NPirateCrew { Ship = _ship };
                    crew.MoveToWorld(new Point3D(x, y, z), map);
                    crew.Combatant = target;
                    return;
                }
            }
        }
    }

    private void Talk()
    {
        var lines = PirateSystem.SpeechLines;
        if (lines.Length == 0)
        {
            return;
        }

        Say(lines[_speechIndex % lines.Length]);
        _speechIndex++;
    }

    private void SayCombatTaunt()
    {
        var fraction = HitsMax > 0 ? (double)Hits / HitsMax : 1.0;
        var phase = _enraged ? "Enraged" : fraction > 0.6 ? "Attack" : fraction > 0.3 ? "CombatMid" : "CombatLow";
        SayPhase(phase);
    }

    private void SayPhase(string phase)
    {
        var line = PirateSystem.PickPhrase(phase);
        if (line != null)
        {
            Say(line);
        }
    }

    private void Emote()
    {
        if (Utility.RandomDouble() < PirateConfig.Current.EmoteProbability)
        {
            Emote(Female ? 785 : 1056);
        }
    }

    private void RecallBoarders()
    {
        var pirateBoat = _ship;
        if (pirateBoat?.Deleted != false)
        {
            _boarders.Clear();
            return;
        }

        var home = pirateBoat.GetMarkedLocation();
        foreach (var crew in _boarders)
        {
            if (!crew.Deleted)
            {
                crew.MoveToWorld(new Point3D(home.X + Utility.RandomMinMax(-2, 2), home.Y + Utility.RandomMinMax(-2, 2), home.Z + 1), Map);
            }
        }

        _boarders.Clear();
    }

    public override void OnDelete()
    {
        _boardToken.Cancel();
        _boardState = null;
        _ransom = null;
        RecallBoarders();

        var ship = _ship;
        if (ship?.Deleted == false && PirateBoatHelpers.CountPiratesNear(ship) == 0)
        {
            PirateBoatHelpers.TryMakeLootable(ship);
        }

        PirateSystem.Captains.Remove(this);
        base.OnDelete();
    }

    private static Direction ToCardinal(Direction d) => (Direction)((((int)d & 0x7) / 2) * 2);

    public void JettisonCargo(PlayerMobile pm)
    {
        var state = _ransom;
        var jettisonCfg = PirateConfig.Current.Jettison;
        if (state == null || !jettisonCfg.Enabled || state.JettisonStepsLeft <= 0 || pm == null)
        {
            return;
        }

        var boat = state.Boat;
        if (boat?.Deleted != false)
        {
            return;
        }

        var hold = PirateBoatHelpers.GetBoatHold(boat);
        var goldInHold = hold?.GetAmount(typeof(Gold)) ?? 0;
        if (goldInHold <= 0)
        {
            pm.SendMessage("There is no gold in your hold to dump.");
            PirateRansomGump.DisplayTo(pm, Serial, state.Amount, state.JettisonStepsLeft);
            return;
        }

        var percentPerStep = (double)jettisonCfg.MaxPercent / Math.Max(1, jettisonCfg.Steps);
        var toDump = Math.Min(goldInHold, Math.Max(1, (int)(goldInHold * percentPerStep / 100.0)));

        hold.ConsumeTotal(typeof(Gold), toDump);
        state.JettisonStepsLeft--;
        state.Amount = CalcRansom(boat, PirateConfig.Current.Ransom);

        SayPhase("Jettison");
        PirateSystem.Log("RANSOM_JETTISON", boat, pm, toDump);

        if (jettisonCfg.PiratesCollect && boat.Map != null && boat.Map != Map.Internal)
        {
            new Gold(toDump).MoveToWorld(boat.Location, boat.Map);
            Timer.DelayCall(TimeSpan.FromSeconds(Math.Max(5, jettisonCfg.SalvageDelaySeconds)), SalvageJettisonedCargo);
        }

        PirateRansomGump.DisplayTo(pm, Serial, state.Amount, state.JettisonStepsLeft);
    }

    private void SalvageJettisonedCargo()
    {
        var state = _ransom;
        if (Deleted || state?.Boat?.Deleted != false)
        {
            return;
        }

        var dest = _ship?.Deleted == false ? PirateBoatHelpers.GetBoatHold(_ship) : null;
        if (dest == null)
        {
            return;
        }

        using var found = PooledRefList<Gold>.Create();
        foreach (var item in state.Boat.GetItemsInRange(8))
        {
            if (item is Gold gold && !gold.Deleted)
            {
                found.Add(gold);
            }
        }

        foreach (var gold in found)
        {
            if (gold.Parent is Container parent)
            {
                parent.RemoveItem(gold);
            }

            dest.DropItem(gold);
        }
    }

    private sealed class RansomState(BaseBoat boat, PlayerMobile target, int amount, DateTime expires)
    {
        public readonly BaseBoat Boat = boat;
        public readonly PlayerMobile Target = target;
        public int Amount = amount;
        public readonly DateTime Expires = expires;
        public int JettisonStepsLeft;
    }

    private class BoardingState
    {
        private readonly NPirateCaptain _captain;
        private readonly uint _enemySerial;
        private readonly Serial _targetSerial;
        private readonly DateTime _expires;

        public BoardingState(NPirateCaptain captain, BaseBoat enemy, Mobile target)
        {
            _captain = captain;
            _enemySerial = enemy.Serial.Value;
            _targetSerial = target.Serial;
            _expires = DateTime.UtcNow + PirateConfig.SinkDelay + TimeSpan.FromMinutes(1);
        }

        public bool Check()
        {
            if (World.FindItem((Serial)_enemySerial) is not BaseBoat { Deleted: false } boat)
            {
                PirateCaptureRegistry.Unregister(_enemySerial);
                return true;
            }

            if (DateTime.UtcNow >= _expires)
            {
                _captain.RecallBoarders();
                return true;
            }

            Corpse targetCorpse = null;
            foreach (var item in boat.GetItemsInRange(16))
            {
                if (item is Corpse corpse && corpse.Owner is PlayerMobile && corpse.Owner.Serial == _targetSerial)
                {
                    targetCorpse = corpse;
                    break;
                }
            }

            if (targetCorpse != null)
            {
                _captain.LootAndSink(targetCorpse, boat);
                return true;
            }

            return false;
        }
    }
}
