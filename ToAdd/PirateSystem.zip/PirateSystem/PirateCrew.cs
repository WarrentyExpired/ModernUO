using System;
using ModernUO.Serialization;
using Server.Items;
using Server.Multis;

namespace Server.Mobiles;

public enum PirateRole
{
    Warrior,
    Archer,
    Mage
}

[SerializationGenerator(1, false)]
[CorpseName("pirate corpse")]
public partial class NPirateCrew : BaseCreature
{
    [SerializableField(0)]
    private PirateRole _role;

    [SerializableField(1)]
    private BaseBoat _ship;

    private DateTime _nextExplosionAttempt = Core.Now;

    [Constructible]
    public NPirateCrew() : this((PirateRole)Utility.Random(3))
    {
    }

    public NPirateCrew(PirateRole role) : base(AIType.AI_Archer, FightMode.Closest, 15, 1)
    {
        _role = role;

        SpeechHue = Utility.RandomDyedHue();
        Hue = Race.Human.RandomSkinHue();
        Female = Utility.RandomBool();

        if (Female)
        {
            Body = 0x191;
            Name = NameList.RandomName("female");
        }
        else
        {
            Body = 0x190;
            Name = NameList.RandomName("male");
        }

        Title = "the pirate";

        AddItem(new ThighBoots(RandomRedHue()));
        AddItem(new Shirt(RandomRedHue()));
        AddItem(Utility.RandomBool() ? (Item)new ShortPants(RandomRedHue()) : new LongPants(RandomRedHue()));
        AddItem(Utility.RandomBool() ? (Item)new TricorneHat(RandomRedHue()) : new SkullCap(RandomRedHue()));

        SetStr(316, 385);
        SetDex(96, 115);
        SetInt(366, 455);

        SetHits(350, 420);
        SetMana(520, 620);

        SetDamage(20, 26);

        SetDamageType(ResistanceType.Physical, 0);
        SetDamageType(ResistanceType.Cold, 50);
        SetDamageType(ResistanceType.Fire, 50);

        SetResistance(ResistanceType.Physical, 40, 60);
        SetResistance(ResistanceType.Fire, 50, 70);
        SetResistance(ResistanceType.Cold, 50, 70);
        SetResistance(ResistanceType.Poison, 60, 70);
        SetResistance(ResistanceType.Energy, 50, 70);

        SetSkill(SkillName.EvalInt, 120.0);
        SetSkill(SkillName.Magery, 120.0);
        SetSkill(SkillName.Meditation, 120.0);
        SetSkill(SkillName.Poisoning, 120.0);
        SetSkill(SkillName.Anatomy, 120.0);
        SetSkill(SkillName.MagicResist, 120.0);
        SetSkill(SkillName.Tactics, 120.0);
        SetSkill(SkillName.Wrestling, 120.0);

        Fame = 25000;
        Karma = -25000;

        VirtualArmor = 70;

        PackItem(new Bottle(Utility.RandomMinMax(3, 7)));
        PackItem(new Gold(Utility.RandomMinMax(100, 250)));

        ConfigureByRole(role);

        ChangeAIType(role switch
        {
            PirateRole.Warrior => AIType.AI_Melee,
            PirateRole.Mage => AIType.AI_Mage,
            _ => AIType.AI_Archer
        });
    }

    private static int RandomRedHue() => Utility.RandomMinMax(0x66C, 0x673);

    private void ConfigureByRole(PirateRole role)
    {
        Item weapon = role switch
        {
            PirateRole.Warrior => Utility.Random(4) switch
            {
                0 => new Halberd(),
                1 => new VikingSword(),
                2 => new WarAxe(),
                _ => new Spear()
            },
            PirateRole.Mage => Utility.Random(2) switch
            {
                0 => new BlackStaff(),
                _ => new GnarledStaff()
            },
            _ => Utility.Random(6) switch
            {
                0 => new Bow(),
                1 => new CompositeBow(),
                2 => new Crossbow(),
                3 => new HeavyCrossbow(),
                4 => new RepeatingCrossbow(),
                _ => new Bow()
            }
        };

        weapon.Movable = false;
        weapon.LootType = LootType.Blessed;
        AddItem(weapon);

        if (role == PirateRole.Archer)
        {
            PackItem(weapon is Bow or CompositeBow ? new Arrow(100) : new Bolt(100));
        }

        if (role == PirateRole.Mage)
        {
            PackItem(new Spellbook());
            PackItem(new BlackPearl(Utility.RandomMinMax(5, 10)));
            PackItem(new Bloodmoss(Utility.RandomMinMax(5, 10)));
            PackItem(new MandrakeRoot(Utility.RandomMinMax(5, 10)));
            PackItem(new SulfurousAsh(Utility.RandomMinMax(5, 10)));
            PackItem(new SpidersSilk(Utility.RandomMinMax(5, 10)));
        }
    }

    private void MigrateFrom(V0Content content)
    {
        _role = (PirateRole)Utility.Random(3);
    }

    public override bool AlwaysMurderer => true;
    public override bool CanRummageCorpses => true;
    public override bool PlayerRangeSensitive => false;

    public override void GenerateLoot()
    {
        AddLoot(LootPack.Rich);
        AddLoot(LootPack.Gems, Utility.Random(1, 3));
    }

    public override void OnThink()
    {
        base.OnThink();

        if (Combatant == null || Deleted)
        {
            return;
        }

        if (Core.Now < _nextExplosionAttempt)
        {
            return;
        }

        var target = Combatant;
        var dist = Math.Max(Math.Abs(X - target.X), Math.Abs(Y - target.Y));
        if (dist is < 1 or > 8)
        {
            return;
        }

        var chance = _role switch
        {
            PirateRole.Warrior => 0.22,
            PirateRole.Archer => 0.18,
            PirateRole.Mage => 0.12,
            _ => 0.15
        };

        _nextExplosionAttempt = Core.Now + TimeSpan.FromSeconds(Utility.RandomMinMax(8, 16));

        if (Utility.RandomDouble() < chance && Backpack?.FindItemByType(typeof(Bottle), true) != null)
        {
            ThrowExplosion(target);
        }
    }

    private void ThrowExplosion(Mobile target)
    {
        Say("*throws an explosive!*");
        PlaySound(0x2F6);

        var damage = Utility.RandomMinMax(18, 30);
        AOS.Damage(target, this, damage, 60, 40, 0, 0, 0);

        foreach (var m in target.GetMobilesInRange(1))
        {
            if (m != target && m.Alive)
            {
                AOS.Damage(m, this, damage / 2, 60, 40, 0, 0, 0);
            }
        }

        Backpack.FindItemByType(typeof(Bottle), true)?.Delete();
    }

    public override void OnDeath(Container corpse)
    {
        base.OnDeath(corpse);

        var ship = _ship;
        if (ship?.Deleted == false && PirateBoatHelpers.CountPiratesNear(ship) == 0)
        {
            PirateBoatHelpers.TryMakeLootable(ship);
        }
    }
}
