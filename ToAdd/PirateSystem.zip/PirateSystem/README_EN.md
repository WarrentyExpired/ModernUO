/***********************************
* Author: Anna 08/12/2014          *
* Refactoring: Expa 09/18/2026     *
* Optimized for ModernUO 0.15.6.178*
***********************************/

# Pirate System — Staff Guide

Pirate system for ModernUO (.NET 10). Self-spawning pirate captains, hunting of
player ships, ransom, boarding, bounties, admin panel, logging.

---

## 1. Installation

1. Copy all `.cs` files into `Projects/UOContent/Engines/PirateSystem/`
   (or `Projects/UOContent/Custom/Pirate System/` — folder is up to you).
2. Build the server (`publish.cmd` / `dotnet build`).
3. On first start the system creates automatically:
   - `Distribution/Configuration/PirateSystem/config.json` — settings;
   - `Distribution/Data/The Pirate Captain/Speech.txt` — captain's ambient lines;
   - `Distribution/Data/The Pirate Captain/phrases.json` — event phrases;
   - `Distribution/Logs/PirateSystem.csv` — event journal (on first event).
4. On startup the console must show:
   `[PirateSystem] Initialized: ransom=on, autoSpawn=on, ...`
   If it is missing — the system did not load; check compile errors.

## 2. Quick start

- `[PirateAdmin` — control panel (GM+).
- `[add NPirateCaptain` — manually spawn a captain at the current spot (water!).
- `[add PirateWantedBoard` — wanted board (place it in a tavern).
- `[add NPirateShipDeed` — give a player a ready pirate ship.
- `[add PirateBountyToken` — give a bounty token (for testing).

## 3. How it works (for staff)

1. Every 30–60 minutes the system checks Felucca and Trammel: if there are
   fewer captains than the limit, it finds a water tile and spawns a captain.
   The captain builds a ship under himself (40% chance pirate ship, else
   regular boats) and a crew of 1–10 pirates.
2. Every 1–2 seconds the captain scans a radius of 100. The target is a living
   player on a boat. Skipped: young players, players with Skills.Total < 300,
   boats near shore (< 15 tiles to land), captured/cooldown boats.
3. In boarding range -> if ransom is enabled and the player can afford it, a
   demand gump appears (45 seconds). Paid — the captain leaves peacefully
   (+immunity). The gump has a "Jettison cargo" button: dump part of the hold
   gold overboard and the ransom is recalculated (limited to MaxPercent over
   Steps presses). If PiratesCollect is on, the pirates fish the dumped gold
   into their hold after SalvageDelaySeconds. Refused/timeout — boarding.
3a. Chat negotiations: a captain hears speech within 18 tiles. Yell a phrase
   from SurrenderKeywords ("take my gold", "we surrender"...) — the pirates
   stop and open the ransom early (if they have caught up). An insult from
   InsultKeywords ("coward", "weakling"...) enrages the captain: he will not
   retreat and fights to the death.
4. Boarding: the boat is stopped (anchor, keys removed), a raiding party
   spawns. Once the player's corpse is found — loot goes to the pirate hold —
   the party returns home.
5. SinkDelayMinutes (5) after capture the boat sinks: chat warnings, sinking
   animation, victims' items dumped to the water, corpses surface with loot.
6. Kill the captain and the whole crew -> the pirate ship's hold opens for
   5 minutes -> then it sinks. Bounty token drops from the captain's corpse.

## 4. Config (config.json)

| Parameter | Default | Description |
|---|---|---|
| `Enabled` | true | Master switch |
| `SpeechFilePath`, `PhrasesPath` | — | Paths to phrase files |
| `SpeechIntervalMin/Max` | 4/6 | Pause between ambient lines (sec) |
| `SearchRadius` | 100 | Captain hunt radius |
| `BoardingDistance` | 3 | Distance to start boarding |
| `NumCrew` / `NumCrewMax` | 5 / 10 | Ship crew and spell-spawn cap |
| `NumLooters` (Min/Max) | 3 (1/8) | Boarding party size |
| `SinkDelayMinutes` | 5 | Time until a captured boat sinks |
| `MaxConcurrentCaptures` | 20 | Simultaneous capture cap (excess sinks instantly) |
| `RemoveCorpsesOnSink` | true | Corpses near the sinking boat surface with loot and are removed |
| `TeleportOnSink` | true | Teleport everyone aboard to shore when sinking |
| `MoveEquippedItemsToHold` | false | Also take equipped items when sinking |
| `CaptainSpawnEnabled` | true | Automatic captain spawning |
| `CaptainSpawnIntervalMin/MaxMinutes` | 30/60 | Spawn check period |
| `CaptainSpawnMaxPerMap` | 2 | Captain limit per map |
| **BoatWeights** (ship type weights, sum = 100%) |||
| `BoatWeights.NPirateShip` | 40 | Pirate ship |
| `BoatWeights.LargeDragonBoat` | 20 | Large dragon boat |
| `BoatWeights.LargeBoat` | 15 | Large boat |
| `BoatWeights.MediumDragonBoat` | 8 | Medium dragon boat |
| `BoatWeights.MediumBoat` | 6 | Medium boat |
| `BoatWeights.SmallDragonBoat` | 6 | Small dragon boat |
| `BoatWeights.SmallBoat` | 5 | Small boat |
| **Ransom** |||
| `Ransom.Enabled` | true | Ransom instead of instant boarding |
| `Ransom.TimeoutSeconds` | 45 | Time to decide |
| `Ransom.SmallBase/MediumBase/LargeBase/PirateShipBase` | 500/1500/3000/5000 | Ransom base by boat type |
| `Ransom.HoldValuePercent` | 0.10 | + % of gold in the hold |
| `Ransom.PerPlayerBonus` | 250 | + per player aboard |
| `Ransom.CooldownMinutes` | 30 | Re-capture cooldown for a boat |
| `Ransom.ImmunityAfterRansomMinutes` | 10 | Immunity after paying (result = max with cooldown) |
| `Ransom.MinShoreDistance` | 15 | Do not attack boats closer to shore |
| `Ransom.SkipYoungPlayers` | true | Do not attack young players |
| `Ransom.SkipBelowTotalSkills` | 300 | Do not attack with Skills.Total below |
| **Jettison** |||
| `Jettison.Enabled` | true | Cargo-dump button in the ransom gump |
| `Jettison.MaxPercent` | 50 | Total % of hold gold that can be dumped |
| `Jettison.Steps` | 2 | Number of presses (each dumps MaxPercent/Steps) |
| `Jettison.PiratesCollect` | true | Pirates salvage the dumped gold into their hold |
| `Jettison.SalvageDelaySeconds` | 45 | Delay before pirates salvage the cargo |
| **Morale** |||
| `Morale.DesertionChance` | 0.35 | Chance a crew member "dives overboard" when the captain dies |
| **Combat** |||
| `Combat.RetreatHealthPercent` | 0.28 | Captain HP% to retreat |
| `Combat.ReinforceHealthPercent` | 0.5 | HP% to call reinforcements (once) |
| **Bounty** |||
| `Bounty.Enabled` | true | Bounty token from the captain |
| `Bounty.TokenGoldReward` | 1500 | Gold per token |
| `Bounty.TokenHue` | 1157 | Token hue |

The config is re-read every minute (hot-reload) — edit without restarting.

## 5. Logs

`Distribution/Logs/PirateSystem.csv` — columns:
`timestamp; action; boatSerial; boatX; boatY; map; actor; amount`

Events: `CAPTURE` (boarding), `RANSOM_DEMAND`, `RANSOM_PAID`, `RANSOM_REFUSED`,
`RANSOM_JETTISON` (cargo dump), `SINK`, `LOGOUT_CAPTURED` (player logged out on
a captured boat), `ADMIN_DELETE`.

**Logging levels:** the console only receives the initialization line,
warnings and errors. Captain spawns, capture registrations, sinkings and config
hot-reloads are written at Debug level — visible in the server log file
(`Logs/`), not in the console.

The wanted board (`PirateWantedBoard`) reads this file and shows the last
12 captures with victim names.

## 6. Phrases

- `Speech.txt` — captain's ambient chatter out of combat (one phrase per line,
  `#` starts a comment).
- `phrases.json` — event phrases by phase: `Spot, Chase, Demand, Accept,
  Refuse, Boarding, Reinforce, Attack (30), CombatMid (12), CombatLow (12),
  Retreat (30), Victory, Death`. Additional phases: `SurrenderKeywords` and
  `InsultKeywords` — chat-negotiation triggers; `Jettison`, `ParleyFar`,
  `Enraged` — lines for cargo dumping, parley-out-of-range and rage.
  In combat the phrase is picked by the captain's HP: >60% — Attack,
  30–60% — CombatMid, <30% — CombatLow (Enraged when furious).
- Your edits are preserved: the system only appends missing phases. Delete the
  file to regenerate the full default set.

## 7. Admin panel `[PirateAdmin`

Columns: serial, coordinates, map, pirates nearby, captured, hold items.
Row actions:
- **TP** — teleport to the boat;
- **Hold** — inspect hold contents (teleport / dump all);
- **Del** — full delete: unregisters capture, loot to water, hold, pirates,
  corpses, boat.

## 8. Tuning tips

- Too harsh? Raise `SinkDelayMinutes` to 10, lower `NumLooters`,
  keep `MoveEquippedItemsToHold` off (default).
- Too soft? Lower TimeoutSeconds, raise ransom bases, add more captains
  (`CaptainSpawnMaxPerMap`).
- Gold inflation: ransom removes gold from the server — raise bases if the
  economy is overheated.
- Pirate ships decay by standard boat rules (~9 days).

## 9. Known limitations

1. Serialization format changed: pirates from the old (2014) saves do not
   migrate — clean them before the update (crew survives restarts, role is
   re-randomized; old-format holds are readable).
2. Restart during an active ransom: capture timers survive, the open ransom
   gump does not (it resolves into boarding).
3. Admin delete kills pirates within a radius of 16; distant crew members of
   the same party may remain — kill them separately or with a second delete.

## 10. Troubleshooting

| Symptom | Check |
|---|---|
| Captains do not spawn | `Enabled`, `CaptainSpawnEnabled`, the init line in console, per-map limit |
| Captain is silent | `Speech.txt` is not empty, one phrase per line |
| Ransom gump does not open | `Ransom.Enabled`, the player must afford it (otherwise instant boarding) |
| Player boats are not attacked | young / Skills.Total < 300 / near shore / 30-min cooldown |
| Console errors | `Logs/PirateSystem.csv` and the server log; report to the developer with the text |
