using ModernUO.Serialization;

namespace Server.Multis;

[SerializationGenerator(0, false)]
public partial class NPirateShip : BaseBoat
{
    public override int NorthID => 0x4014;
    public override int EastID => 0x4015;
    public override int SouthID => 0x4016;
    public override int WestID => 0x4017;

    public override int HoldDistance => 5;
    public override int TillerManDistance => -5;

    public override Point2D StarboardOffset => new(2, -1);
    public override Point2D PortOffset => new(-2, -1);
    public override Point3D MarkOffset => new(0, 0, 3);

    public override BaseDockedBoat DockedBoat => new NPirateShipDocked(this);

    [Constructible]
    public NPirateShip()
    {
        Name = "Pirate Ship";
    }
}

[SerializationGenerator(0, false)]
public partial class NPirateShipDeed : BaseBoatDeed
{
    public override int LabelNumber => 1041210;
    public override BaseBoat Boat => new NPirateShip();

    [Constructible]
    public NPirateShipDeed() : base(0x4014, new Point3D(0, -1, -5))
    {
        Name = "Pirate Ship Deed";
        Hue = 1157;
    }
}

[SerializationGenerator(0, false)]
public partial class NPirateShipDocked : BaseDockedBoat
{
    public override BaseBoat Boat => new NPirateShip();

    public NPirateShipDocked(BaseBoat boat) : base(0x4014, new Point3D(0, -1, -5), boat)
    {
    }
}
